#include "dialog.h"
#include "ui_dialog.h"
#include <QFileDialog>
#include <QDebug>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

QString Dialog::get_addr()
{
     return ui->ledit_addr->text();
}


void Dialog::on_pbutton_path_clicked()
{
    QString dir=QFileDialog::getExistingDirectory();//选择目录
    if (!dir.isEmpty()) //选择目录名称不为空
    {
        ui->ledit_path->setText(dir);

        QPalette plet = ui->ledit_path->palette();
        plet.setColor(QPalette::Text,Qt::gray);
        ui->ledit_path->setPalette(plet);
    }
}

void Dialog::on_pbutton_ok_clicked()
{
    qDebug() << "成功";
    done(1);
}

void Dialog::on_pbutton_cancel_clicked()
{
    qDebug() << "取消";
    done(0);
}

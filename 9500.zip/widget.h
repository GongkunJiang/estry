#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include <QTableWidgetItem>
#include <QHeaderView>
#include <QCheckBox>

#include <QtSerialPort/QSerialPort>         // 提供访问串口的功能
#include <QtSerialPort/QSerialPortInfo>     // 提供系统中存在的串口信息

#include "dialog.h"
#include "protocol.h"

class CustomHeaderView:public QHeaderView
{
    Q_OBJECT

public:
    // 默认水平方向
    CustomHeaderView(Qt::Orientation ori = Qt::Horizontal, QWidget*parent = 0);

    //自定义头部，主要实现这个函数
protected:
    void paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const;

public slots:
    void slt_checkbox_click(bool);

private:
    QCheckBox *m_checkbox;
};

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
private:
    // 全局变量
    QSerialPort *serial;                                // 定义全局的串口对象
    int res_flag;
    QByteArray stub;
    int stub_count=0;
    bool ok;                                            // 用于接收字符串转数字的处理结果
    QList<xml_config> xml_cfg;
    int cfg_index;  // 用于擦除分区
    int xml_index;  // 用于发送分区
    QByteArray partition_data;
    QString partition_name;
    int partition_count=0;
    int command;
    QString upload_path;

    // 处理串口数据的函数封装
    int validate_frame(char *data,int type);
    void get_frame_check(frame_request *frame);
    void local_stub_changerate();
    xml_config get_cfg_by_name(QString name);
    void update_partition_progress(float progress);

    void request_bootrom_handshake();
    void request_stub_handshake();
    void request_stub_changerate();
    void request_stub_config();
    void request_bootstub();
    void request_bootdevice();
    void request_flash_unblock_erase(qint32 offset, qint32 size);
    void request_emmc_unblock_erase(qint32 offset, qint32 size);
    void request_upload_partitions();

    void send_frame(frame_request frame);
    void send_stub();
    void send_stub_ex(int offset,qint16 total);
    void send_stub_remain();
    void send_area_erase(int index);
    void send_partition(int index);
    void send_partition_flash(quint32 offset,qint16 total);
    void send_partition_emmc(quint32 offset,qint16 total);
    void send_partition_remain();

    void next_bootrom_handshake(char *data);
    void next_stub_handshake(char *data);
    void next_config(char *data);
    void next_send_stub(char *data);
    void next_bootstub(char *data);
    void next_changerate(char *data);
    void next_erase_unblock_flash(char *data);
    void next_erase_unblock_emmc(char *data);
    void next_send_partition_flash(char *data);
    void next_send_partition_emmc(char *data);
    void next_reboot(char *data);

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    Ui::Widget *ui;
    void log_update(QDateTime curDateTime,enum log_level level,QString detail);
    void xml_update(QString name);

    // 串口功能
    void SerialPortInit();             // 串口初始化（参数配置）
    void RefreshSerialPort();          // 刷新串口
    void openSerial();                 // 串口开关

    void set_gray();    // 设置bootrom波特率、stub路径和xml路径字体为灰色，表示不可编辑
    void set_other();   // "其他功能"按钮设置下拉菜单
    void set_table();   // 调整表格

public slots:
    void DataReceived();                         // 接收数据
    void DataSend(const char * data,int size);   // 发送数据

private slots:
    void on_table_xml_cellDoubleClicked(int row, int column);
    void on_pbutton_spath_clicked();
    void on_pbutton_xml_clicked();
    void on_act_clear_triggered();
    void on_act_ota_triggered();
    void on_act_emmc_triggered();
    void on_act_flash_triggered();
    void on_act_scope_triggered();
    void on_pbutton_download_clicked();
    void on_pbutton_upload_clicked();
    void on_pbutton_erase_clicked();
    void on_combo_port_activated(const QString &arg1);

};

#endif // WIDGET_H

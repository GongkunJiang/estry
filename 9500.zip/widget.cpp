#include "widget.h"
#include "ui_widget.h"

#include <QMenu>
#include <QDebug>
#include <QFileDialog>
#include <QXmlStreamReader>
#include <QDateTime>

void Widget::set_gray()
{
    QPalette plet_brate = ui->ledit_brate->palette();
    QPalette plet_spath = ui->ledit_spath->palette();
    QPalette plet_xml = ui->ledit_xml->palette();
    plet_brate.setColor(QPalette::Text,Qt::gray);
    plet_spath.setColor(QPalette::Text,Qt::gray);
    plet_xml.setColor(QPalette::Text,Qt::gray);
    ui->ledit_brate->setPalette(plet_brate);
    ui->ledit_spath->setPalette(plet_spath);
    ui->ledit_xml->setPalette(plet_xml);
}

void Widget::set_other()
{
    QMenu * menu = new QMenu(this);
    menu->addAction(ui->act_scope);
    menu->addAction(ui->act_flash);
    menu->addAction(ui->act_emmc);
    menu->addAction(ui->act_ota);
    menu->addAction(ui->act_clear);
    ui->tbutton_other->setMenu(menu);
}

void Widget::set_table()
{
    CustomHeaderView *head = new CustomHeaderView(Qt::Horizontal,this);
    head->setSectionResizeMode(QHeaderView::Fixed);
    ui->table_xml->setHorizontalHeader(head);
    ui->table_xml->resizeRowsToContents();
    ui->table_xml->setColumnWidth(0,80);
    ui->table_xml->setColumnWidth(1,100);
    ui->table_xml->setColumnWidth(2,400);
    ui->table_xml->setColumnWidth(3,50);
    ui->table_xml->setAlternatingRowColors(true);
    ui->table_log->resizeRowsToContents();
    ui->table_log->setColumnWidth(0,130);
    ui->table_log->setColumnWidth(1,100);
    ui->table_log->setColumnWidth(2,400);
    ui->table_log->setAlternatingRowColors(true);
}

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    // 设置bootrom波特率、stub路径和xml路径字体为灰色，表示不可编辑
    set_gray();
    // "其他功能"按钮设置下拉菜单
    set_other();
    // 调整表格
    set_table();

    // 串口初始化
    SerialPortInit();

}

Widget::~Widget()
{
    delete ui;
}

CustomHeaderView::CustomHeaderView(Qt::Orientation ori, QWidget *parent)
    :QHeaderView(ori,parent)
{
    m_checkbox = new QCheckBox(this);
    connect(m_checkbox,SIGNAL(clicked(bool)),this, SLOT(slt_checkbox_click(bool)));

    setSectionsClickable(true);
    m_checkbox->setCheckState(Qt::Checked);
}

void CustomHeaderView::paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const
{
    QHeaderView::paintSection(painter,rect,logicalIndex);

    //logicalIndex 当前第几列，也可以自定义显示其他控件；
    if(logicalIndex == 0)
    {
        QRect tmp;
        tmp.setSize(QSize(20,20));
        tmp.moveCenter(QPoint(rect.center().x()-30,rect.center().y()));
        m_checkbox->setGeometry(tmp);
    }

}

void CustomHeaderView::slt_checkbox_click(bool state)
{
    QTableWidget * xml = (QTableWidget *) this->parent();

    if(state)
    {
        for(int i=0;i<xml->rowCount();i++)
            xml->item(i,0)->setCheckState(Qt::Checked);
    }
    else
    {
        for(int i=0;i<xml->rowCount();i++)
            xml->item(i,0)->setCheckState(Qt::Unchecked);
    }
}

xml_config Widget::get_cfg_by_name(QString name)
{
    xml_config config;
    foreach (xml_config cfg, xml_cfg) {
        if(!QString::compare(name,cfg.name))
            config = cfg;
    }
    return config;
}

void Widget::on_table_xml_cellDoubleClicked(int row, int column)
{
    if(column==2)
    {
        QString curPath,aFileName;
        //获取应用程序的路径
        curPath=QCoreApplication::applicationDirPath();
        //调用打开文件对话框打开一个文件
        QString name = this->ui->table_xml->item(row,column-1)->text();
        xml_config cfg = get_cfg_by_name(name);
        aFileName=QFileDialog::getOpenFileName(this,tr("选择分区文件"),curPath+"\\"+cfg.img,"(*.bin)");
        if (!aFileName.isEmpty())
        {
            if ((cfg.img=="") || !QString::compare(QFileInfo(aFileName).fileName(),cfg.img)){
                cfg.path = aFileName;
                QString detail = tr("init.3 为%2选择%1").arg(aFileName,name);
                log_update(QDateTime::currentDateTime(),INFO,detail);
                QTableWidgetItem *item = new QTableWidgetItem();
                QFont font;
                font.setUnderline(true);
                item->setFont(font);
                item->setText(aFileName);
                this->ui->table_xml->setItem(row,column,item);
            }else{
                log_update(QDateTime::currentDateTime(),WARNING,tr("文件名称不匹配，请选择%1").arg(cfg.img));
            }
        }
    }
}

void Widget::on_pbutton_spath_clicked()
{
    QString curPath,aFileName;
    //获取应用程序的路径
    curPath=QCoreApplication::applicationDirPath();
    //调用打开文件对话框打开一个文件
    aFileName=QFileDialog::getOpenFileName(this,tr("选择stub文件"),curPath,"(*.bin)");
    if (!aFileName.isEmpty())
    {
        this->ui->ledit_spath->setText(aFileName);
        log_update(QDateTime::currentDateTime(),INFO,tr("成功设置stub路径 %1").arg(aFileName));
    }
}

void Widget::log_update(QDateTime curDateTime,enum log_level level,QString detail)
{
    int log_count = this->ui->table_log->rowCount();
    this->ui->table_log->setRowCount(log_count+1);
    QTableWidgetItem *item_time = new QTableWidgetItem();
    item_time->setText(curDateTime.toString("yyyy-MM-dd hh:mm:ss"));
    this->ui->table_log->setItem(log_count, 0, item_time);
    QTableWidgetItem *item_level = new QTableWidgetItem();
    if (level == INFO)
        item_level->setText("INFO");
    else if(level == WARNING)
        item_level->setText("WARNING");
    else if(level == ERROR)
        item_level->setText("ERROR");
    this->ui->table_log->setItem(log_count, 1, item_level);
    QTableWidgetItem *item_detail = new QTableWidgetItem();
    item_detail->setText(detail);
    this->ui->table_log->setItem(log_count, 2, item_detail);

    this->ui->table_log->scrollToBottom();
}

void Widget::xml_update(QString name)
{
    int xml_count = this->ui->table_xml->rowCount();
    this->ui->table_xml->setRowCount(xml_count+1);
    QTableWidgetItem *item_check = new QTableWidgetItem();
    item_check->setCheckState(Qt::Checked);
    item_check->setText("勾选");
    this->ui->table_xml->setItem(xml_count, 0, item_check);
    QTableWidgetItem *item_name = new QTableWidgetItem();
    item_name->setText(name);
    this->ui->table_xml->setItem(xml_count, 1, item_name);
    QTableWidgetItem *item_progress = new QTableWidgetItem();
    item_progress->setText("0%");
    this->ui->table_xml->setItem(xml_count, 3, item_progress);
}

void Widget::on_pbutton_xml_clicked()
{
    QString curPath,aFileName;
    //获取应用程序的路径
    curPath=QCoreApplication::applicationDirPath();

    if(this->ui->ledit_xml->text()==""){
        //调用打开文件对话框打开一个文件
        aFileName=QFileDialog::getOpenFileName(this,tr("打开配置文件"),curPath,"(*.xml)");

        if (!aFileName.isEmpty()){
            this->ui->ledit_xml->setText(aFileName);
        }
    }
    QXmlStreamReader reader;
    QFile file(this->ui->ledit_xml->text());
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        log_update(QDateTime::currentDateTime(),ERROR,tr("Cannot read file %1").arg(aFileName));
        return;
    }
    reader.setDevice(&file);
    while (!reader.atEnd())
    {
        if (reader.isStartElement() && reader.name() == "PARTITION")
        {

            // 存入全局变量
            xml_config cfg;
            cfg.dev_type = reader.attributes().value("dev_type").toInt();
            cfg.name = reader.attributes().value("name").toString();
            cfg.offset = reader.attributes().value("offset").toInt(&ok,16);
            cfg.size = reader.attributes().value("size").toInt(&ok,16);
            cfg.flag = reader.attributes().value("flag").toString();
            cfg.fota_flags = reader.attributes().value("fota_flags").toString();
            cfg.img = reader.attributes().value("img").toString();
            xml_cfg.append(cfg);

            // 更新配置表
            xml_update(cfg.name);
        }
        reader.readNext();
    }
    file.close();
    log_update(QDateTime::currentDateTime(),INFO,tr("成功打开配置文件 %1").arg(aFileName));
    qDebug() << "\n";
    foreach (xml_config cfg, xml_cfg) {
       qDebug() << "dev_type=" << cfg.dev_type << "\t"
                << "name=" << cfg.name << "\t"
                << "offset=" << QString::number(cfg.offset,16)<< "\t"
                << "size=" << QString::number(cfg.size,16) << "\t"
                << "flag=" << cfg.flag << "\t"
                << "fota_flags=" << cfg.fota_flags << "\t"
                << "img=" << cfg.img;
    }
}

void Widget::on_act_clear_triggered()
{
    if(this->ui->table_xml->rowCount()>0)
    {
        log_update(QDateTime::currentDateTime(),INFO,"清空配置分区列表");
        this->ui->table_xml->setRowCount(0);
        this->ui->ledit_xml->setText("");
    }
    else
    {
        log_update(QDateTime::currentDateTime(),WARNING,"分区列表为空！");
    }
}

void Widget::on_act_ota_triggered()
{
    log_update(QDateTime::currentDateTime(),INFO,"on_act_ota_triggered");
}

void Widget::on_act_emmc_triggered()
{
    log_update(QDateTime::currentDateTime(),INFO,"on_act_emmc_triggered");
}

void Widget::on_act_flash_triggered()
{
    log_update(QDateTime::currentDateTime(),INFO,"on_act_flash_triggered");
}

void Widget::on_act_scope_triggered()
{
    Dialog *d;
    d = new Dialog(this);
    if(d->exec())
    {
        log_update(QDateTime::currentDateTime(),INFO,"按范围上传成功");

    }
    else
    {
        log_update(QDateTime::currentDateTime(),WARNING,"取消按范围上传");
    }
}

void Widget::request_bootrom_handshake()
{
    frame_request hand_shake;
    hand_shake.magic = MAGIC_REQUEST;
    hand_shake.type = HANDSHAKE;
    hand_shake.length = 0x0000;
    hand_shake.data = nullptr;
    hand_shake.check = hand_shake.magic;    // 其他都是0
    char fp[10] = {0};
    memcpy(fp,(char *)&hand_shake,4);
    memcpy(fp+4,(char *)&hand_shake.check,1);
    DataSend(fp,5);

    res_flag = FLAG_BOOTROM_HANDSHAKE;
}

void Widget::on_pbutton_download_clicked()
{
    command = COMMAND_DOWNLOAD;
    if(serial->isOpen()){
        log_update(QDateTime::currentDateTime(),INFO,"step.1 发送bootrom握手请求");
        request_bootrom_handshake();
    }
    else{
        log_update(QDateTime::currentDateTime(),WARNING,"请先选择正确的端口号！");
    }
}

void Widget::on_pbutton_upload_clicked()
{
    command = COMMAND_UPLOAD;
    log_update(QDateTime::currentDateTime(),INFO,"step.0 设置上传路径");
    QString curPath,aPath;
    curPath=QCoreApplication::applicationDirPath();
    aPath=QFileDialog::getExistingDirectory(this,tr("选择分区上传路径"),curPath);
    if (!aPath.isEmpty())
    {
        log_update(QDateTime::currentDateTime(),INFO,tr("成功选择分区上传路径 %1").arg(aPath));
        upload_path = aPath;

        if(serial->isOpen()){
            log_update(QDateTime::currentDateTime(),INFO,"step.1 发送bootrom握手请求");
            request_bootrom_handshake();
        }
        else{
            log_update(QDateTime::currentDateTime(),WARNING,"请先选择正确的端口号！");
        }
    }
}

void Widget::on_pbutton_erase_clicked()
{
    log_update(QDateTime::currentDateTime(),INFO,tr("on_pbutton_erase_clicked"));
}

// 串口初始化（参数配置）
void Widget::SerialPortInit()
{
    serial = new QSerialPort;                       //申请内存,并设置父对象
    // 获取计算机中有效的端口号，然后将端口号的名称给端口选择控件
    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts())
    {
        serial->setPort(info);                      // 在对象中设置串口
        if(serial->open(QIODevice::ReadWrite))      // 以读写方式打开串口
        {
            ui->combo_port->addItem(info.portName());  // 添加计算机中的端口
            serial->close();                        // 关闭
        }
    }
    // 刷新串口
    RefreshSerialPort();

    // 信号
    connect(serial,&QSerialPort::readyRead,this,&Widget::DataReceived);         // 接收数据
}

// 刷新串口
void Widget::RefreshSerialPort()
{
    QStringList portNameList;                                        // 存储所有串口名

    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts()) //添加新串口
    {
        portNameList.append(info.portName());
    }
    ui->combo_port->clear();
    ui->combo_port->addItems(portNameList);

    // 模拟运行
    quint32 baud_rate = this->ui->ledit_brate->text().toInt(&ok,10);
    log_update(QDateTime::currentDateTime(),INFO,tr("init.1 设置bootrom波特率为 %1").arg(baud_rate));
    serial->setBaudRate(baud_rate);

    log_update(QDateTime::currentDateTime(),INFO,tr("init.2 打开配置文件partitions.xml"));
    on_pbutton_xml_clicked();

    // init.3 选择路径 不模拟，需要手动操作

    log_update(QDateTime::currentDateTime(),INFO,"init.4 打开串口 COM2");
    ui->combo_port->setCurrentIndex(1);                             // 当前串口号为COM2
    serial->setPortName(ui->combo_port->currentText());             // 设置串口号
    openSerial();                                                   // 打开串口
//    on_pbutton_download_clicked();                                  // 点击“下载分区”
}


// 串口开关
void Widget::openSerial()
{
    if(serial->isOpen())                                        // 如果串口打开了，先给他关闭
    {
        serial->clear();
        serial->close();
    }

    //当前选择的串口名字
    serial->setPortName(ui->combo_port->currentText());
    //用ReadWrite 的模式尝试打开串口，无法收发数据时，发出警告
    if(!serial->open(QIODevice::ReadWrite))
    {
        log_update(QDateTime::currentDateTime(),INFO,tr("串口打开失败 %1").arg(ui->combo_port->currentText()));
        return;
     }
    log_update(QDateTime::currentDateTime(),INFO,tr("串口打开成功 %1").arg(ui->combo_port->currentText()));
}

void Widget::on_combo_port_activated(const QString &arg1)
{
    log_update(QDateTime::currentDateTime(),INFO,tr("on_pbutton_upload_clicked %1").arg(arg1));
    openSerial();
}

int Widget::validate_frame(char *data,int type){
    frame_response response;
    memcpy((char *)&response,data,4);
    memcpy((char *)&response.status,data+4,2);
    if((response.check != response.magic + response.type + response.length + response.status)||
        (response.magic != MAGIC_RESPONSE)||(response.type!=type)||(response.length!=0)){
        log_update(QDateTime::currentDateTime(),ERROR,tr("响应帧无效！"));
        return FAILURE;
    }
    if(response.status == RESPONSE_FAILURE){
            log_update(QDateTime::currentDateTime(),ERROR,tr("响应失败！"));
            return FAILURE;
    }else if(response.status == RESPONSE_SUCCESS){
        log_update(QDateTime::currentDateTime(),INFO,tr("响应成功"));
        return SUCCESS;
    }
    return FAILURE;
}

void Widget::get_frame_check(frame_request *frame){
    frame->check = frame->magic + frame->type + (frame->length & 0xff) + (frame->length >> 8);
    for(int i=0;i<frame->length;i++)
        frame->check += frame->data[i];
}

void Widget::request_stub_config(){
    log_update(QDateTime::currentDateTime(),INFO,"step.3 发送stub.bin配置请求帧");
    frame_config cfg;
    cfg.type = 0x00000001;
    cfg.addr = this->ui->ledit_saddr->text().toInt(&ok,16);
    if(this->ui->ledit_spath->text()==""){
        log_update(QDateTime::currentDateTime(),ERROR,tr("stub路径为空！"));
        return;
    }
    QFile file(this->ui->ledit_spath->text());
    cfg.len = file.size() + 1;  // 1byte校验位
    // log_update(QDateTime::currentDateTime(),INFO,tr("cfg.len==%1").arg(cfg.len));
    frame_request cfg_request;
    cfg_request.magic = MAGIC_REQUEST;
    cfg_request.type = DOWNLOAD_RAM;
    cfg_request.length = sizeof(frame_config);
    cfg_request.data = (char *) &cfg;
    get_frame_check(&cfg_request);
    // log_update(QDateTime::currentDateTime(),INFO,tr("cfg_request.check==%1").arg(cfg_request.check));
    send_frame(cfg_request);

    res_flag = FLAG_CONFIG;
}

void Widget::next_bootrom_handshake(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.2 处理bootrom握手反馈");
    if(!validate_frame(data,HANDSHAKE)){
        request_stub_config();
    }
}

void Widget::send_frame(frame_request frame){
    DataSend((char *) &frame,4);
    DataSend(frame.data,frame.length);
    DataSend((char *) &frame.check,1);
}

void Widget::send_stub_ex(int offset,qint16 total){
    frame_request send_stub;
    send_stub.magic = MAGIC_REQUEST;
    send_stub.type = DOWNLOAD_RAM;

    char buf[FRAME_MAXSIZE + 8] = {0}; // 8字节地址+长度,1字节数据check
    quint32 addr = this->ui->ledit_saddr->text().toInt(&ok,16);
    quint32 len = stub.length();
    memcpy(buf,(char *)&addr,4);
    memcpy(buf+4,(char *)&len,4);

    if(total < FRAME_MAXSIZE){   // 以1K为单位
        send_stub.length = total + 8;// 下载内存地址（4Byte）；下载数据长度（4Byte）
        memcpy(buf+8,stub.data()+offset,total);
        send_stub.data = buf;
    }else{
        send_stub.length = FRAME_MAXSIZE + 8;
        memcpy(buf+8,stub.data()+offset,FRAME_MAXSIZE);
        send_stub.data = buf;
    }

    stub_count += 1;
    get_frame_check(&send_stub);
    send_frame(send_stub);
}

void Widget::send_stub(){
    QFile file(this->ui->ledit_spath->text());

    if (!file.open(QFile::ReadOnly))
    {
        log_update(QDateTime::currentDateTime(),ERROR,tr("Cannot read file %1").arg(this->ui->ledit_spath->text()));
        return;
    }
    stub = file.readAll();
    file.close();

    log_update(QDateTime::currentDateTime(),INFO,(tr("stub.bin共%1字节").arg(stub.length())));
    qint16 total = stub.length();

    send_stub_ex(0,total);

    res_flag = FLAG_SEND_STUB;
}

void Widget::next_config(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.4 处理stub.bin配置反馈");
    if(!validate_frame(data,DOWNLOAD_RAM)){
        log_update(QDateTime::currentDateTime(),INFO,"step.5 发送stub.bin数据帧");
        send_stub();

    }
}

void Widget::request_bootstub(){
    frame_request boot;
    boot.magic = MAGIC_REQUEST;
    boot.type = JUMP_TO_RUN;
    boot.length = 4;    // 4字节启动地址
    quint32 addr = this->ui->ledit_saddr->text().toInt(&ok,16);
    boot.data = (char *) &addr;
    get_frame_check(&boot);
    send_frame(boot);

    res_flag = FLAG_BOOTSTUB;
}

void Widget::send_stub_remain(){
    int offset = stub_count*FRAME_MAXSIZE;
    int total = stub.length() - offset;

    if(stub_count>0 && total > 0){
        log_update(QDateTime::currentDateTime(),INFO,(tr("stub.bin剩余%1字节，继续发送...").arg(total)));
        send_stub_ex(offset,total);
    }else{
        log_update(QDateTime::currentDateTime(),INFO,(tr("stub.bin发送完毕")));
        log_update(QDateTime::currentDateTime(),INFO,"step.8 发送stub.bin启动指令");
        request_bootstub();
    }
}

void Widget::next_send_stub(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.6 处理stub.bin数据帧反馈");
    if(!validate_frame(data,DOWNLOAD_RAM)){
        log_update(QDateTime::currentDateTime(),INFO,tr("step.7 stub.bin发送完毕？"));
        send_stub_remain();
    }
}

void Widget::request_stub_changerate(){
    frame_request rate;
    rate.magic = MAGIC_REQUEST;
    rate.type = SWITCH_BAUDRATE;
    rate.length = 4;
    quint32 baud_rate = this->ui->combo_srate->currentText().toInt(&ok,10);
    rate.data = (char *) &baud_rate;
    get_frame_check(&rate);

    send_frame(rate);
    res_flag = FLAG_CHANGERATE;
}

void Widget::next_bootstub(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.9 处理stub启动反馈");
    if(!validate_frame(data,JUMP_TO_RUN)){
        log_update(QDateTime::currentDateTime(),INFO,"step.10 发送波特率切换指令");
        request_stub_changerate();
    }
}

void Widget::local_stub_changerate(){
    quint32 baud_rate = this->ui->combo_srate->currentText().toInt(&ok,10);
    serial->close();
    serial->setBaudRate(baud_rate);
    openSerial();   //重启串口
}

void Widget::request_stub_handshake(){
    frame_request hand_shake;
    hand_shake.magic = MAGIC_REQUEST;
    hand_shake.type = HANDSHAKE;
    hand_shake.length = 0x0000;
    hand_shake.data = nullptr;
    hand_shake.check = hand_shake.magic;    // 其他都是0
    char fp[10] = {0};
    memcpy(fp,(char *)&hand_shake,4);
    memcpy(fp+4,(char *)&hand_shake.check,1);
    DataSend(fp,5);

    res_flag = FLAG_STUB_HANDSHAKE;
}

void Widget::next_changerate(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.11 处理波特率切换反馈");
    if(!validate_frame(data,SWITCH_BAUDRATE)){
        log_update(QDateTime::currentDateTime(),INFO,"step.12 切换本地波特率并重启串口");
        local_stub_changerate();
        log_update(QDateTime::currentDateTime(),INFO,"step.13 发送stub握手请求");
        request_stub_handshake();
    }
}

void Widget::request_emmc_unblock_erase(qint32 offset, qint32 size){
    frame_request erase;
    erase.magic = MAGIC_REQUEST;
    erase.type = ERASE_UNBLOCK_EMMC;
    erase.length = 8;
    char buf[erase.length] = {0};
    memcpy(buf,(char *)&offset,4);
    memcpy(buf+4,(char *)&size,4);
    erase.data = buf;
    get_frame_check(&erase);
    send_frame(erase);

    res_flag = FLAG_ERASE_UNBLOCK_EMMC;
}

void Widget::request_flash_unblock_erase(qint32 offset, qint32 size){
    frame_request erase;
    erase.magic = MAGIC_REQUEST;
    erase.type = ERASE_UNBLOCK_FLASH;
    erase.length = 8;
    char buf[erase.length] = {0};
    memcpy(buf,(char *)&offset,4);
    memcpy(buf+4,(char *)&size,4);
    erase.data = buf;
    get_frame_check(&erase);
    send_frame(erase);

    res_flag = FLAG_ERASE_UNBLOCK_FLASH;
}

void Widget::send_area_erase(int index){
    if(index < xml_cfg.length() && this->ui->table_xml->item(index,0)->checkState() == Qt::Checked) {
        xml_config cfg = xml_cfg.at(index);
        QString dev_type = tr("%1").arg(cfg.dev_type ? "emmc" : "flash");
        QString start = QString::number(cfg.offset,16);
        QString end = QString::number(cfg.offset + cfg.size,16);
        QString detail = tr("为%1擦除%2区域中[0x%3,0x%4)的数据...").arg(cfg.name,dev_type,start,end);
        log_update(QDateTime::currentDateTime(),INFO,detail);

        if(cfg.dev_type){
            //emmc 怎么区分块擦除和非块擦除？没区别，就用非块擦除吧
            request_emmc_unblock_erase(cfg.offset,cfg.size);
        }else{
            //flash 怎么区分块擦除和非块擦除？没区别，就用非块擦除吧
            request_flash_unblock_erase(cfg.offset,cfg.size);
        }
    }else{
        // 发送擦除请求完成
        log_update(QDateTime::currentDateTime(),INFO,"step.17 发送分区数据");
        xml_index = 0;
        send_partition(xml_index);
    }
}

void Widget::send_partition_flash(quint32 offset,qint16 total){
    frame_request spartition;
    spartition.magic = MAGIC_REQUEST;
    spartition.type = DOWNLOAD_FLASH;

    char buf[FRAME_MAXSIZE + 8] = {0};
    xml_config cfg = get_cfg_by_name(partition_name);
    quint32 addr = cfg.offset + offset;
    memcpy(buf,(char *)&addr,4);
    memcpy(buf+4,(char *)&total,4);

    if(total < FRAME_MAXSIZE){
        spartition.length = total + 8;
        memcpy(buf+8,partition_data.data()+offset,total);
        spartition.data = buf;
    }else{
        spartition.length = FRAME_MAXSIZE + 8;
        memcpy(buf+8,partition_data.data()+offset,FRAME_MAXSIZE);
        spartition.data = buf;
    }

    get_frame_check(&spartition);
    send_frame(spartition);

    res_flag = FLAG_SEND_PARTITION_FLASH;
}

void Widget::send_partition_emmc(quint32 offset,qint16 total){
    frame_request spartition;
    spartition.magic = MAGIC_REQUEST;
    spartition.type = DOWNLOAD_EMMC;

    char buf[FRAME_MAXSIZE + 8] = {0};
    xml_config cfg = get_cfg_by_name(partition_name);
    quint32 addr = cfg.offset + offset;
    memcpy(buf,(char *)&addr,4);
    memcpy(buf+4,(char *)&total,4);

    if(total < FRAME_MAXSIZE){
        spartition.length = total + 8;
        memcpy(buf+8,partition_data.data()+offset,total);
        spartition.data = buf;
    }else{
        spartition.length = FRAME_MAXSIZE + 8;
        memcpy(buf+8,partition_data.data()+offset,FRAME_MAXSIZE);
        spartition.data = buf;
    }

    get_frame_check(&spartition);
    send_frame(spartition);

    res_flag = FLAG_SEND_PARTITION_EMMC;
}

void Widget::send_partition(int index){
    // 如何告诉设备端你发的partition是哪个partiton? 根据设备端地址区间确定
    QTableWidgetItem *check = this->ui->table_xml->item(index,0);
    QTableWidgetItem *name = this->ui->table_xml->item(index,1);
    QTableWidgetItem *path = this->ui->table_xml->item(index,2);

    if(index < this->ui->table_xml->rowCount() && check->checkState() == Qt::Checked){
        if(path){   // 尚未设置路径，item地址默认为0x0
            log_update(QDateTime::currentDateTime(),INFO,tr("发送partition数据帧 %1").arg(name->text()));
            partition_count = 0;
            QFile file(path->text());
            if (!file.open(QFile::ReadOnly)){
                log_update(QDateTime::currentDateTime(),ERROR,tr("Cannot read file %1").arg(path->text()));
                return;
            }
            partition_data = file.readAll();
            log_update(QDateTime::currentDateTime(),INFO,tr("partition共%1字节").arg(partition_data.length()));
            file.close();
            xml_config cfg = get_cfg_by_name(name->text());
            partition_name = cfg.name;
            if(cfg.dev_type)
                send_partition_emmc(0,partition_data.length());
            else
                send_partition_flash(0,partition_data.length());
        }else{
            log_update(QDateTime::currentDateTime(),WARNING,tr("请先设置%1的文件路径！").arg(name->text()));
        }
    }else{
        log_update(QDateTime::currentDateTime(),INFO,"step.20 发送重启指令");
        request_bootdevice();
    }
}

void Widget::request_bootdevice(){
    frame_request reboot;
    reboot.magic = MAGIC_REQUEST;
    reboot.type = REBOOT;
    reboot.length = 0x0000;
    reboot.data = nullptr;
    get_frame_check(&reboot);
    send_frame(reboot);

    res_flag = FLAG_REBOOT;
}
void Widget::request_upload_partitions(){
    // 有些细节待确认
    // 上传分区是否和下载是相反的，及先上传分区大小，再上传分区数据 这种。
}

void Widget::next_stub_handshake(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.14 处理stub握手反馈");
    if(!validate_frame(data,HANDSHAKE)){
        switch (command) {
        case COMMAND_DOWNLOAD:
            log_update(QDateTime::currentDateTime(),INFO,"step.15 发送flash或emmc擦除请求");
            cfg_index = 0;
            send_area_erase(cfg_index);
            break;
        case COMMAND_UPLOAD:
            log_update(QDateTime::currentDateTime(),INFO,"step.15 发送分区上传请求");
            request_upload_partitions();
            break;
        default:
            break;
        }

    }
}

void Widget::next_erase_unblock_flash(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.16 处理flash擦除反馈");
    if(!validate_frame(data,ERASE_UNBLOCK_FLASH)){
        send_area_erase(++cfg_index);
    }
}

void Widget::next_erase_unblock_emmc(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.16 处理emmc擦除反馈");
    if(!validate_frame(data,ERASE_UNBLOCK_EMMC)){
        send_area_erase(++cfg_index);
    }
}

void Widget::update_partition_progress(float progress){
    QTableWidget * xml = this->ui->table_xml;
//    log_update(QDateTime::currentDateTime(),INFO,tr("partition_name %1").arg(partition_name));
    for(int i=0;i<xml->rowCount();i++){
//        log_update(QDateTime::currentDateTime(),INFO,tr("xml->item(i,1)->text() %1").arg(xml->item(i,1)->text()));
        if(!QString::compare(xml->item(i,1)->text(),partition_name)){
//            log_update(QDateTime::currentDateTime(),INFO,tr("分区下载进度为 %1").arg(xml->item(i,3)->text()));
            xml->item(i,3)->setText(tr("%1%").arg(progress));
//            log_update(QDateTime::currentDateTime(),INFO,tr("分区下载进度为 %1").arg(xml->item(i,3)->text()));
            break;
        }
    }
}

void Widget::send_partition_remain(){
    int offset = partition_count*FRAME_MAXSIZE;
    int total = partition_data.length() - offset;

    if(partition_count>0 && total > 0){
        log_update(QDateTime::currentDateTime(),INFO,(tr("partition剩余%1字节，继续发送...").arg(total)));
        xml_config cfg = get_cfg_by_name(partition_name);
        if(cfg.dev_type)
            send_partition_emmc(offset,total);
        else
            send_partition_flash(offset,total);
    }else{

        log_update(QDateTime::currentDateTime(),INFO,(tr("发送完毕")));
        update_partition_progress(100);
        partition_count = 0;
        send_partition(++xml_index);
    }
}

void Widget::next_send_partition_flash(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.18 处理发送flash partition反馈");
    if(!validate_frame(data,DOWNLOAD_FLASH)){
        partition_count += 1;
        float progress = 100 * (partition_count*FRAME_MAXSIZE)/partition_data.length();
        progress = progress>100? 100: progress;
        log_update(QDateTime::currentDateTime(),INFO,tr("更新分区下载进度为 %1%").arg(progress));
        update_partition_progress(progress);

        log_update(QDateTime::currentDateTime(),INFO,tr("step.19 flash partition发送完毕？"));
        send_partition_remain();
    }
}

void Widget::next_send_partition_emmc(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.18 处理发送emmc partition反馈");
    if(!validate_frame(data,DOWNLOAD_EMMC)){
        partition_count += 1;
        float progress = 100 * (partition_count*FRAME_MAXSIZE)/partition_data.length();
        log_update(QDateTime::currentDateTime(),INFO,tr("更新分区下载进度为 %1%").arg(progress));
        update_partition_progress(progress);

        log_update(QDateTime::currentDateTime(),INFO,tr("step.19 emmc partition发送完毕？"));
        send_partition_remain();
    }
}

void Widget::next_reboot(char *data){
    log_update(QDateTime::currentDateTime(),INFO,"step.21 处理设备重启反馈");
    if(!validate_frame(data,REBOOT)){
        log_update(QDateTime::currentDateTime(),INFO,"设备烧录成功");
    }
}

void Widget::DataReceived()
{
    QByteArray data = serial->readAll();
//   log_update(QDateTime::currentDateTime(),INFO,tr("data.length()==%1").arg(data.length()));
    if(data.length()==6)
    {
        switch(res_flag) {
        case FLAG_BOOTROM_HANDSHAKE:    next_bootrom_handshake(data.data());    break;
        case FLAG_CONFIG:               next_config(data.data());               break;
        case FLAG_SEND_STUB:            next_send_stub(data.data());            break;
        case FLAG_BOOTSTUB:             next_bootstub(data.data());             break;
        case FLAG_CHANGERATE:           next_changerate(data.data());           break;
        case FLAG_STUB_HANDSHAKE:       next_stub_handshake(data.data());       break;
        case FLAG_ERASE_UNBLOCK_FLASH:  next_erase_unblock_flash(data.data());  break;
        case FLAG_ERASE_UNBLOCK_EMMC:   next_erase_unblock_emmc(data.data());   break;
        case FLAG_SEND_PARTITION_FLASH: next_send_partition_flash(data.data()); break;
        case FLAG_SEND_PARTITION_EMMC:  next_send_partition_emmc(data.data());  break;
        case FLAG_REBOOT:               next_reboot(data.data());               break;
        default:                                                                break;
        }
    }
}
// 发送数据，write ()
void Widget::DataSend(const char *data,int size)
{
    serial->write(data,size);      // 串口发送数据
}

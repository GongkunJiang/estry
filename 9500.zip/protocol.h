#ifndef PROTOCOL_H
#define PROTOCOL_H

#define FRAME_REQUEST       0x73796E63 // 握手请求帧 "sync"
#define RESPONSE_SUCCESS    0x00       // 握手成功、配置成功或数据帧接收成功
#define RESPONSE_FAILURE    0xff       // 握手成功、配置成功或数据帧接收失败
#define MAGIC_REQUEST       0xa5       // 握手请求帧魔数
#define MAGIC_RESPONSE      0x5a       // 握手响应帧魔数
#define FRAME_MAXSIZE       0x0400     // 1KB=1024

enum command_type
{
    COMMAND_DOWNLOAD,
    COMMAND_UPLOAD,
    COMMAND_ERASE,
    COMMAND_UPLOAD_SCOPE,
    COMMAND_ERASE_ALLFLASH,
    COMMAND_ERASE_ALLEMMC,
    COMMAND_ERASE_OTA,
    COMMAND_CLEAR_LIST,
};

enum response_flag
{
    FLAG_BOOTROM_HANDSHAKE,
    FLAG_CONFIG,
    FLAG_SEND_STUB,
    FLAG_BOOTSTUB,
    FLAG_CHANGERATE,
    FLAG_STUB_HANDSHAKE,
    FLAG_ERASE_UNBLOCK_FLASH,
    FLAG_ERASE_UNBLOCK_EMMC,
    FLAG_SEND_PARTITION_FLASH,
    FLAG_SEND_PARTITION_EMMC,
    FLAG_REBOOT,
};

struct frame_config
{
    qint32 type;
    qint32 addr;
    qint32 len;
};

struct frame_request
{
    qint8 magic;
    qint8 type;
    qint16 length;
    char *data;
    qint8 check;
};

struct frame_response
{
    qint8 magic;
    qint8 type;
    qint16 length;
    char *data;
    qint8 status;
    qint8 check;
};

struct xml_config
{
    qint8 dev_type;
    QString name;
    qint32 offset;
    qint32 size;
    QString flag;
    QString fota_flags;
    QString img;
    QString path;
};

enum frame_type
{
    HANDSHAKE=              0x00,       // 握手消息
    DOWNLOAD_RAM=           0x01,       // 下载数据至ram
    DOWNLOAD_FLASH=         0x02,       // 下载数据至flash
    UPLOAD_FLASH=           0x03,       // 上载flash指定数据
    ERASE_BLOCK_FLASH=      0x04,       // 擦除flash指定数据，以1K块为最小单位
    ERASE_UNBLOCK_FLASH=    0x05,       // 擦除flash指定数据，不要求数据1K对齐
    ERASE_ALL_FLASH=        0x06,       // 擦除flash全部数据
    JUMP_TO_RUN=            0x07,       // 跳转到指定位置开始运行
    SWITCH_BAUDRATE=        0x08,       // UART波特率切换操作
    DOWNLOAD_EMMC=          0x09,       // 下载数据至emmc
    UPLOAD_EMMC=            0x0a,       // 上载emmc指定数据
    ERASE_BLOCK_EMMC=       0x0b,       // 擦除emmc指定数据，以1K块为最小单位
    ERASE_UNBLOCK_EMMC=     0x0c,       // 擦除emmc指定数据，不要求数据1K对齐
    ERASE_ALL_EMMC=         0x0d,       // 擦除emmc全部数据
    REBOOT=                 0x0e,       // 重启设备
};

enum status_return
{
    SUCCESS=                0x00,       // 成功
    FAILURE=                0x01,       // 失败
    ADDR_ERROR=             0x02,       // 地址解析错误
    TYPE_ERROR=             0x03,       // 类型错误
    LEN_ERROR=              0x04,       // 长度错误
    CRC_REEOR=              0x05,       // 校验值错误
};


enum log_level
{
    INFO=                   0x00,       // 通知
    WARNING=                0x01,       // 警告
    ERROR=                  0x02,       // 错误
};

#endif // PROTOCOL_H

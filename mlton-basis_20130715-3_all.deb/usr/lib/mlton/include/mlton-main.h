/* Copyright (C) 1999-2008 Henry Cejtin, Matthew Fluet, Suresh
 *    Jagannathan, and Stephen Weeks.
 * Copyright (C) 1997-2000 NEC Research Institute.
 *
 * MLton is released under a BSD-style license.
 * See the file MLton-LICENSE for details.
 */

#ifndef _MLTON_MAIN_H_
#define _MLTON_MAIN_H_

int MLton_main(int argc, char* argv[]);

#endif /* #ifndef _MLTON_MAIN_H_ */

#define MLton_Platform_Arch_host "m68k"


enum X_t60 {
  x1=0,
  x2=0,
  x3=0
};
enum X_t60 main ()
{
  enum X_t60 i_p460;
  int k_p461;
  k_p461 = (-((int) i_p460));
}


int main ()
{
  struct t249 {
    int x;
    int y;
  };
  struct t249 point_p1432;
  goto whileCont_p1434;
  
whileTop_p1433: 
  ;
  
whileCont_p1434: 
  ;
  if (1) 
    goto whileTop_p1433;
  return ;
}


enum X_t17 {
  x1=0,
  x2=0,
  x3=0
};
enum Y_t18 {
  y1=0,
  y2=0,
  y3=0
};
int main ()
{
  enum X_t17 i_p154;
  enum Y_t18 k_p155;
  float d_p156;
  double dd_p157;
  int tmp_p158;
  int *tmp2_p159;
  tmp_p158 = (((((k_p155&&i_p154)&&tmp2_p159)&&(i_p154>>k_p155))||(k_p155<<i_p154))||(dd_p157&&d_p156));
}

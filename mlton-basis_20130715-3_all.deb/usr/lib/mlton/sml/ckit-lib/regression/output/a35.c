
typedef unsigned short USHORT_t50;
typedef char UCHAR_t51;
struct t52 {
  USHORT_t50 size;
  UCHAR_t51 type;
  UCHAR_t51 class;
  long retran:8;
  long to_esid:24;
  long fill:8;
  long from_esid:24;
};
typedef struct t52 MGIHDR_t53;
int main ()
{
  int i_p411[12];
  
}

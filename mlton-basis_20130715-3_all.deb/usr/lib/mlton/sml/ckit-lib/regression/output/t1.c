
extern int printf ();
int main ()
{
  
  printf ("this is the end, my only friend the end");
  goto label_1_p1422;
  
label_1_p1422: 
  ;
  printf ("this is the end, my only friend the end");
  goto label_2_p1423;
  goto label_1_p1422;
  
label_2_p1423: 
  ;
  return 10;
}


struct foo_t25 {
  int x;
  float y;
};
union bar_t26 {
  int x;
  float y;
};
int main ()
{
  char z_p237[2][3];
  z_p237[0][0] = 97;
  z_p237[0][1] = 98;
  z_p237[0][2] = 99;
  z_p237[1][0] = 100;
  z_p237[1][1] = 101;
  z_p237[1][2] = 102;
  return 0;
}


int a[4]={1,2,3,4};
int main ()
{
  
  return a[2];
}

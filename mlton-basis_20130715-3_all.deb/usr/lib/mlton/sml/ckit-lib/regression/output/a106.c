
struct foo_t11 {
  int a[10];
  int p:4;
};
int main ()
{
  struct foo_t11 j_p70;
  return j_p70.p;
}

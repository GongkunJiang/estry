
int main ()
{
  void *i_p130;
  int *j_p131;
  j_p131==i_p130;
}

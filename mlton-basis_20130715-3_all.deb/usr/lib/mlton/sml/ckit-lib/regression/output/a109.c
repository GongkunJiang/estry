
struct t12 *x;
int main ()
{
  
  
}

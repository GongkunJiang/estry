
typedef int date_t_t97;
typedef int Htime_t_t98;
struct t99 {
  short npa;
};
typedef struct t99 areacode_t_t100;
int main ()
{
  int c_p762;
  c_p762 = ((int) 4);
}

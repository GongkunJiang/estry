
int f ();
int f (int c_p388)
{
  
  return c_p388;
}
int main ()
{
  char c_p390;
  f ((int) c_p390);
}


int a[4];
int f (int x_p56,int y_p57,int z_p58)
{
  
  return (x_p56+y_p57)+z_p58;
}
int main ()
{
  int s_p60;
  s_p60 = 3;
  a[3] = 5;
  a[3];
  return f (a[2],a[0],a[1]);
}

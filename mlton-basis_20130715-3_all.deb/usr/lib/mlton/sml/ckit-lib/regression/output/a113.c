
int main ()
{
  char *cp_p104;
  if (cp_p104==0) 
    return 1;
  else
    return 2;
}

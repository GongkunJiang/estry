
typedef unsigned long ULONG_t54;
struct cpMSCID_t55 {
  ULONG_t54 sid:16;
  ULONG_t54 swno:8;
  ULONG_t54 fill:8;
};
typedef struct cpMSCID_t55 CP_MSCID_TYPE_t56;
struct A_t57 {
  CP_MSCID_TYPE_t56 t;
};
int b[4];
int main ()
{
  int i_p422;
  
}

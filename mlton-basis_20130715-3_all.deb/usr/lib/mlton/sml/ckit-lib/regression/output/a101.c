
enum t22_t6 {
  p45_B_FALSE=0,
  p46_B_TRUE=1
};
typedef enum t22_t6 boolean_t_t23_t7;
int main ()
{
  boolean_t_t23_t7 j_p43;
  return 3;
}

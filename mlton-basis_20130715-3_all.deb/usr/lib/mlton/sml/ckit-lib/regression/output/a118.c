
extern struct t13 *fp;
struct bar_t14 {
  struct t13 *l;
};
int main ()
{
  int i_p128;
  return 0;
}

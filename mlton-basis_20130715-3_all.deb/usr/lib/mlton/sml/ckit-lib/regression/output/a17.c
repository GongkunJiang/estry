
int main ()
{
  int i_p169;
  i_p169 = (i_p169+i_p169);
  i_p169 = (i_p169-i_p169);
  i_p169 = (i_p169&&i_p169);
}

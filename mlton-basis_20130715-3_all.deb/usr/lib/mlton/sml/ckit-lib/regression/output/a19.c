
struct X_t19 {
  int x1;
  int x2;
  int x3;
};
enum Y_t20 {
  x1=0,
  x2=0,
  x3=0
};
int main ()
{
  int x1_p183;
  x1_p183 = x2;
}


struct qqux_t31 {
  int x;
};
int main ()
{
  unsigned int x_p298;
  
}

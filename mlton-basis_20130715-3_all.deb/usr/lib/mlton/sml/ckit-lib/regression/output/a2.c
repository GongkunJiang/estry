
int main ()
{
  int i_p185[4];
  int *j_p186;
  j_p186 = i_p185;
}


int main ()
{
  long i_p1631;
  unsigned long j_p1632;
  i_p1631 = 0;
  j_p1632 = 0;
  i_p1631 = ((long) 1);
  j_p1632 = ((unsigned long) 2);
  printf ("%d\n",i_p1631+j_p1632);
}

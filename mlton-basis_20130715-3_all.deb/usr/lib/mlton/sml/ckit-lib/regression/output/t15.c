
void main ()
{
  struct t347 {
    int x;
    int y;
  };
  struct t347 point_p1855;
  goto whileCont_p1857;
  
whileTop_p1856: 
  ;
  
whileCont_p1857: 
  ;
  if (1) 
    goto whileTop_p1856;
  return ;
}

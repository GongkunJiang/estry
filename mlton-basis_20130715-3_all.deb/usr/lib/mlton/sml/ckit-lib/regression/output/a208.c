
struct qqux_t30 {
  int x;
};
int main ()
{
  struct qqux_t30 x_p291;
  
}

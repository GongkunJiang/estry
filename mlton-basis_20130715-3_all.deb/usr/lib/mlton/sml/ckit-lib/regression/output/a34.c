
static int g ()
{
  
  return 3;
}
static int f (int h_p398 ())
{
  
  return h_p398 ();
}
int main ()
{
  
  return f (g);
}


int main ()
{
  int i_p1476;
  int x1_p1477;
  int *x2_p1478;
  int *x3_p1479[3];
  int **x4_p1480;
  int (*x5) ();
  x1_p1477 = ((int) i_p1476);
  x2_p1478 = ((int *) i_p1476);
  x4_p1480 = ((int **) x4_p1480);
  x5 = x5;
}

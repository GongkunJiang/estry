
int f ()
{
  int i_p434;
  i_p434 = 1;
}
int main ()
{
  int i_p436;
  i_p436 = (f&&i_p436);
}

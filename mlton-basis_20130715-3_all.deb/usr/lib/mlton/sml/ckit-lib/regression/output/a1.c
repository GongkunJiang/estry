
enum S_t1 {
  x1=0,
  x2=0
};
int main ()
{
  struct S_t2 {
    int abdd;
  };
  struct S_t2 j_p7;
  int i_p8;
  i_p8 = x1;
  switch (i_p8)
    {
      
      
    case 1: 
      
    case 2: 
      45;
      
    default: 
      45;
    }
  if (i_p8) 
    {
      
      1;
    }
  goto whileCont_p11;
  
whileTop_p10: 
  ;
  2;
  
whileCont_p11: 
  ;
  if (i_p8) 
    goto whileTop_p10;
  goto forStart_p14;
  
forTop_p13: 
  ;
  
forStart_p14: 
  ;
  if (i_p8) 
    goto forTop_p13;
  goto forStart_p18;
  
forTop_p17: 
  ;
  
forStart_p18: 
  ;
  if (1) 
    goto forTop_p17;
  
doTop_p21: 
  ;
  3;
  if (i_p8) 
    goto doTop_p21;
}


enum X_t15 {
  x1=0,
  x2=0,
  x3=0
};
enum Y_t16 {
  y1=0,
  y2=0,
  y3=0
};
int main ()
{
  enum X_t15 i_p141;
  enum Y_t16 k_p142;
  int tmp_p143;
  int *tmp2_p144;
  tmp_p143 = (k_p142%i_p141);
  tmp_p143 = (k_p142^i_p141);
  tmp_p143 = (k_p142|i_p141);
  tmp_p143 = (k_p142&i_p141);
  tmp_p143 = (k_p142>>i_p141);
  tmp_p143 = (k_p142<<i_p141);
  tmp2_p144 = (tmp2_p144+(x1*4));
  tmp2_p144 = (tmp2_p144+(k_p142*4));
}

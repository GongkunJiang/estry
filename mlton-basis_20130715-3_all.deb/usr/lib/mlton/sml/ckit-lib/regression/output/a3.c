
int main ()
{
  int j_p379;
  j_p379 = ((int) 4);
}

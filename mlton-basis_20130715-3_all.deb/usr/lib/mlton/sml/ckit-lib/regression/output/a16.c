
int main ()
{
  int i_p165;
  int k_p166;
  char j_p167;
  i_p165 = 99999999;
  i_p165 = ((int) j_p167);
  k_p166 = i_p165;
}

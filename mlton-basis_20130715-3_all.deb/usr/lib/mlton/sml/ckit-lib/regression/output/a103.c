
struct foo_t8 {
  int a[10];
  int p;
};
int b[100];
int f (int a_p51[100])
{
  
  return a_p51[0];
}
int main ()
{
  struct foo_t8 j_p53;
  return j_p53.p;
}

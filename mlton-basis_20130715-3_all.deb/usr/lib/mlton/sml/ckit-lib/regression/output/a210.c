
int main ()
{
  int *x_p312;
  int y_p313;
  y_p313 = 3;
}

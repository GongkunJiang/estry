
struct X_t32 {
  int x1;
  int x2;
  int x3;
};
enum Y_t33 {
  x1=0,
  x2=0,
  x3=0
};
int main ()
{
  struct X_t32 y_p308;
  struct X_t32 z_p309;
  float x2_p310;
  y_p308 = z_p309;
}

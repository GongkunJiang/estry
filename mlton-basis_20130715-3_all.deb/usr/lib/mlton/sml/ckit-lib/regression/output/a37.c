
void f (void);
int main ()
{
  
  f ();
}
void f ()
{
  
  
}

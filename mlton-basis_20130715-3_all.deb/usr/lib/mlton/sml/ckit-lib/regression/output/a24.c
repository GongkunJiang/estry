
struct X_t38 {
  int x1;
  int x2;
  int x3;
};
enum Y_t39 {
  x1=0,
  x2=0,
  x3=0
};
int main ()
{
  struct X_t40 {
    int x2;
    char x3;
  };
  struct X_t40 pp_p344;
  pp_p344.x2 = ((int) x1);
}


extern int timer_create (struct t5 *);
int main ()
{
  
  return 3;
}

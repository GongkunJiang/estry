
struct t63 {
  int n;
};
struct bar_t62 {
  struct t63 m;
};
struct bar_t62 a;
struct bar_t62 b;
struct bar_t62 c;
int main ()
{
  struct t65 {
    int n;
  };
  struct foo_t64 {
    struct t65 m;
  };
  typedef struct foo_t64 baz_t66;
  struct foo_t64 *p_p486;
  struct foo_t64 pp_p487;
  
}

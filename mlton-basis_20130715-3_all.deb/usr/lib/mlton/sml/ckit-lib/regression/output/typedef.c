
typedef int foo_t282;
int f (int y_p1651)
{
  int foo_p1652;
  foo_p1652 = 1;
  return foo_p1652+y_p1651;
}
foo_t282 main ()
{
  
  return f (1);
}

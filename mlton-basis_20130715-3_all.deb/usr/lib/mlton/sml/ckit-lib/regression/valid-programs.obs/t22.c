
void myfunc (){
  return;
}

void (*fp) () = &myfunc;

main ()
{
}



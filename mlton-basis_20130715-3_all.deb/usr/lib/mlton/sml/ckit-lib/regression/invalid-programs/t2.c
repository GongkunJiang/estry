extern int foo (int);

main ()
{
  int i;
  printf ("this is the end, my only friend the end");

  default: printf ("bar\n");

  switch (i) 
    default:
      if (foo (i))
	case 2: case 3: case 5: case 7:
	  foo (i);
      else 
        case 4: case 6: case 8: case 9: case 10:
          printf ("1");
}


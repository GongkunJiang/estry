main () {
  int i;
  i = 1;
  i++ += 3;
  printf("%d\n", i);
}

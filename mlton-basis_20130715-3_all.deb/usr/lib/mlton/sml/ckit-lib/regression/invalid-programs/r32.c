 const volatile const int y;
 const volatile volatile const volatile int z;
 const int * const volatile const p;

main() {
 y;
}

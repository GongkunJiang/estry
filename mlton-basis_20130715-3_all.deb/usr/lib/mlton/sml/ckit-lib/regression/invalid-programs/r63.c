/* null function pointers */

void f(int x, void y);

void main(){
 f(0);
}


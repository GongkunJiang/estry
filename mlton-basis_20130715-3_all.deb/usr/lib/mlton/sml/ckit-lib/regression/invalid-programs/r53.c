struct X { 
  int t(int);
  int y;
};


main(){
 return(0);
}

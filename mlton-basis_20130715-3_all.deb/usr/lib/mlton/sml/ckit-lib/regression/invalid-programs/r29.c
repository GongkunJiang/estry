union X {
  int y;
};


main () {
int x;
int x; 
 return(1);
}





void main() {
  int x;
  unsigned const int xx;
  char y;
  int *p;
 
/*  ++(*++p); */
/*  *(++p) += 6; */
/*  p++; */
/*  p--; */
/* *(p--) += 6; */

  xx = x;

}

main () {
 int j;
 int * const y = &j;
 y=&j; 
}

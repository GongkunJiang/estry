f() {
 int i = 1;
}

main () {
  float j, k;
  int i;

  i = j & k; 
}

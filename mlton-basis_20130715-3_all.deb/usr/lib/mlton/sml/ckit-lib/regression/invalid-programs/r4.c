main () {

  int *i, i2, k[4];
  short *j;

  i = j;
  i = i2;
  i = k;
}
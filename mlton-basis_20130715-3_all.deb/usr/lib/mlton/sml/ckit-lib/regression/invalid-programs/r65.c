main () {
  return 1;
}

int foo () {
  extern int a[10];
  return 1;
}

int bar () {
  extern int a[20];
  return 1;
}

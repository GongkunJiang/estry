f() {
 int i = 1;
}

main () {
  void *j;
  j = 5+sizeof;
}


  struct w { int x,y,z; };
  
  void main() {
   struct w foo;
   float x;
   x = foo;
  
  }

struct S {
  int x;
  int y;
};

main () {

  int i;
  
  switch(i) {
	case 1: 
	case 2: 45;
	default: 45;;;;
	}

}

struct S g () {
 int i;
 return(i);
}

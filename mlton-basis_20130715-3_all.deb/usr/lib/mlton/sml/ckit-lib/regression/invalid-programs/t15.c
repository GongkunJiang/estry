junk junk junk

void main ()
{

  while (1) {
    struct {int x; int y;} point;
  }

  return;
}



register int f(int x) {
 return(0);
}

main(){
 return(0);
}

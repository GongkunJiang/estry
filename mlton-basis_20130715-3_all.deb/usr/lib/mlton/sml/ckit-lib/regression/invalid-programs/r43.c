enum E1 {
 x, y, z
};

enum E2 {
 a, b
};

main () {
  enum E1 *x;
  enum E2 *y;
 
  x = y;
}

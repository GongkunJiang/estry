int f(float);

int f(int x) {
 return(x);
}

main () {
 return(0);
}

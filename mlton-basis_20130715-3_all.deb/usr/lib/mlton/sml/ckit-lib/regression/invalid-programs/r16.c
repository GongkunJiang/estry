enum X { 
  x1, x2, x3
}

main () {
  int i=1;

  x1 = i;
}

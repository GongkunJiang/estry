f() {
 int i = 1;
}

main () {
  int j;
  float d;
  j = sizeof(5) & d;
}

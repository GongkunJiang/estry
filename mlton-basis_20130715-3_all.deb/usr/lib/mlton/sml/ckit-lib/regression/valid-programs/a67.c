int a[20];
int a[];

int main () { return(0);}

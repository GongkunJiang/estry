extern printf ();

enum S {
  x1, x2
};

main () {

  struct S {
    int abdd;
  } j;
  int i = x1;

  switch(i) {
    case 1: 
    case 2: printf ("%d\n",45);
    default: printf ("%d\n",45);;;
  }

  if(i) { printf ("%d\n",i); }

  while(i--) { 2; }

  for(i; i; i++);
  
  do {3;} while (i);
}


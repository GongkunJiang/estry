main () {
  int *i, *j;
  i != 0;
  i > j;
  i >= j;
  i < j+1;
}

main () {

  int i[4], *j = i;
}

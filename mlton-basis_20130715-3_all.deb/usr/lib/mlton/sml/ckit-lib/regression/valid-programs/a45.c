void printf();

main() {

 int y;
 int x['\?'];  
 printf("\xAA\?\n\t\a\b\r\f %d eh???/n", '\xAA');
 printf("", '\001');
 
 y = 1;
 
}

char c_null = '\0';
char c_zero = '0';

int main () { return 0; }

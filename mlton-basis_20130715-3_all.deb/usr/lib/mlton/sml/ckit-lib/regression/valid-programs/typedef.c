typedef int foo;

int f (int y)
{ 
  int foo = 1;
  return (foo+y);
}

foo main ()
{
  return f(1);
}

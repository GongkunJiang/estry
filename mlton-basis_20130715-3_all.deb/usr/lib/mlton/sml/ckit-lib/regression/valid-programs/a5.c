f() {
 int i = 1;
}

main () {
  int i;

  i = f && i; 
}

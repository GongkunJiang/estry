/* a38.c */
/* Chandra bug, 6/3/99 */

int main(){
  for(;;){return 0;}
  return 0;
}

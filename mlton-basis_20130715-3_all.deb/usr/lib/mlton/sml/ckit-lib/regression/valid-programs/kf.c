
# 1 "../../tests/b.c"
# 1 "../../tests/myinc.h"

typedef int date_t;
typedef int Htime_t;







typedef struct {
  short int npa;
} areacode_t;


# 2 "../../tests/b.c"
main(){
 int c;
 c = sizeof(int);
}


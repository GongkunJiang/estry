
void foo(char * const * arg){
}


main () {

return 0;
}



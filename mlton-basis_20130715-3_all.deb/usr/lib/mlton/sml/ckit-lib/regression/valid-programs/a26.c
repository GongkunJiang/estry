enum e;

struct t {
  enum e *x;
};

enum e {
 g1, g2
};

struct s {
  enum e *x;
};

main () {

 return 0;
}

main () {
  int i = 99999999, k;
  char j;

  k = (i = j);
}

main (){

  int *p;

  p ++;

  p += 3;
}

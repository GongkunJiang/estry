struct qqux {int x;};

main (){

  unsigned int x;
}

extern struct foo *fp;

struct bar {
  struct foo *l;
};

main (){
  int i;

  return 0;

}

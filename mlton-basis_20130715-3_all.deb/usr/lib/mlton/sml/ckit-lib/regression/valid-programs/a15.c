main () {
  int j=1;
  int *i = &j;

  *(i++) = 3;
}

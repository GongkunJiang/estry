
main ()
{
  int i;
  do {
    i = i + 1;
    i = i + 1;
  } while (i<10);

  do {
    i = i - 1;
  } while (i>0);
}


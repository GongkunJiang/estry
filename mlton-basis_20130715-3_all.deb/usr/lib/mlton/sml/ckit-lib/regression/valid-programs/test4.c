void printf();

main()
{
   long i = 0;
   unsigned long j = 0;

   i = 1;
   j = 2;

   printf("%d\n", i + j);

}

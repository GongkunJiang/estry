/* Satish bug, 5/21/99 */

float f = 5.6, f1;

int main() {
  f1 = f * f;

  return 0;
}

extern int i;

int i = 5;

static int j;

main () {
  return i-i;
}

struct X;

main () {
  struct X {
    int y;
  };

 return 0;
}





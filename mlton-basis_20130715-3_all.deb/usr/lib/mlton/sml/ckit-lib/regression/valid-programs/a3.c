main () {
  int j;
  j = sizeof(5);
  {
  }
}

extern int i;

static int j;

main () {
  return j;
}

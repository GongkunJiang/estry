struct sigevent;

extern int timer_create(struct sigevent *);

main () {
  return 0;
}


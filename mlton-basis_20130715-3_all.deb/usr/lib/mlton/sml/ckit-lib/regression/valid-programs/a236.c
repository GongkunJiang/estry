int a[1];

int *p = a;

void main () {
  return;
}

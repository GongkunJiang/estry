main () {
  int x[] = {1,2,(int)&x};
}

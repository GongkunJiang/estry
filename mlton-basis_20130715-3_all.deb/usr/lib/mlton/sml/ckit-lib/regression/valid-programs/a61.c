struct x {
  int f;
  int g;
}

main() {

 struct x;

 struct x *k;

 struct x {
  int w;
 };

 k->w = 5;

}

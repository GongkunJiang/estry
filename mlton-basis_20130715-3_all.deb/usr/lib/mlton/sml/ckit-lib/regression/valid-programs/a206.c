main (){

  int x = 1;
  const int y = ++x;
  volatile int j = ++x;

  return 0;
}

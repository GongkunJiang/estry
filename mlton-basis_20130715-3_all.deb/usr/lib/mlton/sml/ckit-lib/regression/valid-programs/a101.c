enum t22 { p45_B_FALSE = 0,
           p46_B_TRUE = 1
         };

typedef enum t22 boolean_t_t23;

main () {
  boolean_t_t23 j;
  return 0;
}


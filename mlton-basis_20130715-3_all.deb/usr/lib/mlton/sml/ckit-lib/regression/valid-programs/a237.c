char * malloc();

main () {
 char *reg_equiv_replace = (char *) malloc (sizeof *reg_equiv_replace);
}


main () {
  return 1;
}

int foo () {
  extern int bar;
  return 1;
}


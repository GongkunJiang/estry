enum e {
	x1, x2, x3}

main () {
	enum e k;
	int i, j;

  j = i >> x1;
}

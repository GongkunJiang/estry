void printf();

struct num {
  short mantissa;
  short exponent;
};


typedef int mynum;

typedef struct numm {
  mynum mantissaa;
  short exponentt;
} xxx;

struct nummm {
  mynum mantissaaa;
  short exponenttt;
} v;

typedef struct nummm nummmmm;

typedef union q1 {
  short qa;
  short qb;
} q2;

typedef union q3 {
  short qaa;
  short qbb;
} q4;

typedef union q6 q7;

mynum main () {
	printf("");
	}

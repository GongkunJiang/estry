int main () {
  int *i, *j;
  i = j+1;

  return 0;
}

int a[4] = {-2,-1,0,1};

int main () {
  return a[2];
}


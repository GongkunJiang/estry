struct X {
  int x1;
  int x2;
  int x3;
};

enum Y {
  x1, x2, x3
};

main() {
  struct X {
	int x2;
        char x3;
  } pp;

  pp.x2 = x1;  
}

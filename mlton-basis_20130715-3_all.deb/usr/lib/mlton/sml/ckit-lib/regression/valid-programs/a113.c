
main () {
  char *cp;
  if (cp == 0) return 0;
  else return 2;
}

  typedef struct { int x,y,z; } w;
  
  void main() {
   w foo;
   foo = foo;
  }
  

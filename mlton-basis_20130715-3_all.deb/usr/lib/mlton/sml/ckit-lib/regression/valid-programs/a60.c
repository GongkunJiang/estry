typedef struct {int x,y; } point;

point x = {2,3};

void main () {
  return;
}

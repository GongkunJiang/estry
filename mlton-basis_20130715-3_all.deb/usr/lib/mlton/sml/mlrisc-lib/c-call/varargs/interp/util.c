#include <stdio.h>
#include <stdlib.h>

void vararg_error() {
  printf("ML vararg error\n");
  exit(1);
}



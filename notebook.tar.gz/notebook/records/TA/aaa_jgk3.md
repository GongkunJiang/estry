D/TC:? 0 tee_ta_open_session:694
D/TC:? 0 tee_ta_open_session:694
D/TC:? 0 tee_ta_open_session:719
D/TC:? 0 tee_ta_open_session:719

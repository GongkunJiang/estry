[main]soc_term.c(268)JGK
listening on port 54321
soc_term: accepted fd 4
[serve_fd]soc_term.c(216)JGK
soc_term: read fd EOF
[serve_fd]soc_term.c(263)end JGK
soc_term: accepted fd 4
[serve_fd]soc_term.c(216)JGK
D/TC:0   get_aslr_seed:1352 Cannot find valid kaslr-seed
D/TC:0   add_phys_mem:585 TEE_SHMEM_START type NSEC_SHM 0x42000000 size 0x00200000
D/TC:0   add_phys_mem:585 TA_RAM_START type TA_RAM 0x0e300000 size 0x00d00000
D/TC:0   add_phys_mem:585 VCORE_UNPG_RW_PA type TEE_RAM_RW 0x0e165000 size 0x0019b000
D/TC:0   add_phys_mem:585 VCORE_UNPG_RX_PA type TEE_RAM_RX 0x0e100000 size 0x00065000
D/TC:0   add_phys_mem:585 ROUNDDOWN(0x09040000, CORE_MMU_PGDIR_SIZE) type IO_SEC 0x09000000 size 0x00200000
D/TC:0   verify_special_mem_areas:524 No NSEC DDR memory area defined
D/TC:0   add_va_space:625 type RES_VASPACE size 0x00a00000
D/TC:0   add_va_space:625 type SHM_VASPACE size 0x02000000
D/TC:0   dump_mmap_table:732 type TEE_RAM_RX   va 0x0e100000..0x0e164fff pa 0x0e100000..0x0e164fff size 0x00065000 (smallpg)
D/TC:0   dump_mmap_table:732 type TEE_RAM_RW   va 0x0e165000..0x0e2fffff pa 0x0e165000..0x0e2fffff size 0x0019b000 (smallpg)
D/TC:0   dump_mmap_table:732 type TA_RAM       va 0x0e300000..0x0effffff pa 0x0e300000..0x0effffff size 0x00d00000 (smallpg)
D/TC:0   dump_mmap_table:732 type RES_VASPACE  va 0x0f000000..0x0f9fffff pa 0x00000000..0x009fffff size 0x00a00000 (pgdir)
D/TC:0   dump_mmap_table:732 type SHM_VASPACE  va 0x0fa00000..0x119fffff pa 0x00000000..0x01ffffff size 0x02000000 (pgdir)
D/TC:0   dump_mmap_table:732 type IO_SEC       va 0x11a00000..0x11bfffff pa 0x09000000..0x091fffff size 0x00200000 (pgdir)
D/TC:0   dump_mmap_table:732 type NSEC_SHM     va 0x11c00000..0x11dfffff pa 0x42000000..0x421fffff size 0x00200000 (pgdir)
D/TC:0   core_mmu_entry_to_finer_grained:761 xlat tables used 1 / 8
D/TC:0   core_mmu_entry_to_finer_grained:761 xlat tables used 2 / 8
D/TC:0   core_mmu_entry_to_finer_grained:761 xlat tables used 3 / 8
D/TC:0 0 malloc_add_pool:837 [malloc_add_pool]lib/libutils/isoc/bget_malloc.c(837)JGK
I/TC: 
D/TC:0 0 init_canaries:190 #Stack canaries for stack_tmp[0] with top at 0xe1aaab8
D/TC:0 0 init_canaries:190 watch *0xe1aaabc
D/TC:0 0 init_canaries:190 #Stack canaries for stack_tmp[1] with top at 0xe1ab2f8
D/TC:0 0 init_canaries:190 watch *0xe1ab2fc
D/TC:0 0 init_canaries:190 #Stack canaries for stack_tmp[2] with top at 0xe1abb38
D/TC:0 0 init_canaries:190 watch *0xe1abb3c
D/TC:0 0 init_canaries:190 #Stack canaries for stack_tmp[3] with top at 0xe1ac378
D/TC:0 0 init_canaries:190 watch *0xe1ac37c
D/TC:0 0 init_canaries:191 #Stack canaries for stack_abt[0] with top at 0xe1a3d38
D/TC:0 0 init_canaries:191 watch *0xe1a3d3c
D/TC:0 0 init_canaries:191 #Stack canaries for stack_abt[1] with top at 0xe1a4978
D/TC:0 0 init_canaries:191 watch *0xe1a497c
D/TC:0 0 init_canaries:191 #Stack canaries for stack_abt[2] with top at 0xe1a55b8
D/TC:0 0 init_canaries:191 watch *0xe1a55bc
D/TC:0 0 init_canaries:191 #Stack canaries for stack_abt[3] with top at 0xe1a61f8
D/TC:0 0 init_canaries:191 watch *0xe1a61fc
D/TC:0 0 init_canaries:193 #Stack canaries for stack_thread[0] with top at 0xe1a8238
D/TC:0 0 init_canaries:193 watch *0xe1a823c
D/TC:0 0 init_canaries:193 #Stack canaries for stack_thread[1] with top at 0xe1aa278
D/TC:0 0 init_canaries:193 watch *0xe1aa27c
E/TC:0 0 init_user_kcode:1035 [init_user_kcode]core/arch/arm/kernel/thread.c(1035)JGK
E/TC:0 0 get_excp_vect:1155 [get_excp_vect]core/arch/arm/kernel/thread.c(1155)JGK
E/TC:0 0 select_vector:1133 [select_vector]core/arch/arm/kernel/thread.c(1133)JGK
D/TC:0 0 select_vector:1135 SMCCC_ARCH_WORKAROUND_1 (0x80008000) available
D/TC:0 0 select_vector:1137 SMC Workaround for CVE-2017-5715 used
I/TC: Non-secure external DT found
D/TC:0 0 carve_out_phys_mem:285 No need to carve out 0xe100000 size 0x200000
D/TC:0 0 carve_out_phys_mem:285 No need to carve out 0xe300000 size 0xd00000
I/TC: Switching console to device: /pl011@9040000
I/TC: OP-TEE version: 2006797-dev (gcc version 9.2.1 20191025 (GNU Toolchain for the A-profile Architecture 9.2-2019.12 (arm-9.10))) #126 Thu Jan 13 05:40:08 UTC 2022 aarch64
I/TC: Primary CPU initializing
D/TC:0 0 paged_init_primary:1218 Executing at offset 0 with virtual load address 0xe100000
D/TC:0 0 call_initcalls:21 level 1 register_time_source()
D/TC:0 0 call_initcalls:21 level 1 teecore_init_pub_ram()
D/TC:0 0 call_initcalls:21 level 3 check_ta_store()
D/TC:0 0 check_ta_store:647 TA store: "Secure Storage TA"
D/TC:0 0 check_ta_store:647 TA store: "REE"
D/TC:0 0 call_initcalls:21 level 3 init_user_ta()
D/TC:0 0 call_initcalls:21 level 3 verify_pseudo_tas_conformance()
D/TC:0 0 call_initcalls:21 level 3 mobj_mapped_shm_init()
D/TC:0 0 mobj_mapped_shm_init:433 Shared memory address range: fa00000, 11a00000
D/TC:0 0 call_initcalls:21 level 3 tee_cryp_init()
E/TC:0 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
D/TC:0 0 call_initcalls:21 level 4 tee_fs_init_key_manager()
D/TC:0 0 call_initcalls:21 level 6 mobj_init()
D/TC:0 0 call_initcalls:21 level 6 default_mobj_init()
D/TC:0 0 call_finalcalls:40 level 1 release_external_dt()
I/TC: Primary CPU switching to normal world boot
I/TC: Secondary CPU 1 initializing
E/TC:1   get_excp_vect:1155 [get_excp_vect]core/arch/arm/kernel/thread.c(1155)JGK
E/TC:1   select_vector:1133 [select_vector]core/arch/arm/kernel/thread.c(1133)JGK
D/TC:1   select_vector:1135 SMCCC_ARCH_WORKAROUND_1 (0x80008000) available
D/TC:1   select_vector:1137 SMC Workaround for CVE-2017-5715 used
I/TC: Secondary CPU 1 switching to normal world boot
D/TC:1   tee_entry_exchange_capabilities:106 Dynamic shared memory is enabled
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
D/TC:1 0 core_mmu_entry_to_finer_grained:761 xlat tables used 4 / 8
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=0.JGK
D/TC:? 0 entry_open_session:355 [entry_open_session]core/arch/arm/tee/entry_std.c(355)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_open_session:695 [tee_ta_open_session]core/kernel/tee_ta_manager.c(695)JGK
D/TC:? 0 tee_ta_init_session:630 [tee_ta_init_session]core/kernel/tee_ta_manager.c(630)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:288 [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(288)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:289 Lookup pseudo TA 7011a688-ddde-4053-a5a9-7b3c4ddf13b8
D/TC:? 0 tee_ta_init_pseudo_ta_session:302 Open device.pta
D/TC:? 0 tee_ta_init_pseudo_ta_session:319 device.pta : 7011a688-ddde-4053-a5a9-7b3c4ddf13b8
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_open_session:720 [tee_ta_open_session]core/kernel/tee_ta_manager.c(720)user_ta_enter_open_session	JGK
E/TC:? 0 pseudo_ta_enter_open_session:147 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(147)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
E/TC:? 0 pseudo_ta_enter_open_session:179 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(179)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 tee_ta_open_session:744 [tee_ta_open_session]core/kernel/tee_ta_manager.c(744)end JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=1.JGK
D/TC:? 0 entry_invoke_command:424 [entry_invoke_command]core/arch/arm/tee/entry_std.c(424)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=4.JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=1.JGK
D/TC:? 0 entry_invoke_command:424 [entry_invoke_command]core/arch/arm/tee/entry_std.c(424)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=15, JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=2.JGK
D/TC:? 0 tee_ta_close_session:496 csess 0xe191a00 id 1
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_close_session:516 Destroy session
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
E/TC:? 0 pseudo_ta_enter_close_session:215 [pseudo_ta_enter_close_session]core/arch/arm/kernel/pseudo_ta.c(215)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=5.JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:0 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:0 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:0 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:0 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:0 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=0.JGK
D/TC:? 0 entry_open_session:355 [entry_open_session]core/arch/arm/tee/entry_std.c(355)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_open_session:695 [tee_ta_open_session]core/kernel/tee_ta_manager.c(695)JGK
D/TC:? 0 tee_ta_init_session:630 [tee_ta_init_session]core/kernel/tee_ta_manager.c(630)JGK
D/TC:? 0 tee_ta_init_session_with_context:590 Re-open TA 7011a688-ddde-4053-a5a9-7b3c4ddf13b8
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_open_session:720 [tee_ta_open_session]core/kernel/tee_ta_manager.c(720)user_ta_enter_open_session	JGK
E/TC:? 0 pseudo_ta_enter_open_session:147 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(147)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
E/TC:? 0 pseudo_ta_enter_open_session:179 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(179)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 tee_ta_open_session:744 [tee_ta_open_session]core/kernel/tee_ta_manager.c(744)end JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:0 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:0 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:0 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:0 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:0 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=1.JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
D/TC:? 0 entry_invoke_command:424 [entry_invoke_command]core/arch/arm/tee/entry_std.c(424)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:0 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:0 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:0 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:0 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:0 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=2.JGK
D/TC:? 0 tee_ta_close_session:496 csess 0xe191860 id 1
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_close_session:516 Destroy session
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
E/TC:? 0 pseudo_ta_enter_close_session:215 [pseudo_ta_enter_close_session]core/arch/arm/kernel/pseudo_ta.c(215)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK


# thread_std_smc_entry (refer)
[_start](asm)ENTRY(_start) optee_os/core/arch/arm/kernel/kern.ld.S
  [thread_vector_table](asm)
    [vector_std_smc_entry](asm)
      [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(73)ASM	vector_std_smc_entry		JGK
        [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
          [init_regs]core/arch/arm/kernel/thread.c(477)JGK
            thread->regs.pc = (uint64_t)thread_std_smc_entry;(asm THREAD_CTX_REGS_SP) 
          [thread_resume](asm)
            [eret_to_el0](asm)

# thread_std_smc_entry (call)
[thread_std_smc_entry](asm)
  [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(216)JGK
    [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(165)JGK
      [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(124)JGK
        [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
    [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
    [tee_entry_std]core/arch/arm/tee/entry_std.c(531)JGK
      [__tee_entry_std]core/arch/arm/tee/entry_std.c(542)arg->cmd=0.JGK
        [entry_open_session]core/arch/arm/tee/entry_std.c(355)JGK
          [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
          [tee_ta_open_session]core/kernel/tee_ta_manager.c(693)JGK
            [tee_ta_init_session]core/kernel/tee_ta_manager.c(628)JGK
              [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(283)JGK
                Lookup pseudo TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
              [tee_ta_init_user_ta_session]core/arch/arm/kernel/user_ta.c(741)utc->uctx.ctx.uuid = *uuid. JGK
                [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                [load_ldelf]core/arch/arm/kernel/user_ta.c(683)JGK
                  utc->entry_func = code_addr + ldelf_entry.
                  ldelf load address 0x40006000
                [init_with_ldelf]core/arch/arm/kernel/user_ta.c(248)call thread_enter_user_mode. JGK
                  [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1464)	JGK
                    [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1212)JGK
                    [set_ctx_regs]core/arch/arm/kernel/thread.c(1426)JGK
                    [__thread_enter_user_mode](asm)
                      [eret_to_el0](asm)
                        ...
                      [thread_excp_vect](asm)
                        [el0_sync_a64](asm)
                          [el0_svc](asm)
                            [thread_svc_handler]core/arch/arm/kernel/thread.c(1560)JGK
                              sess->ctx->ops->handle_svc(regs)
                                [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                                  [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
                                    ldelf
                            [eret_to_el0](asm)
            
# ldelf
[_ldelf_start](asm)ENTRY(_ldelf_start) optee_os/ldelf/ldelf.ld.S
  [ldelf]ldelf/main.c(133)JGK
    Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
    [sys_map_zi]ldelf/sys.c(69)JGK
      [invoke_sys_ta]ldelf/sys.c(55)_utee_open_ta_session	JGK
        res = _utee_open_ta_session(&(const TEE_UUID)PTA_SYSTEM_UUID, 0, NULL, &s, &ret_orig);
          [syscall_open_ta_session]core/tee/tee_svc.c(779)JGK
            [tee_ta_open_session]core/kernel/tee_ta_manager.c(693)JGK
              [tee_ta_init_session]core/kernel/tee_ta_manager.c(628)JGK
                [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(283)JGK
                  Lookup pseudo TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
                  Open system.pta
                  system.pta : 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
              res = ctx->ops->enter_open_session(s, param, err);
                [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(146)JGK
                  [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                  [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
              [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK

# ldelf(rpc_load)
[_ldelf_start](asm)ENTRY(_ldelf_start) optee_os/ldelf/ldelf.ld.S
  [ldelf]ldelf/main.c(133)JGK
    Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
    [sys_map_zi]ldelf/sys.c(69)JGK
    [ta_elf_load_main]ldelf/ta_elf.c(1128)JGK
      [load_main]ldelf/ta_elf.c(1065)
        [init_elf]ldelf/ta_elf.c(432)
          [sys_open_ta_bin]ldelf/sys.c(114)JGK
            [invoke_sys_ta]ldelf/sys.c(55)_utee_open_ta_session	JGK
              return _utee_invoke_ta_command(sess, 0, cmdid, params, &ret_orig);
                [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                  sess->ctx->ops->handle_svc(regs)
                    [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                      [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                        [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                          [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                          [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                            [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                            res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                              [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                  [invoke_command]core/pta/system.c(879)cmd_id=4	JGK
                                    [system_open_ta_binary]core/pta/system.c(233)
                                      Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
                                      res = binh->op->open(uuid, &binh->h);
                                        [ree_fs_ta_open]core/arch/arm/kernel/ree_fs_ta.c(131)JGK
                                          [rpc_load]core/arch/arm/kernel/ree_fs_ta.c(84)JGK
                                            [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                              [thread_rpc](asm)
                                                [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                            [thread_rpc_alloc_payload]core/arch/arm/kernel/thread_optee_smc.c(591)JGK
                                            [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                            [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                          [shdr_alloc_and_copy]core/crypto/signed_hdr.c(18)JGK
                                          [shdr_verify_signature]core/crypto/signed_hdr.c(50)JGK
                                      res=0x0
                                [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                          [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                          [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                            [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                            [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                          [copy_to_user_private]core/kernel/user_access.c(62)JGK
            [sys_map_ta_bin]ldelf/sys.c(150)JGK
              [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                    sess->ctx->ops->handle_svc(regs)
                      [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                        [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                          [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                            [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                            [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                              [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                              res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                  [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                  res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                    [invoke_command]core/pta/system.c(879)cmd_id=6	JGK
                                      [system_map_ta_binary]core/pta/system.c(364)	JGK
                                        [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                                  [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                            [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                            [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                              [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                              [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                            [copy_to_user_private]core/kernel/user_access.c(62)JGK
          [map_segments]ldelf/ta_elf.c(866)JGK
          [populate_segments]ldelf/ta_elf.c(733)JGK
            [sys_map_ta_bin]ldelf/sys.c(150)JGK
              [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                      sess->ctx->ops->handle_svc(regs)
                        [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                          [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                            [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                              [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                              [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                                [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                                res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                  [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                    [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                    res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                      [invoke_command]core/pta/system.c(879)cmd_id=6	JGK
                                        [system_map_ta_binary]core/pta/system.c(364)	JGK
                                          [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                                    [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                              [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                              [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                                [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                              [copy_to_user_private]core/kernel/user_access.c(62)JGK
              [sys_map_zi]ldelf/sys.c(70)JGK
                [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                  [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                      sess->ctx->ops->handle_svc(regs)
                        [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                          [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                            [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                              [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                              [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                                [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                                res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                  [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                    [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                    res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                      [invoke_command]core/pta/system.c(879)cmd_id=6	JGK
                                        [system_map_ta_binary]core/pta/system.c(364)	JGK
                                          [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                                    [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                              [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                              [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                                [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                              [copy_to_user_private]core/kernel/user_access.c(62)JGK
              [sys_map_zi]ldelf/sys.c(70)JGK
                [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                  [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                      sess->ctx->ops->handle_svc(regs)
                        [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                          [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                            [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                              [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                              [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                                [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                                res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                  [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                    [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                    res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                      [invoke_command]core/pta/system.c(879)cmd_id=2	JGK
                                        [system_map_zi]core/pta/system.c(132)JGK
                                          [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                                    [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                              [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                              [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                                [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                              [copy_to_user_private]core/kernel/user_access.c(62)JGK
                [sys_copy_from_ta_bin]ldelf/sys.c(191)JGK
                  [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                    [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                      sess->ctx->ops->handle_svc(regs)
                        [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                          [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                            [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                              [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                              [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                                [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                                res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                  [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                    [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                    [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)
                                      [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073975296, JGK
                                      [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073976403, JGK     
                                    res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                      [invoke_command]core/pta/system.c(879)cmd_id=7	JGK
                                    [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(866)JGK
                              [tee_ta_put_session]core/kernel/tee_ta_manager.c(171)JGK
                              [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                                [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                              [copy_to_user_private]core/kernel/user_access.c(62)JGK
            [add_dependencies]ldelf/ta_elf.c(951)JGK
            [copy_section_headers]ldelf/ta_elf.c(971)JGK
              [sys_copy_from_ta_bin]ldelf/sys.c(191)JGK
                [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
                  [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
                    sess->ctx->ops->handle_svc(regs)
                      [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                        [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                          [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                            [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                            [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                              [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                              res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                                [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                                  [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                                  [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)
                                    [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073975296, JGK
                                    [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073976403, JGK     
                                  res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                                    [invoke_command]core/pta/system.c(879)cmd_id=7	JGK
                                      [system_copy_from_ta_binary]core/pta/system.c(540)JGK
                                        [binh_copy_to]core/pta/system.c(325)start JGK
                                          res = binh->op->read(binh->h, (void *)va, num_bytes);
                                            [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(420)JGK
                                              [crypto_hash_update]core/crypto/crypto.c(88)JGK
                                              [check_digest]core/arch/arm/kernel/ree_fs_ta.c(309)JGK
                                              [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(330)JGK
                                                res = ops->open(&pobj, NULL, &fh);
                                                  [ree_fs_open]core/tee/tee_ree_fs.c(604)start JGK
                                                    [get_dirh]core/tee/tee_ree_fs.c(555)s JGK
                                                      [open_dirh]core/tee/tee_ree_fs.c(531)s JGK
                                                        [tee_fs_dirfile_open]core/tee/fs_dirfile.c(114)start JGK
                                                          res = fops->open(create, hash, NULL, NULL, &dirh->fh);
                                                            [ree_fs_open_primitive]core/tee/tee_ree_fs.c(399)start JGK
                                                              [tee_fs_rpc_open_dfh]core/tee/tee_fs_rpc.c(110)JGK
                                                                [operation_open_dfh]core/tee/tee_fs_rpc.c(77)start JGK
                                                                  [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1630)start JGK
                                                                    [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                                                  [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
                                                                  [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                    [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                      [thread_rpc](asm)
                                                                        [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                        [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                        [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                              [tee_fs_htree_open]core/tee/fs_htree.c(618)start JGK
                                                                [init_head_from_data]core/tee/fs_htree.c(323)start JGK
                                                                  [rpc_read_head]core/tee/fs_htree.c(136)JGK    * 2
                                                                    [rpc_read]core/tee/fs_htree.c(111)start JGK
                                                                      res = ht->stor->rpc_read_init(ht->stor_aux, &op, type, idx, vers, &p);
                                                                        [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
                                                                          [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
                                                                            [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1630)start JGK
                                                                              [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                                                      res = ht->stor->rpc_read_final(&op, &bytes);
                                                                        [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
                                                                          [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                            [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                              [thread_rpc](asm)
                                                                                [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                                [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                                [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                                    [get_idx_from_counter]core/tee/fs_htree.c(309) JGK
                                                                    [rpc_read_node]core/tee/fs_htree.c(145) JGK
                                                                      [rpc_read]core/tee/fs_htree.c(111)start JGK
                                                                        res = ht->stor->rpc_read_init(ht->stor_aux, &op, type, idx, vers, &p);
                                                                        [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
                                                                          [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
                                                                            [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1630)start JGK
                                                                              [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                                                      res = ht->stor->rpc_read_final(&op, &bytes);
                                                                        [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
                                                                          [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                            [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                              [thread_rpc](asm)
                                                                                [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                                [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                                [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                                  [verify_root]core/tee/fs_htree.c(553) JGK
                                                                  [init_tree_from_data]core/tee/fs_htree.c(376) JGK
                                                                  [verify_tree]core/tee/fs_htree.c(590)s JGK
                                                                    [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
                                                                      [traverse_post_order]core/tee/fs_htree.c(184)JGK
                                                                        [verify_node]core/tee/fs_htree.c(576)JGK
                                                                          [calc_node_hash]core/tee/fs_htree.c(412)JGK
                                                                            [crypto_hash_update]core/crypto/crypto.c(88)JGK
                                                            [read_dent]core/tee/fs_dirfile.c(85)start JGK
                                                              res = dirh->fops->read(dirh->fh, sizeof(struct dirfile_entry) * idx, dent, &l);
                                                                [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
                                                                  [tee_fs_htree_read_block]core/tee/fs_htree.c(881)start JGK
                                                                    res = ht->stor->rpc_read_init(ht->stor_aux, &op, TEE_FS_HTREE_TYPE_BLOCK, block_num, block_vers, &enc_block);
                                                                      [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
                                                                        [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
                                                                          [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1630)start JGK
                                                                            [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                                                    res = ht->stor->rpc_read_final(&op, &len);
                                                                      [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
                                                                        [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                          [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                            [thread_rpc](asm)
                                                                              [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                              [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                              [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                      [tee_fs_dirfile_find]core/tee/fs_dirfile.c(206) JGK
                                                        [read_dent]core/tee/fs_dirfile.c(85)start JGK
                                                          res = dirh->fops->read(dirh->fh, sizeof(struct dirfile_entry) * idx, dent, &l);
                                                            [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
                                                              [tee_fs_htree_read_block]core/tee/fs_htree.c(881)start JGK
                                                                res = ht->stor->rpc_read_init(ht->stor_aux, &op, TEE_FS_HTREE_TYPE_BLOCK, block_num, block_vers, &enc_block);
                                                                  [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
                                                                    [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
                                                                      [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1630)start JGK
                                                                        [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                                                res = ht->stor->rpc_read_final(&op, &len);
                                                                  [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
                                                                    [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                      [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                        [thread_rpc](asm)
                                                                          [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                          [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                          [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                    [put_dirh]core/tee/tee_ree_fs.c(603) JGK
                                                      [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
                                                        [close_dirh]core/tee/tee_ree_fs.c(554) JGK
                                                          [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
                                                            dirh->fops->close(dirh->fh);
                                                              [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
                                                                [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
                                                                  [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
                                                                    [free_node]core/tee/fs_htree.c(702)start JGK
                                                                [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
                                                                  [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                    [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                      [thread_rpc](asm)
                                                                        [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                        [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                        [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                                res = ops->create(&pobj, false, NULL, 0, NULL, 0, NULL, 0, &fh);
                                                  [ree_fs_create]core/tee/tee_ree_fs.c(704) JGK
                                                res = ops->write(fh, sizeof(db_hdr) + (db_hdr.nb_entries * len), hdr, len);
                                                  [ree_fs_write]core/tee/tee_ree_fs.c(768)JGK
                                                res = ops->write(fh, 0, &db_hdr, sizeof(db_hdr));
                                                ops->close(&fh);
                                                  [ree_fs_close]core/tee/tee_ree_fs.c(686)JGK
                                                    [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
                                                      [close_dirh]core/tee/tee_ree_fs.c(554) JGK
                                                        [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
                                                          dirh->fops->close(dirh->fh);
                                                            [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
                                                              [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
                                                                [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
                                                                  [free_node]core/tee/fs_htree.c(702)start JGK
                                                              [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
                                                                [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
                                                                  [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                                                    [thread_rpc](asm)
                                                                      [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                                                      [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                                                      [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                  [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(868)JGK
                              [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(146)JGK
                            [tee_ta_put_session]core/kernel/tee_ta_manager.c(172)JGK
                            [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
                              [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                              [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
                            [copy_to_user_private]core/kernel/user_access.c(62)JGK
              [save_symtab]ldelf/ta_elf.c(404)JGK
                [e64_save_symtab]ldelf/ta_elf.c(375)JGK
              [close_handle]ldelf/ta_elf.c(1006)JGK
                [sys_close_ta_bin]ldelf/sys.c(142)JGK
                  [invoke_sys_ta]ldelf/sys.c(63)call _utee_invoke_ta_command JGK
              [set_tls_offset]ldelf/ta_elf.c(1060)JGK
      [sys_map_zi]ldelf/sys.c(70)JGK
  [ta_elf_load_dependency]ldelf/ta_elf.c(1177)elf->is_main=1. JGK
  [ta_elf_relocate]ldelf/ta_elf_rel.c(613)JGK
  [ta_elf_finalize_mappings]ldelf/ta_elf.c(1198)JGK
  [ta_elf_finalize_load_main]ldelf/ta_elf.c(1160)JGK
    [ta_elf_set_init_fini_info_compat]ldelf/ta_elf.c(1700)JGK
      [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
    [ta_elf_set_elf_phdr_info]ldelf/ta_elf.c(1826)JGK
      [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
      [realloc_elf_phdr_info]ldelf/ta_elf.c(1748)JGK
  ELF (8aaaf200-2450-11e4-abe2-0002a5d5c51b) at 0x40077000
  [sys_return_cleanup]ldelf/sys.c(35)JGK
    _utee_close_ta_session(sess)
      [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=6. JGK
        [syscall_close_ta_session]core/tee/tee_svc.c(851)JGK
          [tee_ta_close_session]:495 csess 0xe191060 id 1
            [tee_ta_get_session]core/kernel/tee_ta_manager.c(217)JGK
            515 Destroy session
            [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
            ctx->ops->enter_close_session(sess);
              [pseudo_ta_enter_close_session]core/arch/arm/kernel/pseudo_ta.c(215)JGK
                [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(858) JGK
                [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(868)JGK
                








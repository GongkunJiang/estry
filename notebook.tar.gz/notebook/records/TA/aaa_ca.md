[main]soc_term.c(268)JGK
listening on port 54320
soc_term: accepted fd 4
[serve_fd]soc_term.c(216)JGK
soc_term: read fd EOF
[serve_fd]soc_term.c(263)end JGK
soc_term: accepted fd 4
[serve_fd]soc_term.c(216)JGK
NOTICE:  [bl1_main]bl1/bl1_main.c(86)JGK
NOTICE:  Booting Trusted Firmware
NOTICE:  BL1: v2.3():8ff55a9-dirty
NOTICE:  BL1: Built : 17:01:06, Dec 30 2021
NOTICE:  [bl1_load_bl2]bl1/bl1_main.c(166)JGK
NOTICE:  [load_auth_image]common/bl_common.c(242)JGK
NOTICE:  [load_auth_image_internal]common/bl_common.c(223)JGK
NOTICE:  [load_image_flush]common/bl_common.c(153)JGK
NOTICE:  [load_image]common/bl_common.c(72)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
NOTICE:  [open_fip]plat/qemu/common/qemu_io_storage.c(306)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
WARNING: [fip_dev_init]drivers/io/io_fip.c(220)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
ERROR:   [open_memmap]plat/qemu/common/qemu_io_storage.c(344)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=0. JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
NOTICE:  [is_valid_header]drivers/io/io_fip.c(91)JGK
ERROR:   [fip_dev_init]drivers/io/io_fip.c(255)JGK
WARNING: Firmware Image Package header check failed.
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=-2. JGK
ERROR:   [get_alt_image_source]plat/qemu/common/qemu_io_storage.c(420)JGK
ERROR:   [open_semihosting]plat/qemu/common/qemu_io_storage.c(361)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_size]drivers/io/io_storage.c(262)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
ERROR:   [io_dev_close]drivers/io/io_storage.c(196)JGK
NOTICE:  BL1: Booting BL2
NOTICE:  BL2: v2.3():8ff55a9-dirty
NOTICE:  BL2: Built : 17:01:06, Dec 30 2021
NOTICE:  [load_auth_image]common/bl_common.c(242)JGK
NOTICE:  [load_auth_image_internal]common/bl_common.c(223)JGK
NOTICE:  [load_image_flush]common/bl_common.c(153)JGK
NOTICE:  [load_image]common/bl_common.c(72)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
NOTICE:  [open_fip]plat/qemu/common/qemu_io_storage.c(306)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
WARNING: [fip_dev_init]drivers/io/io_fip.c(220)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
ERROR:   [open_memmap]plat/qemu/common/qemu_io_storage.c(344)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=0. JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
NOTICE:  [is_valid_header]drivers/io/io_fip.c(91)JGK
ERROR:   [fip_dev_init]drivers/io/io_fip.c(255)JGK
WARNING: Firmware Image Package header check failed.
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=-2. JGK
ERROR:   [get_alt_image_source]plat/qemu/common/qemu_io_storage.c(420)JGK
ERROR:   [open_semihosting]plat/qemu/common/qemu_io_storage.c(361)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_size]drivers/io/io_storage.c(262)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
ERROR:   [io_dev_close]drivers/io/io_storage.c(196)JGK
NOTICE:  [load_auth_image]common/bl_common.c(242)JGK
NOTICE:  [load_auth_image_internal]common/bl_common.c(223)JGK
NOTICE:  [load_image_flush]common/bl_common.c(153)JGK
NOTICE:  [load_image]common/bl_common.c(72)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
NOTICE:  [open_fip]plat/qemu/common/qemu_io_storage.c(306)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
WARNING: [fip_dev_init]drivers/io/io_fip.c(220)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
ERROR:   [open_memmap]plat/qemu/common/qemu_io_storage.c(344)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=0. JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
NOTICE:  [is_valid_header]drivers/io/io_fip.c(91)JGK
ERROR:   [fip_dev_init]drivers/io/io_fip.c(255)JGK
WARNING: Firmware Image Package header check failed.
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=-2. JGK
ERROR:   [get_alt_image_source]plat/qemu/common/qemu_io_storage.c(420)JGK
ERROR:   [open_semihosting]plat/qemu/common/qemu_io_storage.c(361)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_size]drivers/io/io_storage.c(262)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
ERROR:   [io_dev_close]drivers/io/io_storage.c(196)JGK
NOTICE:  [load_auth_image]common/bl_common.c(242)JGK
NOTICE:  [load_auth_image_internal]common/bl_common.c(223)JGK
NOTICE:  [load_image_flush]common/bl_common.c(153)JGK
NOTICE:  [load_image]common/bl_common.c(72)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
NOTICE:  [open_fip]plat/qemu/common/qemu_io_storage.c(306)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
WARNING: [fip_dev_init]drivers/io/io_fip.c(220)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
ERROR:   [open_memmap]plat/qemu/common/qemu_io_storage.c(344)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=0. JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
NOTICE:  [is_valid_header]drivers/io/io_fip.c(91)JGK
ERROR:   [fip_dev_init]drivers/io/io_fip.c(255)JGK
WARNING: Firmware Image Package header check failed.
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=-2. JGK
ERROR:   [get_alt_image_source]plat/qemu/common/qemu_io_storage.c(420)JGK
ERROR:   [open_semihosting]plat/qemu/common/qemu_io_storage.c(361)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_size]drivers/io/io_storage.c(262)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
ERROR:   [io_dev_close]drivers/io/io_storage.c(196)JGK
NOTICE:  [load_auth_image]common/bl_common.c(242)JGK
NOTICE:  [load_auth_image_internal]common/bl_common.c(223)JGK
NOTICE:  [load_image_flush]common/bl_common.c(153)JGK
NOTICE:  [load_image]common/bl_common.c(72)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
NOTICE:  [open_fip]plat/qemu/common/qemu_io_storage.c(306)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
WARNING: [fip_dev_init]drivers/io/io_fip.c(220)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(438)start JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(445)result = policy->check JGK
ERROR:   [open_memmap]plat/qemu/common/qemu_io_storage.c(344)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=0. JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
NOTICE:  [is_valid_header]drivers/io/io_fip.c(91)JGK
ERROR:   [fip_dev_init]drivers/io/io_fip.c(255)JGK
WARNING: Firmware Image Package header check failed.
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(447)result=-2. JGK
ERROR:   [get_alt_image_source]plat/qemu/common/qemu_io_storage.c(420)JGK
ERROR:   [open_semihosting]plat/qemu/common/qemu_io_storage.c(361)JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(178)start JGK
NOTICE:  [io_dev_init]drivers/io/io_storage.c(189)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
NOTICE:  [plat_get_image_source]plat/qemu/common/qemu_io_storage.c(455)end JGK
NOTICE:  [io_open]drivers/io/io_storage.c(218)JGK
ERROR:   [io_size]drivers/io/io_storage.c(262)JGK
NOTICE:  [io_read]drivers/io/io_storage.c(283)JGK
ERROR:   [io_close]drivers/io/io_storage.c(323)JGK
ERROR:   [io_dev_close]drivers/io/io_storage.c(196)JGK
NOTICE:  BL1: Booting BL31
NOTICE:  BL31: v2.3():8ff55a9-dirty
NOTICE:  BL31: Built : 10:51:02, Jan 12 2022
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
UEFI firmware (version  built at 10:30:58 on Dec 23 2021)

[=3h















































[=3h















































[=3h























EFI stub: Booting Linux Kernel...
EFI stub: Using DTB from configuration table
EFI stub: Loaded initrd from command line option
EFI stub: Exiting boot services and installing virtual address map...
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    0.000000] Booting Linux on physical CPU 0x0000000000 [0x411fd070]
[    0.000000] Linux version 5.9.0-ga1f8ac036-dirty (e0004941@user-virtual-machine) (aarch64-linux-gnu-gcc (GNU Toolchain for the A-profile Architecture 9.2-2019.12 (arm-9.10)) 9.2.1 20191025, GNU ld (GNU Toolchain for the A-profile Architecture 9.2-2019.12 (arm-9.10)) 2.33.1.20191209) #27 SMP PREEMPT Tue Jan 11 15:34:21 CST 2022
[    0.000000] Machine model: linux,dummy-virt
[    0.000000] printk: debug: skip boot console de-registration.
[    0.000000] efi: EFI v2.70 by EDK II
[    0.000000] efi: SMBIOS=0x81610000 SMBIOS 3.0=0x815f0000 MEMATTR=0x80698018 RNG=0x816cd318 MEMRESERVE=0x7e233f18 
[    0.000000] efi: seeding entropy pool
[    0.000000] cma: Reserved 32 MiB at 0x000000007e400000
[    0.000000] NUMA: No NUMA configuration found
[    0.000000] NUMA: Faking a node at [mem 0x0000000040000000-0x00000000820fffff]
[    0.000000] NUMA: NODE_DATA [mem 0x81ee2100-0x81ee3fff]
[    0.000000] Zone ranges:
[    0.000000]   DMA      [mem 0x0000000040000000-0x000000007fffffff]           
[    0.000000]   DMA32    [mem 0x0000000080000000-0x00000000820fffff]           
[    0.000000]   Normal   empty                                                 
[    0.000000] Movable zone start for each node                                 
[    0.000000] Early memory node ranges                                         
[    0.000000]   node   0: [mem 0x0000000040000000-0x0000000041ffffff]          
[    0.000000]   node   0: [mem 0x0000000042200000-0x000000007df2ffff]          
[    0.000000]   node   0: [mem 0x000000007df30000-0x000000007e22ffff]          
[    0.000000]   node   0: [mem 0x000000007e230000-0x000000008150ffff]          
[    0.000000]   node   0: [mem 0x0000000081510000-0x000000008159ffff]          
[    0.000000]   node   0: [mem 0x00000000815a0000-0x00000000815bffff]          
[    0.000000]   node   0: [mem 0x00000000815c0000-0x00000000816cffff]          
[    0.000000]   node   0: [mem 0x00000000816d0000-0x00000000820fffff]          
[    0.000000] Zeroed struct page in unavailable ranges: 672 pages              
[    0.000000] Initmem setup node 0 [mem 0x0000000040000000-0x00000000820fffff] 
[    0.000000] psci: probing for conduit method from DT.                        
[    0.000000] psci: PSCIv1.1 detected in firmware.                             
[    0.000000] psci: Using standard PSCI v0.2 function IDs                      
[    0.000000] psci: Trusted OS migration not required                          
[    0.000000] psci: SMC Calling Convention v1.2                                
[    0.000000] percpu: Embedded 23 pages/cpu s54104 r8192 d31912 u94208         
[    0.000000] Detected PIPT I-cache on CPU0                                    
[    0.000000] CPU features: detected: ARM erratum 832075                       
[    0.000000] CPU features: detected: ARM erratum 834220                       
[    0.000000] CPU features: detected: EL2 vector hardening                     
[    0.000000] CPU features: kernel page table isolation forced ON by KASLR     
[    0.000000] CPU features: detected: Kernel page table isolation (KPTI)       
[    0.000000] Speculative Store Bypass Disable mitigation not required         
[    0.000000] CPU features: detected: ARM errata 1165522, 1319367, or 1530923  
[    0.000000] Built 1 zonelists, mobility grouping on.  Total pages: 265852    
[    0.000000] Policy zone: DMA32                                               
[    0.000000] Kernel command line: console=ttyAMA0,38400 keep_bootcon root=/dev/vda2 initrd=initrd
[    0.000000] Dentry cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
[    0.000000] Inode-cache hash table entries: 131072 (order: 8, 1048576 bytes, linear)
[    0.000000] mem auto-init: stack:off, heap alloc:off, heap free:off          
[    0.000000] software IO TLB: mapped [mem 0x73070000-0x77070000] (64MB)       
[    0.000000] Memory: 901296K/1080320K available (13948K kernel code, 2284K rwdata, 7656K rodata, 5760K init, 484K bss, 146256K reserved, 32768K cma-reserved)
[    0.000000] SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1       
[    0.000000] rcu: Preemptible hierarchical RCU implementation.                
[    0.000000] rcu:     RCU event tracing is enabled.                           
[    0.000000] rcu:     RCU restricting CPUs from NR_CPUS=256 to nr_cpu_ids=2.  
[    0.000000]  Trampoline variant of Tasks RCU enabled.                        
[    0.000000] rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
[    0.000000] rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2     
[    0.000000] NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0                   
[    0.000000] GICv2m: range[mem 0x08020000-0x08020fff], SPI[80:143]            
[    0.000000] random: get_random_bytes called from start_kernel+0x310/0x4dc with crng_init=0
[    0.000000] arch_timer: cp15 timer(s) running at 62.50MHz (virt).            
[    0.000000] clocksource: arch_sys_counter: mask: 0xffffffffffffff max_cycles: 0x1cd42e208c, max_idle_ns: 881590405314 ns
[    0.000155] sched_clock: 56 bits at 62MHz, resolution 16ns, wraps every 4398046511096ns
[    0.006241] Console: colour dummy device 80x25                               
[    0.008208] Calibrating delay loop (skipped), value calculated using timer frequency.. 125.00 BogoMIPS (lpj=250000)
[    0.008341] pid_max: default: 32768 minimum: 301                             
[    0.009610] LSM: Security Framework initializing                             
[    0.010660] Mount-cache hash table entries: 4096 (order: 3, 32768 bytes, linear)
[    0.010723] Mountpoint-cache hash table entries: 4096 (order: 3, 32768 bytes, linear)
[    0.045998] rcu: Hierarchical SRCU implementation.                           
[    0.052718] Remapping and enabling EFI services.                             
[    0.056509] smp: Bringing up secondary CPUs ...                              
[    0.066707] Detected PIPT I-cache on CPU1                                    
[    0.067355] CPU1: Booted secondary processor 0x0000000001 [0x411fd070]       
[    0.069546] smp: Brought up 1 node, 2 CPUs                                   
[    0.069596] SMP: Total of 2 processors activated.                            
[    0.069648] CPU features: detected: 32-bit EL0 Support                       
[    0.069710] CPU features: detected: CRC32 instructions                       
[    0.069747] CPU features: detected: 32-bit EL1 Support                       
[    0.127828] CPU: All CPU(s) started at EL1                                   
[    0.128193] alternatives: patching kernel code                               
[    0.151314] devtmpfs: initialized                                            
[    0.162366] KASLR enabled                                                    
[    0.166640] clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
[    0.166889] futex hash table entries: 512 (order: 3, 32768 bytes, linear)    
[    0.172432] cma: CMA area reserved could not be activated                    
[    0.174808] pinctrl core: initialized pinctrl subsystem                      
[    0.188840] SMBIOS 3.0.0 present.                                            
[    0.189015] DMI: QEMU QEMU Virtual Machine, BIOS 0.0.0 02/06/2015            
[    0.198943] NET: Registered protocol family 16                               
[    0.202440] DMA: preallocated 128 KiB GFP_KERNEL pool for atomic allocations 
[    0.202618] DMA: preallocated 128 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
[    0.202731] DMA: preallocated 128 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
[    0.203117] audit: initializing netlink subsys (disabled)                    
[    0.205607] audit: type=2000 audit(0.184:1): state=initialized audit_enabled=0 res=1
[    0.211250] thermal_sys: Registered thermal governor 'step_wise'             
[    0.211305] thermal_sys: Registered thermal governor 'power_allocator'       
[    0.213252] cpuidle: using governor menu                                     
[    0.214648] hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.    
[    0.215177] ASID allocator initialised with 32768 entries                    
[    0.220763] Serial: AMBA PL011 UART driver                                   
[    0.290165] 9000000.pl011: ttyAMA0 at MMIO 0x9000000 (irq = 38, base_baud = 0) is a PL011 rev1
[    0.318985] printk: console [ttyAMA0] enabled                                
[    0.364254] HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages     
[    0.364438] HugeTLB registered 32.0 MiB page size, pre-allocated 0 pages     
[    0.364563] HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages     
[    0.364699] HugeTLB registered 64.0 KiB page size, pre-allocated 0 pages     
[    0.375544] cryptd: max_cpu_qlen set to 1000                                 
[    0.386779] ACPI: Interpreter disabled.                                      
[    0.393867] iommu: Default domain type: Translated                           
[    0.395225] vgaarb: loaded                                                   
[    0.397195] SCSI subsystem initialized                                       
[    0.400099] usbcore: registered new interface driver usbfs                   
[    0.400611] usbcore: registered new interface driver hub                     
[    0.401304] usbcore: registered new device driver usb                        
[    0.403954] pps_core: LinuxPPS API ver. 1 registered                         
[    0.404136] pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
[    0.404486] PTP clock support registered                                     
[    0.405354] EDAC MC: Ver: 3.0.0                                              
[    0.409856] Registered efivars operations                                    
[    0.414311] FPGA manager framework                                           
[    0.415153] Advanced Linux Sound Architecture Driver Initialized.            
[    0.426592] clocksource: Switched to clocksource arch_sys_counter            
[    0.428043] VFS: Disk quotas dquot_6.6.0                                     
[    0.428807] VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)   
[    0.431904] pnp: PnP ACPI: disabled                                          
[    0.527108] NET: Registered protocol family 2                                
[    0.532938] tcp_listen_portaddr_hash hash table entries: 1024 (order: 2, 16384 bytes, linear)
[    0.533328] TCP established hash table entries: 16384 (order: 5, 131072 bytes, linear)
[    0.534886] TCP bind hash table entries: 16384 (order: 6, 262144 bytes, linear)
[    0.538531] TCP: Hash tables configured (established 16384 bind 16384)       
[    0.539895] UDP hash table entries: 1024 (order: 3, 32768 bytes, linear)     
[    0.540278] UDP-Lite hash table entries: 1024 (order: 3, 32768 bytes, linear)
[    0.542276] NET: Registered protocol family 1                                
[    0.546160] RPC: Registered named UNIX socket transport module.              
[    0.546341] RPC: Registered udp transport module.                            
[    0.546440] RPC: Registered tcp transport module.                            
[    0.546527] RPC: Registered tcp NFSv4.1 backchannel transport module.        
[    0.546737] PCI: CLS 0 bytes, default 64                                     
[    0.550330] Unpacking initramfs...                                           
[    1.305677] Freeing initrd memory: 7168K                                     
[    1.310639] hw perfevents: enabled with armv8_pmuv3 PMU driver, 1 counters available
[    1.311274] kvm [1]: HYP mode not available                                  
[    1.338358] Initialise system trusted keyrings                               
[    1.340030] workingset: timestamp_bits=44 max_order=18 bucket_order=0        
[    1.360210] squashfs: version 4.0 (2009/01/31) Phillip Lougher               
[    1.363626] NFS: Registering the id_resolver key type                        
[    1.364066] Key type id_resolver registered                                  
[    1.364190] Key type id_legacy registered                                    
[    1.364733] nfs4filelayout_init: NFSv4 File Layout Driver Registering...     
[    1.366415] 9p: Installing v9fs 9p2000 file system support                   
[    1.400965] Key type asymmetric registered                                   
[    1.401692] Asymmetric key parser 'x509' registered                          
[    1.402612] Block layer SCSI generic (bsg) driver version 0.4 loaded (major 245)
[    1.403306] io scheduler mq-deadline registered                              
[    1.403862] io scheduler kyber registered                                    
[    1.436436] pl061_gpio 9030000.pl061: PL061 GPIO chip registered             
[    1.442306] pci-host-generic 4010000000.pcie: host bridge /pcie@10000000 ranges:
[    1.443084] pci-host-generic 4010000000.pcie:       IO 0x003eff0000..0x003effffff -> 0x0000000000
[    1.443649] pci-host-generic 4010000000.pcie:      MEM 0x0010000000..0x003efeffff -> 0x0010000000
[    1.443870] pci-host-generic 4010000000.pcie:      MEM 0x8000000000..0xffffffffff -> 0x8000000000
[    1.444800] pci-host-generic 4010000000.pcie: ECAM at [mem 0x4010000000-0x401fffffff] for [bus 00-ff]
[    1.446333] pci-host-generic 4010000000.pcie: PCI host bridge to bus 0000:00 
[    1.446659] pci_bus 0000:00: root bus resource [bus 00-ff]                   
[    1.446834] pci_bus 0000:00: root bus resource [io  0x0000-0xffff]           
[    1.446951] pci_bus 0000:00: root bus resource [mem 0x10000000-0x3efeffff]   
[    1.447083] pci_bus 0000:00: root bus resource [mem 0x8000000000-0xffffffffff]
[    1.448889] pci 0000:00:00.0: [1b36:0008] type 00 class 0x060000             
[    1.452102] pci 0000:00:01.0: [1af4:1005] type 00 class 0x00ff00             
[    1.453051] pci 0000:00:01.0: reg 0x10: [io  0x0000-0x001f]                  
[    1.455234] pci 0000:00:01.0: reg 0x20: [mem 0x8000000000-0x8000003fff 64bit pref]
[    1.459547] pci 0000:00:01.0: BAR 4: assigned [mem 0x8000000000-0x8000003fff 64bit pref]
[    1.459955] pci 0000:00:01.0: BAR 0: assigned [io  0x1000-0x101f]            
[    1.469006] EINJ: ACPI disabled.                                             
[    1.507162] virtio-pci 0000:00:01.0: enabling device (0005 -> 0007)          
[    1.530159] Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled          
[    1.539630] SuperH (H)SCI(F) driver initialized                              
[    1.543202] msm_serial: driver initialized                                   
[    1.551922] random: fast init done                                           
[    1.553114] random: crng init done                                           
[    1.556442] cacheinfo: Unable to detect cache hierarchy for CPU 0            
[    1.587328] loop: module loaded                                              
[    1.590735] megasas: 07.714.04.00-rc1                                        
[    1.599806] physmap-flash 4000000.flash: physmap platform flash device: [mem 0x04000000-0x07ffffff]
[    1.602082] 4000000.flash: Found 2 x16 devices at 0x0 in 32-bit bank. Manufacturer ID 0x000000 Chip ID 0x000000
[    1.602664] Intel/Sharp Extended Query Table at 0x0031                       
[    1.603905] Using buffer write method                                        
[    1.714494] libphy: Fixed MDIO Bus: probed                                   
[    1.716772] tun: Universal TUN/TAP device driver, 1.6                        
[    1.727948] thunder_xcv, ver 1.0                                             
[    1.728216] thunder_bgx, ver 1.0                                             
[    1.728474] nicpf, ver 1.0                                                   
[    1.734060] hclge is initializing                                            
[    1.734402] hns3: Hisilicon Ethernet Network Driver for Hip08 Family - version
[    1.734556] hns3: Copyright (c) 2017 Huawei Corporation.                     
[    1.735010] e1000: Intel(R) PRO/1000 Network Driver                          
[    1.735135] e1000: Copyright (c) 1999-2006 Intel Corporation.                
[    1.735449] e1000e: Intel(R) PRO/1000 Network Driver                         
[    1.735559] e1000e: Copyright(c) 1999 - 2015 Intel Corporation.              
[    1.735847] igb: Intel(R) Gigabit Ethernet Network Driver                    
[    1.735963] igb: Copyright (c) 2007-2014 Intel Corporation.                  
[    1.736226] igbvf: Intel(R) Gigabit Virtual Function Network Driver          
[    1.736359] igbvf: Copyright (c) 2009 - 2012 Intel Corporation.              
[    1.737866] sky2: driver version 1.30                                        
[    1.742261] VFIO - User Level meta-driver version: 0.3                       
[    1.749825] ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver       
[    1.750047] ehci-pci: EHCI PCI platform driver                               
[    1.750381] ehci-platform: EHCI generic platform driver                      
[    1.750962] ehci-orion: EHCI orion driver                                    
[    1.751453] ehci-exynos: EHCI Exynos driver                                  
[    1.751901] ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver           
[    1.752134] ohci-pci: OHCI PCI platform driver                               
[    1.752490] ohci-platform: OHCI generic platform driver                      
[    1.753134] ohci-exynos: OHCI Exynos driver                                  
[    1.755494] usbcore: registered new interface driver usb-storage             
[    1.767976] rtc-efi rtc-efi.0: registered as rtc0                            
[    1.769012] rtc-efi rtc-efi.0: setting system clock to 2022-01-14T07:37:46 UTC (1642145866)
[    1.771955] i2c /dev entries driver                                          
[    1.795912] sdhci: Secure Digital Host Controller Interface driver           
[    1.796061] sdhci: Copyright(c) Pierre Ossman                                
[    1.798406] Synopsys Designware Multimedia Card Interface Driver             
[    1.802545] sdhci-pltfm: SDHCI platform and OF driver helper                 
[    1.808886] ledtrig-cpu: registered to indicate activity on CPUs             
[    1.812638] SMCCC: SOC_ID: ARCH_FEATURES(ARCH_SOC_ID) returned error: fffffffffffffffd
[    1.816105] usbcore: registered new interface driver usbhid                  
[    1.816255] usbhid: USB HID core driver                                      
[    1.829658] [get_invoke_func]drivers/tee/optee/core.c(571)JGK                
[    1.829799] optee: probing for conduit method.                               
[    1.830047] [get_invoke_func]drivers/tee/optee/core.c(580)method = smc      JGK
[    1.830224] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.831283] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.831859] optee: revision 3.11 (20067976)                                  
[    1.831885] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.832609] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.834804] [tee_device_alloc]drivers/tee/tee_core.c(978)JGK                 
[    1.835030] [tee_device_alloc]drivers/tee/tee_core.c(978)JGK                 
[    1.836517] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.837255] optee: dynamic shared memory is enabled                          
[    1.837590] [optee_probe]drivers/tee/optee/core.c(711)JGK                    
[    1.837630] [optee_enumerate_devices]drivers/tee/optee/device.c(155)JGK      
[    1.837969] [tee_client_open_context]drivers/tee/tee_core.c(1194)JGK         
[    1.838260] [teedev_open]drivers/tee/tee_core.c(61)teedev->desc->ops->open(ctx). JGK
[    1.838414] [optee_open]drivers/tee/optee/core.c(233)JGK                     
[    1.838627] [__optee_enumerate_devices]drivers/tee/optee/device.c(104)JGK    
[    1.838648] [tee_client_open_session]drivers/tee/tee_core.c(1230)JGK         
[    1.838799] [optee_open_session]drivers/tee/optee/call.c(218)JGK             
[    1.839430] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.839592] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.883912] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.884375] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.894215] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.894371] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.899061] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.899219] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.906737] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.906896] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.911932] optee: initialized driver                                        
[    1.914576] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    1.914723] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    1.923335] NET: Registered protocol family 17                               
[    1.924792] 9pnet: Installing 9P2000 support                                 
[    1.925228] Key type dns_resolver registered                                 
[    1.926821] registered taskstats version 1                                   
[    1.926990] Loading compiled-in X.509 certificates                           
[    1.936471] input: gpio-keys as /devices/platform/gpio-keys/input/input0     
[    1.940504] ALSA device list:                                                
[    1.940678]   No soundcards found.                                           
[    1.944025] uart-pl011 9000000.pl011: no DMA platform data                   
[    1.999295] Freeing unused kernel memory: 5760K                              
[    2.000343] Run /init as init process                                        
Starting syslogd: OK                                                            
Starting klogd: OK                                                              
Running sysctl: OK                                                              
Saving random seed: OK                                                          
Set permissions on /dev/tee*: OK                                                
Set permissions on /dev/ion: OK                                                 
Create/set permissions on /data/tee: OK                                         
Starting tee-supplicant: INF [144] TSUP:main:699: [main]src/tee_supplicant.c(699)start	JGK
INF [144] TSUP:main:706: [main]src/tee_supplicant.c(706)pthread_mutex_init     JGK
ERR [144] TSUP:open_dev:439: [open_dev]src/tee_supplicant.c(439)JGK             
ERR [144] TSUP:open_dev:444: [open_dev]src/tee_supplicant.c(444)open start JGK  
[    3.457695] [tee_open]drivers/tee/tee_core.c(107)JGK                         
[    3.457933] [teedev_open]drivers/tee/tee_core.c(61)teedev->desc->ops->open(ctx). JGK
[    3.458070] [optee_open]drivers/tee/optee/core.c(233)JGK                     
[    3.459195] [optee_bus_scan]drivers/tee/optee/core.c(227)JGK                 
[    3.459365] [optee_enumerate_devices]drivers/tee/optee/device.c(155)JGK      
[    3.459398] [tee_client_open_context]drivers/tee/tee_core.c(1194)JGK         
[    3.459614] [teedev_open]drivers/tee/tee_core.c(61)teedev->desc->ops->open(ctx). JGK
[    3.459733] [optee_open]drivers/tee/optee/core.c(233)JGK                     
[    3.459825] [__optee_enumerate_devices]drivers/tee/optee/device.c(104)JGK    
[    3.459832] [tee_client_open_session]drivers/tee/tee_core.c(1230)JGK         
[    3.459949] [optee_open_session]drivers/tee/optee/call.c(218)JGK             
[    3.460167] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    3.460280] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [144] TSUP:open_dev:446: [open_dev]src/tee_supplicant.c(446)open end JGK    
[    3.469348] [tee_ioctl]drivers/tee/tee_core.c(858)TEE_IOC_VERSION JGK        
INF [144] TSUP:main:740: [main]src/tee_supplicant.c(740)daemon(1, 1)    JGK     
[    3.472966] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    3.473151] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
OK                                                                              
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[    3.482967] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[    3.483800] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[    3.491646] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[    3.491812] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
Starting network: OK                                                            
Starting network (udhcpc): OK                                                   
                                                                                
Welcome to Buildroot, type root or test to login                                
buildroot login: root                                                           
# optee_example_hello_world                                                     
[main]host/main.c(40)use libteec to call TA                                     
[TEEC_InitializeContext]src/tee_client_api.c(151)use libteec to call TA.       JGK
[   15.745013] [tee_open]drivers/tee/tee_core.c(107)JGK                         
[   15.745183] [teedev_open]drivers/tee/tee_core.c(61)teedev->desc->ops->open(ctx). JGK
[   15.745325] [optee_open]drivers/tee/optee/core.c(233)JGK                     
[   15.745840] [tee_ioctl]drivers/tee/tee_core.c(858)TEE_IOC_VERSION JGK        
[TEEC_OpenSession]src/tee_client_api.c(585)JGK                                  
[   15.749229] [tee_ioctl]drivers/tee/tee_core.c(870)tee_ioctl_open_session JGK 
[   15.749815] [tee_ioctl_open_session]drivers/tee/tee_core.c(544)optee_open_session start	JGK
[   15.750085] [optee_open_session]drivers/tee/optee/call.c(218)JGK             
[   15.750270] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[   15.750423] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.808125] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:spawn_thread:576: [spawn_thread]src/tee_supplicant.c(576)JGK     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:process_one_request:647: [process_one_request]src/tee_supplicant.c(647)OPTEE_MSG_RPC_CMD_SHM_ALLOC	JGK
ERR [177] TSUP:thread_main:680: [thread_main]src/tee_supplicant.c(680)JGK       
                                                                                
ERR [146] TSUP:process_alloc:377: [process_alloc]src/tee_supplicant.c(377)JGK   
ERR [146] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [146] TSUP:register_local_shm:340: [register_local_shm]src/tee_supplicant.c(340)JGK
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
[   15.826074] [tee_ioctl]drivers/tee/tee_core.c(864)TEE_IOC_SHM_REGISTER JGK   
ERR [177] TSUP:process_one_request:615: looping                                 
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.828704] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.828906] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.831081] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   15.831506] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.834889] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.841590] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   15.842073] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.844605] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.851247] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.851586] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_request:615: lERRORooping:   [opteed_smc_handler]services/s
pd/opteed/opteed_main.c(203)is_caller_non_secure=1      JGK                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.855570] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.863054] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.863374] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_oneERROR:   [op_request:teed_615: loopingsmc_handler]service
s/spd/opteed/opteed_main.c(203)is_caller_non_secure=1   JGK                     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.867387] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.872399] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   15.872752] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGKERROR:   [opteed_smc_h
andler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0     JGK     
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK[   15.875130] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
                                                                                
[   15.876181] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.881654] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.881973] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:proERRORcess_one_r:   [opteequest:615ed_smc: looping_handler]services/spd/opteed
/opteed_main.c(203)is_caller_non_secure=1       JGK                             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.884664] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.892057] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.892374] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSERROR:   [opteed_sUP:process_omc_hanne_request:dler]services/s615: pd/oloopteed/opteed_mapingin.c(203)is_caller_no
n_secure=1      JGK                                                             
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handl[   15.897314] [teer]services/spd/opteed/opteed_main.c(e_ioctl]drivers/tee/tee_c203)is_caller_non_secure=ore.c(882)TEE_0	JGK
IOC_SUPPL_RECV JGK                                                              
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.901013] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.901357] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteERR [177] ed/opTSUP:process_one_request:615: looteed_mainping.c(203)is_caller_non_sec
ure=0   JGK                                                                     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK[   15.903199] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.904878] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.906307] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.912855] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   15.913211] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.917872] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.923013] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   15.923337] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.926586] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   15.927342] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.933007] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.933357] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_nonERR [1_secure=0	JG46] TSUP:procesK
s_one_request:615: looping                                                      
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK[   15.935207] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.936841] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.938583] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.948087] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   15.948444] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGKERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is
_caller_non_secure=0    JGK                                                     
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.951892] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   15.952315] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.954351] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.962076] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.962392] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUERROR:   [P:process_one_request:61opteed_smc_handler]se5: loorvices/spd/opteed/optepinged_main.c(203
)is_caller_non_secure=1 JGK                                                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.966735] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.970607] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   15.970921] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_request:615: looERROR:ping   [opteed_smc_handler]services/spd/o
pteed/opteed_main.c(203)is_caller_non_secure=1  JGK                             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   15.974264] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   15.975042] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.979903] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   15.980239] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.982964] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   15.983793] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   15.992662] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   15.993020] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   15.997925] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.002733] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.003042] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_request:615: loopERingROR:   [o                      
pteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1 JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/s[   16.006055] [tee_pd/opteioctl]drivers/tee/tee_core.c(88ed/op2)TteedEE_IOC_SUPPL_REC_mV JGK
ain.c(203)is_caller_non_secure=0        JGK                                     
[   16.006683] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.012044] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.012361] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.016764] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.021848] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.022166] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_ERROR: re  [opteed_quest:615: loopingsmc_handler]services/spd/opteed/opteed_
main.c(203)is_caller_non_secure=1       JGK                                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.025155] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.027007] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.031253] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.031574] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUERROR:   [P:process_one_request:615: loopingopteed_smc_handler]serv
ices/spd/opteed/opteed_main.c(203)is_caller_non_secure=1        JGK             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.034672] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.035214] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
INF [146] TSUP:process_one_request:635: [process_one_request]src/tee_supplicant.c(635)OPTEE_MSG_RPC_CMD_LOAD_TA	JGK
ERR [146] TSUP:load_ta:272: [load_ta]src/tee_supplicant.c(272)JGK               
ERR [146] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [146] TSUP:get_param:210: [get_param]src/tee_supplicant.c(210)JGK           
ERR [146] TSUP:uuid_from_octets:263: [uuid_from_octets]src/tee_supplicant.c(263)JGK
ERR [146] TSUP:try_load_secure_module:84: [try_load_secure_module]src/teec_ta_load.c(84)JGK
ERR [146] TSUP:try_load_secure_module:119: Attempt to load /tmp/optee_armtz/8aaaf200-2450-11e4-abe2-0002a5d5c51b.ta
ERR [146] TSUP:try_load_secure_module:119: Attempt to load /tmp/optee_armtz/8aaaf200-2450-11e4-abe20002a5d5c51b.ta
ERR [146] TSUP:try_load_secure_module:84: [try_load_secure_module]src/teec_ta_load.c(84)JGK
ERR [146] TSUP:try_load_secure_module:119: Attempt to load /lib/optee_armtz/8aaaf200-2450-11e4-abe2-0002a5d5c51b.ta
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.048638] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
[   16.049127] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   16.056075] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:647: [process_one_request]src/tee_supplicant.c(647)OPTEE_MSG_RPC_CMD_SHM_ALLOC	JGK
ERR [177] TSUP:process_alloc:377: [process_alloc]src/tee_supplicant.c(377)JGK   
ERR [177] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [177] TSUP:register_local_shm:340: [register_local_shm]src/tee_supplicant.c(340)JGK
[   16.062741] [tee_ioctl]drivers/tee/tee_core.c(864)TEE_IOC_SHM_REGISTER JGK   
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.064231] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.064628] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.068699] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
INF [177] TSUP:process_one_request:635: [process_one_request]src/tee_supplicant.c(635)OPTEE_MSG_RPC_CMD_LOAD_TA	JGK
ERR [177] TSUP:load_ta:272: [load_ta]src/tee_supplicant.c(272)JGK               
ERR [177] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [177] TSUP:get_param:210: [get_param]src/tee_supplicant.c(210)JGK           
ERR [177] TSUP:uuid_from_octets:263: [uuid_from_octets]src/tee_supplicant.c(263)JGK
ERR [177] TSUP:try_load_secure_module:84: [try_load_secure_module]src/teec_ta_load.c(84)JGK
ERR [177] TSUP:try_load_secure_module:119: Attempt to load /tmp/optee_armtz/8aaaf200-2450-11e4-abe2-0002a5d5c51b.ta
ERR [177] TSUP:try_load_secure_module:119: Attempt to load /tmp/optee_armtz/8aaaf200-2450-11e4-abe20002a5d5c51b.ta
ERR [177] TSUP:try_load_secure_module:84: [try_load_secure_module]src/teec_ta_load.c(84)JGK
ERR [177] TSUP:try_load_secure_module:119: Attempt to load /lib/optee_armtz/8aaaf200-2450-11e4-abe2-0002a5d5c51b.ta
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.079533] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping                                 
[   16.080039] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_ERR [177] TSUP:num_waiterss_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGKmc_handler]services/spd/opteed/opteed_main.c(
203)is_caller_non_secure=1      JGK                                             
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.087346] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.087853] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.090121] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.162898] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.163329] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.167019] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.167601] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.173818] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping                                 
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.175813] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.176150] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.182861] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.183227] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.186659] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.187575] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.192977] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.193316] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [oERR [177]pteed TSUP:rea_smc_handd_request:509ler]services/s: [repd/opteed/opad_requteed_mainest]src/tee_supplicant.c(509)JGK.c(203)is_caller_non
_secure=1       JGK                                                             
[   16.195898] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.198747] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.206594] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.208666] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.208960] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.218198] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.218534] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:procERROR:ess_one_request:615: looping   [opteed_smc_hand        
ler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1        JGK     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.220955] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.222717] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.228773] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.229081] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_oneERROR: _reques  [opteed_smc_handler]set:615: loopingrvices/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
                                                                                
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=[   16.234600] [tee_0	JGK
ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK                         
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.238316] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.238691] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.241765] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.242502] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.248150] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.248470] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_request:61ERROR:   [opteed_smc_handler]services/spd/opteed/optee5: loopingd_main.c(203)is_cal
ler_non_secure=1        JGK                                                     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
[   16.251383] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_ERR [146main.c(] TSUP:read_reque203st:509: [read_)is_caller_non_request]src/secure=1	JGK
tee_supplicant.c(509)JGK                                                        
[   16.252718] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.254910] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.259552] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.259871] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_request:615: loopingERROR:   [opteed_smc_handler     
]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1   JGK             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secur[   16.264490e=0	JGK
] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK                  
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.268082] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.268415] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:proceERROR:   ss_one_reques[opteet:615: loopingd_smc_handler]s   
ervices/spd/opteed/opteed_main.c(203)is_caller_non_secure=1     JGK             
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.271767] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.273639] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.280578] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.280879] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_requestER:615ROR:: lo   [opteeopingd_smc_handler]services/spd/
opteed/opteed_main.c(203)is_caller_non_secure=1 JGK                             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.286174] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.291678] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.292019] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:processERROR:   _one_req[opteed_smcuest:615: loop_handlering]services/spd/opteed/opteed_
main.c(203)is_caller_non_secure=1       JGK                                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.295077] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.295489] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.298907] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.305667] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping                                 
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.307586] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.307859] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.314127] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.314473] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.317079] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.319051] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.323240] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.323572] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.327173] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.327602] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.333943] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.335988] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.336263] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.337991] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.346123] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.346420] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [17ERROR:   [7] TSUP:process_one_ropteeequest:615: ld_smc_handler]seoopingrvices/spd/opteed/opte
ed_main.c(203)is_caller_non_secure=1    JGK                                     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.349112] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.355766] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.358022] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.358303] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.366652] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.367003] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.369395] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.371288] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.378268] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.378601] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUERP:processROR:   [opteed_smc_handler]services/spd/op_one_requeteed/optst:615: loopingeed_main.c(2
03)is_caller_non_secure=1       JGK                                             
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.382156] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.383013] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.388772] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping                                 
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.391041] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.391319] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.397260] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK[   16.398501] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.400367] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.402678] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.408780] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.409107] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] ERROR:TSUP:proces   [s_one_reqopteed_smc_uest:615: loopinghandler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
                                                                                
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0[   	J16.414484] [tee_iGK
octl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK                          
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.418313] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.418644] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.421195] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.423042] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.427707] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.428076] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.431150] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.431593] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.434832] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.439210] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.439527] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_request:615: loERROR:   [opteeopingd_smc_handler]servi
ces/spd/opteed/opteed_main.c(203)is_caller_non_secure=1 JGK                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.443845] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.448846] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.449146] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_requestERROR:   [o:615: loopingpteed_smc_handler]services/spd/op
teed/opteed_main.c(203)is_caller_non_secure=1   JGK                             
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.453547] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.458442] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.458779] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_calle[   re/tee_core.c(41] [tee_ioctl]decrivers/teure=0	JGK
882)TEE_IOC_SUPPL_RECV JGK                                                      
[   16.462816] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.463981] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.470172] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.470489] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_no[   16.474564]n_sec [tee_ioctl]drivers/tee/tee_cure=0	JGK
ore.c(882)TEE_IOC_SUPPL_RECV JGK                                                
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.478354] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.478686] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [o[   16.481875] [tee_ioctl]drivers/tee/tpteed_smc_handler]see_core.c(882)TEEer_IOC_SUPPL_RECV JGK
vices/spd/opteed/opteed_main.c(203)is_caller_non_secure=0       JGK             
[   16.482448] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.483501] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.490401] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.490765] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/[   1op6.49teed_ma4481] [tee_ioctl]in.c(drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_R203)is_caECV JGK
ller_non_secure=0       JGK                                                     
[   16.495200] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.501875] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.502181] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:process_one_request:615: loopingERROR:   [opteed_smc_handle      
r]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1  JGK             
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.505319] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.511095] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.511443] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509E)JGKRROR:   [opteed_sm
c_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0  JGK     
[   16.514687] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.515280] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.521034] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.521490] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.526438] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.529818] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.530647] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.532912] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.534289] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.540460] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.540774] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:procesERROR:   [opteed_ss_one_requesmc_ht:615: andlloopier]services/spd/opngteed/opteed_main.c(203)is
_caller_non_secure=1    JGK                                                     
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.544767] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.549795] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.550132] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:ERRORprocess_one_request::   [opt615: loopingeed_smc_ha          
ndler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1      JGK     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.555248] [tee_ioctl]drivers/tee/tee_core.c(88ERR2)TEE_IOC_SUPPL_RECV JGK  
OR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.559241] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.559586] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]serERR [146] TSvices/spd/optUP:read_reed/opequest:509: [rteed_main.ead_rc(203equest]sr)is_callec/tee_supplicant.c(509)JGKr_non_secure=0	JGK
                                                                                
[   16.563083] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.563517] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.568803] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.569152] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
[   16.571079] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.572571] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.574817] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.580873] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.581208] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.585272] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.590276] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.590629] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_[   16main.c(.593994] [tee_ioctl203]dr)is_caliverles/tee/tee_core.c(882)r_non_secure=0	JGK
TEE_IOC_SUPPL_RECV JGK                                                          
[   16.594754] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.596007] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.602255] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.602604] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.606729] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.610901] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.611254] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.614788] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.615523] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.621734] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.622086] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.624648] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.626854] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.632433] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.632747] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_request:615:ERROR:    looping[opteed_smc_handler]servi
ces/spd/opteed/opteed_main.c(203)is_caller_non_secure=1 JGK                     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.634778] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.638290] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.643286] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [146] TSUP:process_one_request:615: looping[   16.643625] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.646841] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.647572] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.653922] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.654278] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.657341] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.663074] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.663412] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [146] TSUP:procERROR:   [ess_one_request:615: loopingopteed_smc_handler]ser 
vices/spd/opteed/opteed_main.c(203)is_caller_non_secure=1       JGK             
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(50ure=0J9)JGK
                                                                                
[   16.666935] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
[   16.667706] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.674425] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.674758] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_requeERst:615:ROR:   [ loopingopteed_smc_handler]services/spd/opteed/op
teed_main.c(203)is_caller_non_secure=1  JGK                                     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGKERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
                                                                                
[   16.679834] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:639: [process_one_request]src/tee_supplicant.c(639)OPTEE_MSG_RPC_CMD_FS	JGK
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.684017] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
ERR [177] TSUP:process_one_request:615: looping[   16.684359] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK
                                                                                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.687337] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   16.688077] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [146] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [146] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [146] TSUP:process_one_request:651: [process_one_request]src/tee_supplicant.c(651)OPTEE_MSG_RPC_CMD_SHM_FREE	JGK
ERR [146] TSUP:process_free:401: [process_free]src/tee_supplicant.c(401)JGK     
ERR [146] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [146] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.705116] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.705565] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERR [146] TSUP:process_one_request:615: looping                                 
ERR [146] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
ERR [146] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.710122] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.710950] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
ERR [177] TSUP:find_params:547: [find_params]src/tee_supplicant.c(547)JGK       
ERR [177] TSUP:num_waiters_dec:121: [num_waiters_dec]src/tee_supplicant.c(121)JGK
ERR [177] TSUP:process_one_request:651: [process_one_request]src/tee_supplicant.c(651)OPTEE_MSG_RPC_CMD_SHM_FREE	JGK
ERR [177] TSUP:process_free:401: [process_free]src/tee_supplicant.c(401)JGK     
ERR [177] TSUP:get_value:136: [get_value]src/tee_supplicant.c(136)JGK           
ERR [177] TSUP:write_response:526: [write_response]src/tee_supplicant.c(526)JGK 
[   16.776827] [tee_ioctl]drivers/tee/tee_core.c(885)TEE_IOC_SUPPL_SEND JGK     
[   16.777186] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERR [177] TSUP:process_one_request:615: loopingERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[   16.778747] [tee_ioctl_open_session]drivers/tee/tee_core.c(546)optee_open_session end	JGK
                                                                                
[main]host/main.c(78)TEEC_PARAM_TYPES   JGK                                     
Invoking TA to increment 42                                                     
ERR [177] TSUP:num_waiters_inc:107: [num_waiters_inc]src/tee_supplicant.c(107)JGK
[TEEC_InvokeCommand]src/tee_client_api.c(669)JGK                                
[   16.780368] [tee_ioctl]drivers/tee/tee_core.c(873)TEE_IOC_INVOKE JGK         
ERR [177] TSUP:read_request:509: [read_request]src/tee_supplicant.c(509)JGK     
[   16.780694] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[   16.780844] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
[   16.781186] [tee_ioctl]drivers/tee/tee_core.c(882)TEE_IOC_SUPPL_RECV JGK     
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
TA incremented value to 43                                                      
[TEEC_CloseSession]src/tee_client_api.c(653)JGK                                 
[   16.804885] [tee_ioctl]drivers/tee/tee_core.c(879)tee_ioctl_cancel JGK       
[   16.805128] [optee_do_call_with_arg]drivers/tee/optee/call.c(128)JGK         
[   16.805264] [optee_smccc_smc]drivers/tee/optee/core.c(556)JGK                
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=1	JGK
ERROR:   [opteed_smc_handler]services/spd/opteed/opteed_main.c(203)is_caller_non_secure=0	JGK
[TEEC_FinalizeContext]src/tee_client_api.c(177)JGK                              
#                                                                               

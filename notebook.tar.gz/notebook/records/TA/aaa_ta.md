I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:1 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:1 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:1 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:1 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:1 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=0.JGK
D/TC:? 0 entry_open_session:355 [entry_open_session]core/arch/arm/tee/entry_std.c(355)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_open_session:695 [tee_ta_open_session]core/kernel/tee_ta_manager.c(695)JGK
D/TC:? 0 tee_ta_init_session:630 [tee_ta_init_session]core/kernel/tee_ta_manager.c(630)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:288 [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(288)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:289 Lookup pseudo TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
D/TC:? 0 tee_ta_init_user_ta_session:741 [tee_ta_init_user_ta_session]core/arch/arm/kernel/user_ta.c(741)utc->uctx.ctx.uuid = *uuid. JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 load_ldelf:683 [load_ldelf]core/arch/arm/kernel/user_ta.c(683)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
D/TC:? 0 load_ldelf:695 [load_ldelf]core/arch/arm/kernel/user_ta.c(695)utc->entry_func = code_addr + ldelf_entry. JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
D/TC:? 0 load_ldelf:713 ldelf load address 0x40006000
D/TC:? 0 init_with_ldelf:248 [init_with_ldelf]core/arch/arm/kernel/user_ta.c(248)call thread_enter_user_mode. JGK
D/TC:? 0 thread_enter_user_mode:1467 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1467)JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
D/TC:1 0 set_ctx_regs:1428 [set_ctx_regs]core/arch/arm/kernel/thread.c(1428)JGK
D/TC:1 0 thread_enter_user_mode:1486 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1486)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:133 [ldelf]ldelf/main.c(133)s JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:134 Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:71 [sys_map_zi]ldelf/sys.c(71)s JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:56 [invoke_sys_ta]ldelf/sys.c(56)_utee_open_ta_session	JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=5. JGK
E/TC:? 0 syscall_open_ta_session:779 [syscall_open_ta_session]core/tee/tee_svc.c(779)JGK
D/TC:? 0 tee_ta_open_session:695 [tee_ta_open_session]core/kernel/tee_ta_manager.c(695)JGK
D/TC:? 0 tee_ta_init_session:630 [tee_ta_init_session]core/kernel/tee_ta_manager.c(630)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:288 [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(288)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:289 Lookup pseudo TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 tee_ta_init_pseudo_ta_session:302 Open system.pta
D/TC:? 0 tee_ta_init_pseudo_ta_session:319 system.pta : 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_open_session:720 [tee_ta_open_session]core/kernel/tee_ta_manager.c(720)user_ta_enter_open_session	JGK
E/TC:? 0 pseudo_ta_enter_open_session:147 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(147)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
E/TC:? 0 open_session:855 [open_session]core/pta/system.c(855)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
E/TC:? 0 pseudo_ta_enter_open_session:179 [pseudo_ta_enter_open_session]core/arch/arm/kernel/pseudo_ta.c(179)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 tee_ta_open_session:744 [tee_ta_open_session]core/kernel/tee_ta_manager.c(744)end JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:59 [invoke_sys_ta]ldelf/sys.c(59)_utee_open_ta_session endJGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=2	JGK
E/TC:? 0 system_map_zi:132 [system_map_zi]core/pta/system.c(132)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:92 [sys_map_zi]ldelf/sys.c(92)e JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  malloc_add_pool:837 [malloc_add_pool]lib/libutils/isoc/bget_malloc.c(837)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/LD:  ta_elf_load_main:1129 [ta_elf_load_main]ldelf/ta_elf.c(1129)s JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  load_main:1076 [load_main]ldelf/ta_elf.c(1076)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  init_elf:434 [init_elf]ldelf/ta_elf.c(434)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_open_ta_bin:116 [sys_open_ta_bin]ldelf/sys.c(116)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073823656, JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073823671, JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=4	JGK
D/TC:? 0 system_open_ta_binary:234 [system_open_ta_binary]core/pta/system.c(234)system_open_ta_binary start JGK
D/TC:? 0 system_open_ta_binary:258 Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (Secure Storage TA)
D/TC:? 0 system_open_ta_binary:260 [system_open_ta_binary]core/pta/system.c(260)binh->op->open start JGK
E/TC:? 0 ree_fs_open:613 [ree_fs_open]core/tee/tee_ree_fs.c(613)start JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 open_dirh:537 [open_dirh]core/tee/tee_ree_fs.c(537)s JGK
E/TC:? 0 tee_fs_dirfile_open:115 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(115)start JGK
E/TC:? 0 tee_fs_dirfile_open:124 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(124)open start JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_open_dfh:112 [tee_fs_rpc_open_dfh]core/tee/tee_fs_rpc.c(112)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 thread_rpc_alloc_payload:592 [thread_rpc_alloc_payload]core/arch/arm/kernel/thread_optee_smc.c(592)JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_dirfile_open:126 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(126)open end JGK
E/TC:? 0 tee_fs_dirfile_close:170 [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_dirfile_open:164 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(164)end JGK
E/TC:? 0 tee_fs_dirfile_open:115 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(115)start JGK
E/TC:? 0 tee_fs_dirfile_open:124 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(124)open start JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_create_dfh:120 [tee_fs_rpc_create_dfh]core/tee/tee_fs_rpc.c(120)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=1 JGK
E/TC:? 0 init_root_node:613 [init_root_node]core/tee/fs_htree.c(613)start JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 init_root_node:624 [init_root_node]core/tee/fs_htree.c(624)end JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_dirfile_open:126 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(126)open end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_open:164 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(164)end JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 put_dirh:603 [put_dirh]core/tee/tee_ree_fs.c(603) JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 close_dirh:554 [close_dirh]core/tee/tee_ree_fs.c(554) JGK
E/TC:? 0 tee_fs_dirfile_close:170 [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 ree_fs_open:643 [ree_fs_open]core/tee/tee_ree_fs.c(643)end JGK
E/TC:? 0 ree_fs_create:703 [ree_fs_create]core/tee/tee_ree_fs.c(703)start JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 open_dirh:537 [open_dirh]core/tee/tee_ree_fs.c(537)s JGK
E/TC:? 0 tee_fs_dirfile_open:115 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(115)start JGK
E/TC:? 0 tee_fs_dirfile_open:124 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(124)open start JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_open_dfh:112 [tee_fs_rpc_open_dfh]core/tee/tee_fs_rpc.c(112)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=0 JGK
E/TC:? 0 init_head_from_data:330 [init_head_from_data]core/tee/fs_htree.c(330)start JGK
E/TC:? 0 init_head_from_data:353 [init_head_from_data]core/tee/fs_htree.c(353) JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 get_idx_from_counter:311 [get_idx_from_counter]core/tee/fs_htree.c(311) JGK
E/TC:? 0 rpc_read_node:145 [rpc_read_node]core/tee/fs_htree.c(145) JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 init_head_from_data:372 [init_head_from_data]core/tee/fs_htree.c(372)end JGK
E/TC:? 0 verify_root:556 [verify_root]core/tee/fs_htree.c(556)start JGK
E/TC:? 0 verify_root:568 [verify_root]core/tee/fs_htree.c(568)end authenc_decrypt_final JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 init_tree_from_data:378 [init_tree_from_data]core/tee/fs_htree.c(378)start JGK
E/TC:? 0 init_tree_from_data:404 [init_tree_from_data]core/tee/fs_htree.c(404)end JGK
E/TC:? 0 verify_tree:594 [verify_tree]core/tee/fs_htree.c(594)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 verify_node:576 [verify_node]core/tee/fs_htree.c(576)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 verify_tree:605 [verify_tree]core/tee/fs_htree.c(605)end JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_dirfile_open:126 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(126)open end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_open:164 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(164)end JGK
E/TC:? 0 open_dirh:543 [open_dirh]core/tee/tee_ree_fs.c(543)e JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_create_dfh:120 [tee_fs_rpc_create_dfh]core/tee/tee_fs_rpc.c(120)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=1 JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 init_root_node:613 [init_root_node]core/tee/fs_htree.c(613)start JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 init_root_node:624 [init_root_node]core/tee/fs_htree.c(624)end JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 ree_fs_create:761 [ree_fs_create]core/tee/tee_ree_fs.c(761)end JGK
E/TC:? 0 ree_fs_read:363 [ree_fs_read]core/tee/tee_ree_fs.c(363)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 ree_fs_read:369 [ree_fs_read]core/tee/tee_ree_fs.c(369)end JGK
E/TC:? 0 ree_fs_close:686 [ree_fs_close]core/tee/tee_ree_fs.c(686)JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 close_dirh:554 [close_dirh]core/tee/tee_ree_fs.c(554) JGK
E/TC:? 0 tee_fs_dirfile_close:170 [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
D/TC:? 0 system_open_ta_binary:262 res=0xffff0008
D/TC:? 0 system_open_ta_binary:258 Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
D/TC:? 0 system_open_ta_binary:260 [system_open_ta_binary]core/pta/system.c(260)binh->op->open start JGK
E/TC:? 0 ree_fs_ta_open:131 [ree_fs_ta_open]core/arch/arm/kernel/ree_fs_ta.c(131)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 rpc_load:84 [rpc_load]core/arch/arm/kernel/ree_fs_ta.c(84)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 thread_rpc_alloc_payload:592 [thread_rpc_alloc_payload]core/arch/arm/kernel/thread_optee_smc.c(592)JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
D/TC:? 0 shdr_alloc_and_copy:18 [shdr_alloc_and_copy]core/crypto/signed_hdr.c(18)JGK
D/TC:? 0 shdr_verify_signature:50 [shdr_verify_signature]core/crypto/signed_hdr.c(50)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
D/TC:? 0 system_open_ta_binary:262 res=0x0
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_ta_bin:152 [sys_map_ta_bin]ldelf/sys.c(152)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=6	JGK
D/TC:? 0 system_map_ta_binary:369 [system_map_ta_binary]core/pta/system.c(369)start	JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 binh_copy_to:325 [binh_copy_to]core/pta/system.c(325)start JGK
E/TC:? 0 binh_copy_to:353 [binh_copy_to]core/pta/system.c(353) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:? 0 binh_copy_to:355 [binh_copy_to]core/pta/system.c(355)read done JGK
E/TC:? 0 binh_copy_to:360 [binh_copy_to]core/pta/system.c(360)end JGK
D/TC:? 0 system_map_ta_binary:520 [system_map_ta_binary]core/pta/system.c(520)end	JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  map_segments:867 [map_segments]ldelf/ta_elf.c(867)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  populate_segments:733 [populate_segments]ldelf/ta_elf.c(733)START JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=33. JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_ta_bin:152 [sys_map_ta_bin]ldelf/sys.c(152)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=6	JGK
D/TC:? 0 system_map_ta_binary:369 [system_map_ta_binary]core/pta/system.c(369)start	JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 binh_copy_to:325 [binh_copy_to]core/pta/system.c(325)start JGK
E/TC:? 0 binh_copy_to:353 [binh_copy_to]core/pta/system.c(353) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:? 0 binh_copy_to:355 [binh_copy_to]core/pta/system.c(355)read done JGK
E/TC:? 0 binh_copy_to:360 [binh_copy_to]core/pta/system.c(360)end JGK
D/TC:? 0 system_map_ta_binary:520 [system_map_ta_binary]core/pta/system.c(520)end	JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:71 [sys_map_zi]ldelf/sys.c(71)s JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=2	JGK
E/TC:? 0 system_map_zi:132 [system_map_zi]core/pta/system.c(132)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:92 [sys_map_zi]ldelf/sys.c(92)e JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_copy_from_ta_bin:193 [sys_copy_from_ta_bin]ldelf/sys.c(193)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1074053120, JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1074054227, JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=7	JGK
D/TC:? 0 system_copy_from_ta_binary:543 [system_copy_from_ta_binary]core/pta/system.c(543)JGK
D/TC:? 0 system_copy_from_ta_binary:556 [system_copy_from_ta_binary]core/pta/system.c(556)return binh_copy_to JGK
E/TC:? 0 binh_copy_to:325 [binh_copy_to]core/pta/system.c(325)start JGK
E/TC:? 0 binh_copy_to:336 [binh_copy_to]core/pta/system.c(336) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:? 0 binh_copy_to:353 [binh_copy_to]core/pta/system.c(353) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:? 0 binh_copy_to:355 [binh_copy_to]core/pta/system.c(355)read done JGK
E/TC:? 0 binh_copy_to:360 [binh_copy_to]core/pta/system.c(360)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  populate_segments:862 [populate_segments]ldelf/ta_elf.c(862)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  add_dependencies:951 [add_dependencies]ldelf/ta_elf.c(951)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  copy_section_headers:971 [copy_section_headers]ldelf/ta_elf.c(971)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_copy_from_ta_bin:193 [sys_copy_from_ta_bin]ldelf/sys.c(193)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073822128, JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=1073823215, JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=7	JGK
D/TC:? 0 system_copy_from_ta_binary:543 [system_copy_from_ta_binary]core/pta/system.c(543)JGK
D/TC:? 0 system_copy_from_ta_binary:556 [system_copy_from_ta_binary]core/pta/system.c(556)return binh_copy_to JGK
E/TC:? 0 binh_copy_to:325 [binh_copy_to]core/pta/system.c(325)start JGK
E/TC:? 0 binh_copy_to:336 [binh_copy_to]core/pta/system.c(336) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:? 0 binh_copy_to:353 [binh_copy_to]core/pta/system.c(353) JGK
E/TC:? 0 ree_fs_ta_read:435 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(435)start JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 check_digest:309 [check_digest]core/arch/arm/kernel/ree_fs_ta.c(309)JGK
E/TC:? 0 check_update_version:330 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(330)start JGK
E/TC:? 0 check_update_version:346 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(346)start open JGK
E/TC:? 0 ree_fs_open:613 [ree_fs_open]core/tee/tee_ree_fs.c(613)start JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 open_dirh:537 [open_dirh]core/tee/tee_ree_fs.c(537)s JGK
E/TC:? 0 tee_fs_dirfile_open:115 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(115)start JGK
E/TC:? 0 tee_fs_dirfile_open:124 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(124)open start JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_open_dfh:112 [tee_fs_rpc_open_dfh]core/tee/tee_fs_rpc.c(112)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=0 JGK
E/TC:? 0 init_head_from_data:330 [init_head_from_data]core/tee/fs_htree.c(330)start JGK
E/TC:? 0 init_head_from_data:353 [init_head_from_data]core/tee/fs_htree.c(353) JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 get_idx_from_counter:311 [get_idx_from_counter]core/tee/fs_htree.c(311) JGK
E/TC:? 0 rpc_read_node:145 [rpc_read_node]core/tee/fs_htree.c(145) JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 init_head_from_data:372 [init_head_from_data]core/tee/fs_htree.c(372)end JGK
E/TC:? 0 verify_root:556 [verify_root]core/tee/fs_htree.c(556)start JGK
E/TC:? 0 verify_root:568 [verify_root]core/tee/fs_htree.c(568)end authenc_decrypt_final JGK
E/TC:? 0 init_tree_from_data:378 [init_tree_from_data]core/tee/fs_htree.c(378)start JGK
E/TC:? 0 init_tree_from_data:404 [init_tree_from_data]core/tee/fs_htree.c(404)end JGK
E/TC:? 0 verify_tree:594 [verify_tree]core/tee/fs_htree.c(594)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 verify_node:576 [verify_node]core/tee/fs_htree.c(576)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 verify_tree:605 [verify_tree]core/tee/fs_htree.c(605)end JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_dirfile_open:126 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(126)open end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_open:164 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(164)end JGK
E/TC:? 0 open_dirh:543 [open_dirh]core/tee/tee_ree_fs.c(543)e JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 put_dirh:603 [put_dirh]core/tee/tee_ree_fs.c(603) JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 close_dirh:554 [close_dirh]core/tee/tee_ree_fs.c(554) JGK
E/TC:? 0 tee_fs_dirfile_close:170 [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 ree_fs_open:643 [ree_fs_open]core/tee/tee_ree_fs.c(643)end JGK
E/TC:? 0 check_update_version:348 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(348)end open JGK
E/TC:? 0 check_update_version:353 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(353)start create JGK
E/TC:? 0 ree_fs_create:703 [ree_fs_create]core/tee/tee_ree_fs.c(703)start JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 open_dirh:537 [open_dirh]core/tee/tee_ree_fs.c(537)s JGK
E/TC:? 0 tee_fs_dirfile_open:115 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(115)start JGK
E/TC:? 0 tee_fs_dirfile_open:124 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(124)open start JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_open_dfh:112 [tee_fs_rpc_open_dfh]core/tee/tee_fs_rpc.c(112)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=0 JGK
E/TC:? 0 init_head_from_data:330 [init_head_from_data]core/tee/fs_htree.c(330)start JGK
E/TC:? 0 init_head_from_data:353 [init_head_from_data]core/tee/fs_htree.c(353) JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 rpc_read_head:136 [rpc_read_head]core/tee/fs_htree.c(136)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 get_idx_from_counter:311 [get_idx_from_counter]core/tee/fs_htree.c(311) JGK
E/TC:? 0 rpc_read_node:145 [rpc_read_node]core/tee/fs_htree.c(145) JGK
E/TC:? 0 rpc_read:111 [rpc_read]core/tee/fs_htree.c(111)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 rpc_read:129 [rpc_read]core/tee/fs_htree.c(129)end JGK
E/TC:? 0 init_head_from_data:372 [init_head_from_data]core/tee/fs_htree.c(372)end JGK
E/TC:? 0 verify_root:556 [verify_root]core/tee/fs_htree.c(556)start JGK
E/TC:? 0 verify_root:568 [verify_root]core/tee/fs_htree.c(568)end authenc_decrypt_final JGK
E/TC:? 0 init_tree_from_data:378 [init_tree_from_data]core/tee/fs_htree.c(378)start JGK
E/TC:? 0 init_tree_from_data:404 [init_tree_from_data]core/tee/fs_htree.c(404)end JGK
E/TC:? 0 verify_tree:594 [verify_tree]core/tee/fs_htree.c(594)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 verify_node:576 [verify_node]core/tee/fs_htree.c(576)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 verify_tree:605 [verify_tree]core/tee/fs_htree.c(605)end JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_dirfile_open:126 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(126)open end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_open:164 [tee_fs_dirfile_open]core/tee/fs_dirfile.c(164)end JGK
E/TC:? 0 open_dirh:543 [open_dirh]core/tee/tee_ree_fs.c(543)e JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 ree_fs_open_primitive:403 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(403)start JGK
E/TC:? 0 tee_fs_rpc_create_dfh:120 [tee_fs_rpc_create_dfh]core/tee/tee_fs_rpc.c(120)JGK
E/TC:? 0 operation_open_dfh:78 [operation_open_dfh]core/tee/tee_fs_rpc.c(78)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_svc_storage_create_filename_dfh:135 [tee_svc_storage_create_filename_dfh]core/tee/tee_svc_storage.c(135)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 operation_open_dfh:103 [operation_open_dfh]core/tee/tee_fs_rpc.c(103)end JGK
E/TC:? 0 tee_fs_htree_open:632 [tee_fs_htree_open]core/tee/fs_htree.c(632)start create=1 JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 init_root_node:613 [init_root_node]core/tee/fs_htree.c(613)start JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 init_root_node:624 [init_root_node]core/tee/fs_htree.c(624)end JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_open:684 [tee_fs_htree_open]core/tee/fs_htree.c(684)end JGK
E/TC:? 0 ree_fs_open_primitive:440 [ree_fs_open_primitive]core/tee/tee_ree_fs.c(440)end JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 tee_fs_dirfile_find:207 [tee_fs_dirfile_find]core/tee/fs_dirfile.c(207) JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:1 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:1 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:1 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 ree_fs_create:761 [ree_fs_create]core/tee/tee_ree_fs.c(761)end JGK
E/TC:? 0 check_update_version:355 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(355)end create JGK
E/TC:? 0 check_update_version:358 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(358)start write JGK
E/TC:? 0 ree_fs_write:768 [ree_fs_write]core/tee/tee_ree_fs.c(768)JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 put_dirh:603 [put_dirh]core/tee/tee_ree_fs.c(603) JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 check_update_version:360 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(360)end write JGK
E/TC:? 0 check_update_version:410 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(410)start write JGK
E/TC:? 0 ree_fs_write:768 [ree_fs_write]core/tee/tee_ree_fs.c(768)JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 put_dirh:603 [put_dirh]core/tee/tee_ree_fs.c(603) JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 check_update_version:413 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(413)end write JGK
E/TC:? 0 check_update_version:418 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(418)start write JGK
E/TC:? 0 ree_fs_write:768 [ree_fs_write]core/tee/tee_ree_fs.c(768)JGK
E/TC:? 0 get_dirh:562 [get_dirh]core/tee/tee_ree_fs.c(562)s JGK
E/TC:? 0 get_dirh:575 [get_dirh]core/tee/tee_ree_fs.c(575)e JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 read_dent:85 [read_dent]core/tee/fs_dirfile.c(85)start JGK
E/TC:? 0 ree_fs_read_primitive:301 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(301)start JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 ree_fs_read_primitive:352 [ree_fs_read_primitive]core/tee/tee_ree_fs.c(352)end JGK
E/TC:? 0 read_dent:94 [read_dent]core/tee/fs_dirfile.c(94)end JGK
E/TC:? 0 ree_fs_write_primitive:376 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(376)start JGK
E/TC:? 0 ree_fs_write_primitive:394 [ree_fs_write_primitive]core/tee/tee_ree_fs.c(394)end out_of_place_write JGK
E/TC:? 0 tee_fs_htree_read_block:885 [tee_fs_htree_read_block]core/tee/fs_htree.c(885)start JGK
E/TC:? 0 ree_fs_rpc_read_init:219 [ree_fs_rpc_read_init]core/tee/tee_ree_fs.c(219)JGK
E/TC:? 0 tee_fs_rpc_read_init:140 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(140)start JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 tee_fs_rpc_read_init:162 [tee_fs_rpc_read_init]core/tee/tee_fs_rpc.c(162)end JGK
E/TC:? 0 tee_fs_rpc_read_final:169 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(169)start JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_rpc_read_final:174 [tee_fs_rpc_read_final]core/tee/tee_fs_rpc.c(174)end JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 tee_fs_htree_read_block:927 [tee_fs_htree_read_block]core/tee/fs_htree.c(927)end JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:780 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(780)start JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 htree_sync_node_to_storage:722 [htree_sync_node_to_storage]core/tee/fs_htree.c(722)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 calc_node_hash:412 [calc_node_hash]core/tee/fs_htree.c(412)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 htree_sync_node_to_storage:758 [htree_sync_node_to_storage]core/tee/fs_htree.c(758)rpc_write_node JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:798 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(798)update_root JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:803 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(803)rpc_write_head JGK
E/TC:? 0 tee_fs_rpc_write_init:182 [tee_fs_rpc_write_init]core/tee/tee_fs_rpc.c(182)JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1631 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1631)start JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 thread_rpc_shm_cache_alloc:1675 [thread_rpc_shm_cache_alloc]core/arch/arm/kernel/thread.c(1675)end JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:807 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(807)rpc_write_head JGK
E/TC:? 0 tee_fs_htree_sync_to_storage:815 [tee_fs_htree_sync_to_storage]core/tee/fs_htree.c(815)end JGK
E/TC:? 0 put_dirh:603 [put_dirh]core/tee/tee_ree_fs.c(603) JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 check_update_version:420 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(420)end write JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 ree_fs_close:686 [ree_fs_close]core/tee/tee_ree_fs.c(686)JGK
E/TC:? 0 put_dirh_primitive:581 [put_dirh_primitive]core/tee/tee_ree_fs.c(581) JGK
E/TC:? 0 close_dirh:554 [close_dirh]core/tee/tee_ree_fs.c(554) JGK
E/TC:? 0 tee_fs_dirfile_close:170 [tee_fs_dirfile_close]core/tee/fs_dirfile.c(170) JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 ree_fs_close_primitive:446 [ree_fs_close_primitive]core/tee/tee_ree_fs.c(446)JGK
E/TC:? 0 tee_fs_htree_close:711 [tee_fs_htree_close]core/tee/fs_htree.c(711)JGK
E/TC:? 0 htree_traverse_post_order:209 [htree_traverse_post_order]core/tee/fs_htree.c(209)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 traverse_post_order:184 [traverse_post_order]core/tee/fs_htree.c(184)JGK
E/TC:? 0 free_node:702 [free_node]core/tee/fs_htree.c(702)start JGK
E/TC:? 0 free_node:705 [free_node]core/tee/fs_htree.c(705)end JGK
E/TC:? 0 tee_fs_rpc_close:126 [tee_fs_rpc_close]core/tee/tee_fs_rpc.c(126)JGK
E/TC:? 0 operation_commit:28 [operation_commit]core/tee/tee_fs_rpc.c(28)JGK
E/TC:? 0 thread_rpc_cmd:481 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(481)JGK
E/TC:? 0 thread_rpc_cmd:496 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(496)asm thread_rpc start .JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 thread_rpc_cmd:498 [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(498)asm thread_rpc end .JGK
E/TC:? 0 check_update_version:428 [check_update_version]core/arch/arm/kernel/ree_fs_ta.c(428)end JGK
E/TC:? 0 ree_fs_ta_read:516 [ree_fs_ta_read]core/arch/arm/kernel/ree_fs_ta.c(516)end JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:? 0 binh_copy_to:355 [binh_copy_to]core/pta/system.c(355)read done JGK
E/TC:? 0 binh_copy_to:360 [binh_copy_to]core/pta/system.c(360)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  save_symtab:404 [save_symtab]ldelf/ta_elf.c(404)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  e64_save_symtab:375 [e64_save_symtab]ldelf/ta_elf.c(375)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  close_handle:1006 [close_handle]ldelf/ta_elf.c(1006)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_close_ta_bin:144 [sys_close_ta_bin]ldelf/sys.c(144)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=5	JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  set_tls_offset:1060 [set_tls_offset]ldelf/ta_elf.c(1060)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:71 [sys_map_zi]ldelf/sys.c(71)s JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:64 [invoke_sys_ta]ldelf/sys.c(64)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 syscall_invoke_ta_command:859 [syscall_invoke_ta_command]core/tee/tee_svc.c(859)start JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:187 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(187)start JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 copy_in_param:59 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(59)start JGK
D/TC:? 0 copy_in_param:103 [copy_in_param]core/arch/arm/kernel/pseudo_ta.c(103)end JGK
D/TC:? 0 invoke_command:887 [invoke_command]core/pta/system.c(887)cmd_id=2	JGK
E/TC:? 0 system_map_zi:132 [system_map_zi]core/pta/system.c(132)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 pseudo_ta_enter_invoke_cmd:209 [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(209)end JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 mobj_put_wipe:158 [mobj_put_wipe]core/arch/arm/include/mm/mobj.h(158)JGK
E/TC:? 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 copy_to_user_private:62 [copy_to_user_private]core/kernel/user_access.c(62)JGK
D/TC:? 0 syscall_invoke_ta_command:917 [syscall_invoke_ta_command]core/tee/tee_svc.c(917)end JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:92 [sys_map_zi]ldelf/sys.c(92)e JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/LD:  ta_elf_load_main:1152 [ta_elf_load_main]ldelf/ta_elf.c(1152)e JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_load_dependency:1178 [ta_elf_load_dependency]ldelf/ta_elf.c(1178)elf->is_main=1. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_relocate:613 [ta_elf_relocate]ldelf/ta_elf_rel.c(613)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_finalize_mappings:1199 [ta_elf_finalize_mappings]ldelf/ta_elf.c(1199)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_finalize_load_main:1161 [ta_elf_finalize_load_main]ldelf/ta_elf.c(1161)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_set_init_fini_info_compat:1701 [ta_elf_set_init_fini_info_compat]ldelf/ta_elf.c(1701)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_resolve_sym:157 [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_set_elf_phdr_info:1827 [ta_elf_set_elf_phdr_info]ldelf/ta_elf.c(1827)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_resolve_sym:157 [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  realloc_elf_phdr_info:1749 [realloc_elf_phdr_info]ldelf/ta_elf.c(1749)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:168 ELF (8aaaf200-2450-11e4-abe2-0002a5d5c51b) at 0x4003f000
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_return_cleanup:35 [sys_return_cleanup]ldelf/sys.c(35)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=6. JGK
D/TC:? 0 syscall_close_ta_session:851 [syscall_close_ta_session]core/tee/tee_svc.c(851)JGK
D/TC:? 0 tee_ta_close_session:496 csess 0xe191060 id 1
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_close_session:516 Destroy session
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
E/TC:? 0 pseudo_ta_enter_close_session:215 [pseudo_ta_enter_close_session]core/arch/arm/kernel/pseudo_ta.c(215)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_return_cleanup:41 [sys_return_cleanup]ldelf/sys.c(41)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
E/TC:? 0 tee_svc_sys_return_helper:428 [tee_svc_sys_return_helper]core/arch/arm/tee/arch_svc.c(428)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_open_session:720 [tee_ta_open_session]core/kernel/tee_ta_manager.c(720)user_ta_enter_open_session	JGK
D/TC:? 0 user_ta_enter_open_session:294 [user_ta_enter_open_session]core/arch/arm/kernel/user_ta.c(294)JGK
D/TC:? 0 user_ta_enter:152 [user_ta_enter]core/arch/arm/kernel/user_ta.c(152)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 thread_enter_user_mode:1467 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1467)JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
D/TC:0 0 set_ctx_regs:1428 [set_ctx_regs]core/arch/arm/kernel/thread.c(1428)JGK
D/TC:0 0 thread_enter_user_mode:1486 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1486)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:48 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(48)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __utee_entry:375 lib/libutee/arch/arm/user_ta_entry.c(375)[__utee_entry]JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  entry_open_session:309 [entry_open_session]lib/libutee/arch/arm/user_ta_entry.c(309)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_add_session:197 [ta_header_add_session]lib/libutee/arch/arm/user_ta_entry.c(197)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_get_session:185 [ta_header_get_session]lib/libutee/arch/arm/user_ta_entry.c(185)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_CreateEntryPoint:39 has been called
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_get_session:185 [ta_header_get_session]lib/libutee/arch/arm/user_ta_entry.c(185)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  from_utee_params:276 [from_utee_params]lib/libutee/arch/arm/user_ta_entry.c(276)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_save_params:174 [ta_header_save_params]lib/libutee/arch/arm/user_ta_entry.c(174)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  entry_open_session:325 [entry_open_session]lib/libutee/arch/arm/user_ta_entry.c(325)TA_OpenSessionEntryPoint start. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_OpenSessionEntryPoint:69 has been called
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: JGK, Hello World!
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  entry_open_session:328 [entry_open_session]lib/libutee/arch/arm/user_ta_entry.c(328)TA_OpenSessionEntryPoint end. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  to_utee_params:246 [to_utee_params]lib/libutee/arch/arm/user_ta_entry.c(246)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_save_params:174 [ta_header_save_params]lib/libutee/arch/arm/user_ta_entry.c(174)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:59 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(59)_utee_return start. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
E/TC:? 0 tee_svc_sys_return_helper:428 [tee_svc_sys_return_helper]core/arch/arm/tee/arch_svc.c(428)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
E/TC:? 0 tee_ta_open_session:744 [tee_ta_open_session]core/kernel/tee_ta_manager.c(744)end JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 crypto_hash_update:88 [crypto_hash_update]core/crypto/crypto.c(88)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_suspend:871 [thread_state_suspend]core/arch/arm/kernel/thread.c(871)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(70)ASM	thread_resume_from_rpc		JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:0 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:0 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:0 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:0 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:0 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=1.JGK
D/TC:? 0 entry_invoke_command:424 [entry_invoke_command]core/arch/arm/tee/entry_std.c(424)JGK
D/TC:? 0 copy_in_params:176 [copy_in_params]core/arch/arm/tee/entry_std.c(176)JGK
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_invoke_command:754 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(754)start JGK
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 tee_ta_invoke_command:777 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(777)enter_invoke_cmd JGK
D/TC:? 0 user_ta_enter_invoke_cmd:302 [user_ta_enter_invoke_cmd]core/arch/arm/kernel/user_ta.c(302)JGK
D/TC:? 0 user_ta_enter:152 [user_ta_enter]core/arch/arm/kernel/user_ta.c(152)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 thread_enter_user_mode:1467 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1467)JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
D/TC:0 0 set_ctx_regs:1428 [set_ctx_regs]core/arch/arm/kernel/thread.c(1428)JGK
D/TC:0 0 thread_enter_user_mode:1486 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1486)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:48 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(48)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __utee_entry:375 lib/libutee/arch/arm/user_ta_entry.c(375)[__utee_entry]JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  entry_invoke_command:352 [entry_invoke_command]lib/libutee/arch/arm/user_ta_entry.c(352)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_get_session:185 [ta_header_get_session]lib/libutee/arch/arm/user_ta_entry.c(185)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  from_utee_params:276 [from_utee_params]lib/libutee/arch/arm/user_ta_entry.c(276)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_save_params:174 [ta_header_save_params]lib/libutee/arch/arm/user_ta_entry.c(174)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  inc_value:106 has been called
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Got value: 42 from NW
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Increase value to: 43
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  to_utee_params:246 [to_utee_params]lib/libutee/arch/arm/user_ta_entry.c(246)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_save_params:174 [ta_header_save_params]lib/libutee/arch/arm/user_ta_entry.c(174)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:59 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(59)_utee_return start. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
E/TC:? 0 tee_svc_sys_return_helper:428 [tee_svc_sys_return_helper]core/arch/arm/tee/arch_svc.c(428)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 tee_ta_invoke_command:791 [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(791)end JGK
D/TC:? 0 tee_ta_put_session:173 [tee_ta_put_session]core/kernel/tee_ta_manager.c(173)JGK
D/TC:? 0 copy_out_param:278 [copy_out_param]core/arch/arm/tee/entry_std.c(278)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(74)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(559)thread_resume start
D/TC:0 0 __thread_std_smc_entry:217 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(217)JGK
D/TC:0 0 std_smc_entry:166 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(166)JGK
E/TC:0 0 map_cmd_buffer:125 [map_cmd_buffer]core/arch/arm/kernel/thread_optee_smc.c(125)JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
E/TC:0 0 mobj_get_va:45 [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
D/TC:0 0 tee_entry_std:532 [tee_entry_std]core/arch/arm/tee/entry_std.c(532)JGK
D/TC:0 0 __tee_entry_std:543 [__tee_entry_std]core/arch/arm/tee/entry_std.c(543)arg->cmd=2.JGK
D/TC:? 0 tee_ta_close_session:496 csess 0xe191860 id 1
D/TC:? 0 tee_ta_get_session:218 [tee_ta_get_session]core/kernel/tee_ta_manager.c(218)JGK
D/TC:? 0 tee_ta_close_session:516 Destroy session
D/TC:? 0 tee_ta_set_busy:140 [tee_ta_set_busy]core/kernel/tee_ta_manager.c(140)JGK
E/TC:? 0 tee_ta_try_set_busy:100 [tee_ta_try_set_busy]core/kernel/tee_ta_manager.c(100)JGK
D/TC:? 0 user_ta_enter:152 [user_ta_enter]core/arch/arm/kernel/user_ta.c(152)JGK
D/TC:? 0 tee_ta_push_current_session:859 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(859)start JGK
D/TC:? 0 tee_ta_push_current_session:864 [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(864)end JGK
D/TC:? 0 thread_enter_user_mode:1467 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1467)JGK
E/TC:0 0 thread_get_ctx_regs:1214 [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1214)JGK
D/TC:0 0 set_ctx_regs:1428 [set_ctx_regs]core/arch/arm/kernel/thread.c(1428)JGK
D/TC:0 0 thread_enter_user_mode:1486 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1486)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:48 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(48)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __utee_entry:375 lib/libutee/arch/arm/user_ta_entry.c(375)[__utee_entry]JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_get_session:185 [ta_header_get_session]lib/libutee/arch/arm/user_ta_entry.c(185)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Goodbye!
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_DestroyEntryPoint:50 [TA_DestroyEntryPoint]hello_world_ta.c(50)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_DestroyEntryPoint:51 has been called
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  ta_header_save_params:174 [ta_header_save_params]lib/libutee/arch/arm/user_ta_entry.c(174)JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
E/TA:  __ta_entry:59 [__ta_entry]/home/e0004941/Desktop/1223/out/optee_os/out/arm/export-ta_arm64/src/user_ta_header.c(59)_utee_return start. JGK
D/TC:? 0 thread_svc_handler:1562 [thread_svc_handler]core/arch/arm/kernel/thread.c(1562)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
E/TC:? 0 tee_svc_sys_return_helper:428 [tee_svc_sys_return_helper]core/arch/arm/tee/arch_svc.c(428)JGK
D/TC:? 0 tee_ta_pop_current_session:869 [tee_ta_pop_current_session]core/kernel/tee_ta_manager.c(869)JGK
D/TC:? 0 tee_ta_clear_busy:147 [tee_ta_clear_busy]core/kernel/tee_ta_manager.c(147)JGK
D/TC:? 0 destroy_context:295 [destroy_context]core/kernel/tee_ta_manager.c(295)JGK
D/TC:? 0 destroy_context:296 Destroy TA ctx (0xe191800)
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:? 0 mobj_put:145 [mobj_put]core/arch/arm/include/mm/mobj.h(145)JGK
E/TC:0 0 thread_get_tmp_sp:707 [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
E/TC:0 0 thread_state_free:818 [thread_state_free]core/arch/arm/kernel/thread.c(818)JGK


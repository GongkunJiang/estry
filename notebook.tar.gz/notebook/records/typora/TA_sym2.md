# __resolve_sym

总结: 根据符号类型st_type派生符号的虚拟地址val

```c
resolve_sym_helper(hash, name, val, elf, false /* !weak_ok */)
static TEE_Result resolve_sym_helper(uint32_t hash, const char *name, vaddr_t *val, struct ta_elf *elf, bool weak_ok)
```

## 1. 检查入参的有效性

```c
/* Macros for accessing the fields of st_info. */
#define ELF64_ST_BIND(info)    ((info) >> 4)
#define ELF64_ST_TYPE(info)    ((info) & 0xf)

__resolve_sym(elf, ELF64_ST_BIND(sym[n].st_info), ELF64_ST_TYPE(sym[n].st_info),
					  sym[n].st_shndx, sym[n].st_name, sym[n].st_value, name, val, weak_ok)
static bool __resolve_sym(struct ta_elf *elf, unsigned int st_bind, unsigned int st_type, size_t st_shndx,
			  size_t st_name, size_t st_value, const char *name, vaddr_t *val, bool weak_ok)
```

### st_name&name	

- st_name符号名字索引: 非零&没有越界.
- name动态链接目标的名字(字符串): 与动态符号表指向的外部符号字符串一致.

```c
if (!st_name)
    return false;
if (st_name > elf->dynstr_size)
    err(TEE_ERROR_BAD_FORMAT, "Symbol name out of range");
if (strcmp(name, elf->dynstr + st_name))
		return false;
```

### st_bind&st_shndx

- st_bind符号约束: STB_GLOBAL|STB_WEAK; 并且当约束为STB_WEAK且符号节索引无效时，直接返回真.
- st_shndx符号节索引: 符号节索引无效（未定义、未命中、不相关）或退出（索引存在其他地方）时返回假。

```c
/* Symbol Binding - ELFNN_ST_BIND - st_info */
#define	STB_GLOBAL	1	/* Global symbol */
#define	STB_WEAK	2	/* like global - lower precedence */
/* Special section indexes. */
#define SHN_UNDEF       0    /* Undefined, missing, irrelevant. */
#define SHN_XINDEX  0xffff    /* Escape -- index stored elsewhere. */
bool bind_ok = false;
if (st_bind == STB_GLOBAL || (weak_ok && st_bind == STB_WEAK))
    bind_ok = true;
if (!bind_ok)
    return false;
if (st_bind == STB_WEAK && st_shndx == SHN_UNDEF) {	/* st_shndx: Section index of symbol. */
    if (val)
        *val = 0;
    return true;
}
if (st_shndx == SHN_UNDEF || st_shndx == SHN_XINDEX)
    return false;
```

## 2. 根据符号类型派生符号的虚拟地址

### st_type&st_value

1. 未定义类型|数据对象|函数对象: 先判断有效性，再计算出虚拟地址
2. 线程局部数据对象: 虚拟地址即为符号值

```c
/* Symbol type - ELFNN_ST_TYPE - st_info */
#define STT_NOTYPE  0  /* Unspecified type. */
#define STT_OBJECT  1  /* Data object. */
#define STT_FUNC  2  /* Function. */
#define STT_TLS    6  /* TLS(Thread Local Storage) object. */
switch (st_type) {
	case STT_NOTYPE:
	case STT_OBJECT:
	case STT_FUNC:
		if (st_value > (elf->max_addr - elf->load_addr))
			err(TEE_ERROR_BAD_FORMAT,
			    "Symbol location out of range");
		if (val)
			*val = st_value + elf->load_addr;
		break;
	case STT_TLS:
		if (val)
			*val = st_value;
		break;
	default:
		err(TEE_ERROR_NOT_SUPPORTED, "Symbol type not supported");
	}
```

# resolve_sym_helper

总结:  根据elf->is_32bit确定动态符号表elf->dynsymtab的转换类型, 用elf->hashtab快速解析外部符号索引值n. 然后从sym[n] 加载值, 用于调用__resolve_sym得到符号的虚拟地址.

```c
ta_elf_resolve_sym(arg->dlsym.symbol, &arg->dlsym.val, NULL, elf);
TEE_Result ta_elf_resolve_sym(const char *name, vaddr_t *val, struct ta_elf **found_elf, struct ta_elf *elf)
```

## 1. 初始化hashtab

DT HASH哈希表，快速解析外部符号

```c
uint32_t *hashtab = elf->hashtab;/* DT_HASH hash table for faster resolution of external symbols */
uint32_t nbuckets = hashtab[0];
uint32_t nchains = hashtab[1];
uint32_t *bucket = &hashtab[2];
uint32_t *chain = &bucket[nbuckets];
size_t n = 0;
```

## 2. 判断is_32bit

从Elf32_Ehdr/Elf64_Ehdr初始化, 解析步骤类似.

## 3. Elf64_Sym

我们正在从 sym[n] 加载值，稍后将用于加载某些内容。

幽灵Vi模式, 需要覆盖指数避免预测.

### st_info

用于计算符号类型和约束的信息

```c
Elf64_Sym *sym = elf->dynsymtab;

for (n = bucket[hash % nbuckets]; n; n = chain[n]) {
    if (n >= nchains || n >= elf->num_dynsyms)
        err(TEE_ERROR_BAD_FORMAT, "Index out of range");
	// returns |n|, if it is < size, or 0 if |n| is >= size.
    n = confine_array_index(n, elf->num_dynsyms);
    if (__resolve_sym(elf,
                      ELF64_ST_BIND(sym[n].st_info),//符号约束
                      ELF64_ST_TYPE(sym[n].st_info),//符号类型
                      sym[n].st_shndx,//符号节索引
                      sym[n].st_name,//符号名字索引
                      sym[n].st_value, name, val, weak_ok)){
        return TEE_SUCCESS;
    }
}
```

# ta_elf_resolve_sym

总结:  在elf中寻找叫name的符号, 或者所有的模块(elf为空).

- 先找全局符号，再找较弱的.
- 如果val不为0，就接收符号值.
- 如果found_elf不为0，在符号处接收模块.

```c
arg->ret = dlsym_entry(arg);
TEE_Result dlsym_entry(struct dl_entry_arg *arg)
```

## 1. 计算name的哈希

直接由移位、与、异或、取反等运算逐位派生出哈希.

```c
// uint32_t hash = elf_hash(name);
static uint32_t elf_hash(const char *name)
{
	const unsigned char *p = (const unsigned char *)name;
	uint32_t h = 0;
	uint32_t g = 0;

	while (*p) {
		h = (h << 4) + *p++;
		g = h & 0xf0000000;
		if (g)
			h ^= g >> 24;
		h &= ~g;
	}
	return h;
}
```

## 2. elf非空

在elf中寻找叫name的符号, 先找全局符号，再找较弱的.

```c
if (elf) {
    /* Search global symbols */
    if (!resolve_sym_helper(hash, name, val, elf,
                            false /* !weak_ok */))
        goto success;
    /* Search weak symbols */
    if (!resolve_sym_helper(hash, name, val, elf,
                            true /* weak_ok */))
        goto success;
}
```

## 3. elf为空

遍历main_elf_queue, 寻找所有的模块.

```c
TAILQ_FOREACH(elf, &main_elf_queue, link) {
    if (!resolve_sym_helper(hash, name, val, elf,
                            false /* !weak_ok */))
        goto success;
    if (!resolve_sym_helper(hash, name, val, elf,
                            true /* weak_ok */))
        goto success;
}
```

## 4. found_elf

如果found_elf不为0，在符号处接收模块.

```c
success:
	if (found_elf)
		*found_elf = elf;
	return TEE_SUCCESS;
```

# dlsym_entry

总结:  先根据*arg*->dlsym.uuid调用ta_elf_find_elf匹配elf, 再调用ta_elf_resolve_sym找elf中叫*arg*->dlsym.symbol的符号. 将符号的虚拟地址存入*arg*->dlsym.val. 

```c
//res = call_ldelf_dlsym(utc, uuid, sym, maxlen, &va);
//res = thread_enter_user_mode((vaddr_t)arg, 0, 0, 0, usr_stack, utc->dl_entry_func, is_arm32, &panicked, &panic_code);
static void __noreturn dl_entry(struct dl_entry_arg *arg) 
```

## 1. 匹配elf

ta_elf_find_elf遍历main_elf_queue, 寻找与arg->dlsym.uuid匹配的elf.

```c
struct ta_elf *elf = NULL;
	TEE_UUID zero = { };
	if (memcmp(&arg->dlsym.uuid, &zero, sizeof(zero))) {// if(arg->dlsym.uuid)
		elf = ta_elf_find_elf(&arg->dlsym.uuid);
		if (!elf)
			return TEE_ERROR_ITEM_NOT_FOUND;
	}
```

## 2. 解析val

找elf中叫*arg*->dlsym.symbol的符号. 并将符号的虚拟地址存入*arg*->dlsym.val. 

```c
return ta_elf_resolve_sym(arg->dlsym.symbol, &arg->dlsym.val, NULL, elf);
```

# dl_entry

总结:  根据arg->cmd调用dlopen_entry/dlsym_entry

```c
// res = thread_enter_user_mode((vaddr_t)arg, 0, 0, 0, usr_stack, utc->dl_entry_func, is_arm32, &panicked, &panic_code);
static void __noreturn dl_entry(struct dl_entry_arg *arg)
{
	switch (arg->cmd) {
	case LDELF_DL_ENTRY_DLOPEN:
		arg->ret = dlopen_entry(arg);
		break;
	case LDELF_DL_ENTRY_DLSYM:
		arg->ret = dlsym_entry(arg);
		break;
	default:
		arg->ret = TEE_ERROR_NOT_SUPPORTED;
	}

	sys_return_cleanup();
}
```

# call_ldelf_dlsym

总结:  根据调用入参初始化arg, 用thread_enter_user_mode调dl_entry,得到符号虚拟地址存arg->dlsym.val, 最后用入参val接收.

```c
return system_dlsym(s, param_types, params);
static TEE_Result system_dlsym(struct tee_ta_session *cs, uint32_t param_types, TEE_Param params[TEE_NUM_PARAMS])
```

## 1. 初始化arg

```c
uaddr_t usr_stack = utc->ldelf_stack_ptr;// Stack pointer used for dumping address mappings and stack trace
struct dl_entry_arg *arg = NULL;// argument for ldelf_arg::dl_entry()
size_t len = strnlen(sym, maxlen);
usr_stack -= ROUNDUP(sizeof(*arg) + len + 1, STACK_ALIGNMENT);
arg = (struct dl_entry_arg *)usr_stack;
memset(arg, 0, sizeof(*arg));// 0初始化
arg->cmd = LDELF_DL_ENTRY_DLSYM;// dl_entry根据arg->cmd调用dlopen_entry/dlsym_entry
arg->dlsym.uuid = *uuid;// ta_elf_find_elf遍历main_elf_queue, 寻找与arg->dlsym.uuid匹配的elf.
memcpy(arg->dlsym.symbol, sym, len);//Copy len bytes of sym to arg->dlsym.symbol.
arg->dlsym.symbol[len] = '\0';
```

## 2. thread_enter_user_mode

thread_enter_user_mode执行过程中会调utc->dl_entry_func, 即dl_entry.

```c
res = thread_enter_user_mode((vaddr_t)arg, 0, 0, 0,
				     usr_stack, utc->dl_entry_func,
				     is_arm32, &panicked, &panic_code);
if (panicked) {
    EMSG("ldelf dl_entry function panicked");
    abort_print_current_ta();
    res = TEE_ERROR_TARGET_DEAD;
}
if (!res) {
    res = arg->ret;
    if (!res)
        *val = arg->dlsym.val;
}

return res;
```

# system_dlsym

总结:  用call_ldelf_dlsym得到符号虚拟地址val,并将其转换为32位, 用params[2].value接收.

```c
res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
static TEE_Result invoke_command(void *sess_ctx, uint32_t cmd_id, uint32_t param_types, TEE_Param params[TEE_NUM_PARAMS])
```

## 1. 初始化入参

```c
struct user_ta_ctx *utc = NULL;
const char *sym = NULL;
TEE_UUID *uuid = NULL;
size_t maxlen = 0;
vaddr_t va = 0;//接收符号虚拟地址存

uuid = params[0].memref.buffer;//匹配elf
sym = params[1].memref.buffer;// sym名字
maxlen = params[1].memref.size;
utc = to_user_ta_ctx(cs->ctx);// TA context
```

## 2. call_ldelf_dlsym

根据调用入参初始化arg, 用thread_enter_user_mode调dl_entry,得到符号虚拟地址存arg->dlsym.val, 最后用入参val接收.

```c
s = tee_ta_pop_current_session();
res = call_ldelf_dlsym(utc, uuid, sym, maxlen, &va);
tee_ta_push_current_session(s);
```

## 3. reg_pair_from_64

将虚拟地址转换为32位，用params[2].value接收

```c
if (!res)
	reg_pair_from_64(va, &params[2].value.a, &params[2].value.b);

static inline void reg_pair_from_64(uint64_t val, uint32_t *reg0,
				    uint32_t *reg1)
{
	*reg0 = val >> 32;
	*reg1 = val;
}
```

# dlsym

总结:  查找符号"os_test_shlib_dl_add"并返回其虚拟地址.

```c
return ta_entry_call_lib_dl(nParamTypes, pParams);//TA_OS_TEST_CMD_CALL_LIB_DL
    add_func = dlsym(handle, "os_test_shlib_dl_add");	
        res = invoke_system_pta(PTA_SYSTEM_DLSYM, param_types, params);
            return TEE_InvokeTACommand(sess, TEE_TIMEOUT_INFINITE, cmd_id, param_types, params, NULL);
                    res = _utee_invoke_ta_command((uintptr_t)session, cancellationRequestTimeout, commandID, &up, &ret_origin);

syscall_invoke_ta_command
	called_sess = tee_ta_get_session((uint32_t)ta_sess, true, &utc->open_sessions);
	res = tee_ta_invoke_command(&ret_o, called_sess, &clnt_id, cancel_req_to, cmd_id, &param);
		res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);//pseudo_ta_enter_invoke_cmd
			res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
				return system_dlsym(s, param_types, params);
```

## 1. 初始化params

用param_types指定params[4]参数类型，并存入uuid和symbol.

```c
TEE_Param params[TEE_NUM_PARAMS] = { };//#define TEE_NUM_PARAMS  4
struct dl_handle *h = handle;
uint32_t param_types = 0;

param_types = TEE_PARAM_TYPES(TEE_PARAM_TYPE_MEMREF_INPUT,// params[0].memref INPUT	uuid
                              TEE_PARAM_TYPE_MEMREF_INPUT,// params[1].memref INPUT	symbol
                              TEE_PARAM_TYPE_VALUE_OUTPUT,// params[2].value OUTPUT	val
                              TEE_PARAM_TYPE_NONE);// params[3] NONE

params[0].memref.buffer = &h->uuid;
params[0].memref.size = sizeof(h->uuid);
params[1].memref.buffer = (void *)symbol;
params[1].memref.size = strlen(symbol) + 1;
```

## 2. 获取va

invoke_system_pta系统调用system_dlsym获取符号va, 用params[2].value接收.

```c
res = invoke_system_pta(PTA_SYSTEM_DLSYM, param_types, params);
```

## 3. reg_pair_to_64

reg_pair_to_64将va转为64位并返回

```c
if (!res)
		ptr = (void *)(vaddr_t)reg_pair_to_64(params[2].value.a,
						      params[2].value.b);
return ptr;
```

# ta_entry_call_lib_dl

总结:  测试两种情况下（是否打开静态TA）加载外部符号的功能是否正常

```c
TA_InvokeCommandEntryPoint(void *pSessionContext, uint32_t nCommandID, uint32_t nParamTypes, TEE_Param pParams[4])
    case TA_OS_TEST_CMD_CALL_LIB_DL:
		return ta_entry_call_lib_dl(nParamTypes, pParams);
	case TA_OS_TEST_CMD_CALL_LIB_DL_PANIC:
		return ta_entry_call_lib_dl_panic(nParamTypes, pParams);
```

## 1. handle

dlopen打开静态TA(SHLIBNAME = libos_test_dl) , dlsym返回符号"os_test_shlib_dl_add"虚拟地址, 然后测试其功能是否正常

```c
/* The MODE argument to `dlopen' contains one of the following: */
#define RTLD_NOW	0x00002	/* Immediate function call binding.  */
/* If the following bit is set in the MODE argument to `dlopen',
   the symbols of the loaded object and its dependencies are made
   visible as if the object were linked directly into the program.  */
#define RTLD_GLOBAL	0x00100
/* Do not delete object when closed.  */
#define RTLD_NODELETE	0x01000

handle = dlopen("b3091a65-9751-4784-abf7-0298a7cc35ba",
			RTLD_NOW | RTLD_GLOBAL | RTLD_NODELETE);
if (!handle)
    return TEE_ERROR_GENERIC;

add_func = dlsym(handle, "os_test_shlib_dl_add");
if (!add_func)
    goto err;
if (add_func(3, 4) != 7)
    goto err;
```

## 2. hnull

dlopen不打开静态TA(SHLIBNAME = libos_test_dl) , dlsym返回符号"os_test_shlib_dl_add"虚拟地址, 然后测试其功能是否正常

```c
hnull = dlopen(NULL, RTLD_NOW | RTLD_GLOBAL | RTLD_NODELETE);
if (!hnull)
    goto err;

add_func = dlsym(hnull, "os_test_shlib_dl_add");
if (!add_func)
    goto err;
if (add_func(5, 6) != 11)
    goto err;
```

# xtest_tee_test_1022

```c
# xtest 1022
[main]xtest_main.c(118)
    tee_res = xtest_teec_ctx_init();
		return TEEC_InitializeContext(xtest_tee_name, &xtest_teec_ctx);
	[Do_ADBG_RunSuite]adbg/src/adbg_run.c(55)
		[ADBG_RunSuite]adbg/src/adbg_run.c(114)
        	xtest_tee_test_1022// case_def->Run_fp(Case_p);
        		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL, NULL, &ret_orig)
        		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL_PANIC, NULL, &ret_orig)
    xtest_teec_ctx_deinit();
		TEEC_FinalizeContext(&xtest_teec_ctx);
```


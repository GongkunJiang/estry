# qemu

```sh
cd /home/e0004941/Desktop/qemu/linux
tar -zvcf crypto1108.tar.gz crypto
# tar -zvxf crypto1108.tar.gz
cp /home/e0004941/Desktop/shaoxie/eswin_bsp/kernel/common/crypto .

cd /home/e0004941/Desktop/shaoxie/external/boringssl
mma

cp /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/system/bin/test_fips /home/e0004941/Desktop/qemu/out-br/target/
cd /home/e0004941/Desktop/qemu/build
make -f qemu_v8.mk -j100 buildroot # all buildroot linux
make -f qemu_v8.mk run-only


cd /home/e0004941/Desktop/shaoxie/external/boringssl/src/util/fipstools/cavp/
aarch64-linux-gnu-gcc util/fipstools/cavp/test_fips.c -L/home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/vendor/apex/com.android.vndk.current.on_vendor/lib/ -lcrypto -I/home/e0004941/Desktop/shaoxie/external/boringssl/src/include -o test_fips


aarch64-linux-gnu-gcc util/fipstools/cavp/test_fips.c -L/home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/vendor/apex/com.android.vndk.current.on_vendor/lib/ -lcrypto -I/home/e0004941/Desktop/shaoxie/external/boringssl/src/include -o test_fips
```



# e_afalg.c



# e_afalg.h



## engine

![image-20211028112312867](/home/e0004941/.config/Typora/typora-user-images/image-20211028112312867.png)

![image-20211028133533236](/home/e0004941/.config/Typora/typora-user-images/image-20211028133533236.png)

```c
#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})
```

# test

## self_check

./src/crypto/fipsmodule/self_check/self_check.c

# error

## Kotlin

```sh
warning: some JAR files in the classpath have the Kotlin Runtime library bundled into them. This may cause difficult to debug problems if there's a different version of the Kotlin Runtime library in the classpath. Consider removing these libraries from the classpath
out/soong/.intermediates/frameworks/base/packages/SettingsLib/SettingsLib/android_common/turbine-combined/SettingsLib.jar: warning: library has Kotlin runtime bundled into it
out/soong/.intermediates/prebuilts/tools/common/m2/kotlinx-coroutines-core/android_common/turbine-combined/kotlinx-coroutines-core.jar: warning: library has Kotlin runtime bundled into it
ninja: build stopped: subcommand failed.
11:41:13 ninja failed with: exit status 1
```

handle

```sh
c܉[  139.074439]  show_stack+0x24/0x30rm out/soong/.intermediates/frameworks/base/packages/SettingsLib/SettingsLib/android_common/turbine-combined/SettingsLib.jar
rm out/soong/.intermediates/prebuilts/tools/common/m2/kotlinx-coroutines-core/android_common/turbine-combined/kotlinx-coroutines-core.jar
```

## socket.h

```sh
FAILED: out/soong/.intermediates/external/boringssl/libcrypto/windows_x86_64_static/obj/external/boringssl/src/crypto/afalg/afalg.o
PWD=/proc/self/cwd prebuilts/clang/host/linux-x86/clang-r383902b/bin/clang -c -Wno-enum-compare -Wno-enum-compare-switch -Wno-null-pointer-arithmetic -Wno-null-dereference -Wno-pointer-compare -Wno-xor-used-as-pow -Wno-final-dtor-non-final-class  -DUSE_MINGW -DWIN32_LEAN_AND_MEAN -Wno-unused-parameter -D__STDC_FORMAT_MACROS -D__STDC_CONSTANT_MACROS -D__USE_MINGW_ANSI_STDIO=1 -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -D_FILE_OFFSET_BITS=64 --sysroot prebuilts/gcc/linux-x86/host/x86_64-w64-mingw32-4.8/x86_64-w64-mingw32 -m64 -DANDROID -fmessage-length=0 -W -Wall -Wno-unused -Winit-self -Wpointer-arith -no-canonical-prefixes -DNDEBUG -UDEBUG -fno-exceptions -Wno-multichar -O2 -g -fno-strict-aliasing -Werror=date-time -Werror=pragma-pack -Werror=pragma-pack-suspicious-include -fdebug-prefix-map=/proc/self/cwd= -D__compiler_offsetof=__builtin_offsetof -faddrsig -Werror=int-conversion -fexperimental-new-pass-manager -Wno-reserved-id-macro -Wno-unused-command-line-argument -fcolor-diagnostics -Wno-sign-compare -Wno-defaulted-function-deleted -Wno-inconsistent-missing-override -Wno-c99-designator -ftrivial-auto-var-init=zero -enable-trivial-auto-var-init-zero-knowing-it-will-be-removed-from-clang   -target x86_64-pc-windows-gnu -Bprebuilts/gcc/linux-x86/host/x86_64-w64-mingw32-4.8/x86_64-w64-mingw32/bin  -Iexternal/boringssl/src/include -Iexternal/boringssl/src/include -Iexternal/boringssl/src/crypto -Iexternal/boringssl -Iexternal/libcxx/include -Iexternal/libcxxabi/include -fvisibility=hidden -DBORINGSSL_SHARED_LIBRARY -DBORINGSSL_ANDROID_SYSTEM -DOPENSSL_SMALL -D_XOPEN_SOURCE=700 -Werror -Wno-unused-parameter -DBORINGSSL_IMPLEMENTATION -DOPENSSL_NO_ASM -std=gnu99 -std=c99 -Isystem/core/include -Isystem/media/audio/include -Ihardware/libhardware/include -Ihardware/libhardware_legacy/include -Ihardware/ril/include -Iframeworks/native/include -Iframeworks/native/opengl/include -Iframeworks/av/include -isystem prebuilts/gcc/linux-x86/host/x86_64-w64-mingw32-4.8/x86_64-w64-mingw32/include -Ilibnativehelper/include_jni -Werror=int-to-pointer-cast -Werror=pointer-to-int-cast -Werror=fortify-source -Werror=address-of-temporary -Werror=return-type -Wno-tautological-constant-compare -Wno-tautological-type-limit-compare -Wno-reorder-init-list -Wno-implicit-int-float-conversion -Wno-int-in-bool-context -Wno-sizeof-array-div -Wno-tautological-overlap-compare -Wno-deprecated-copy -Wno-range-loop-construct -Wno-misleading-indentation -Wno-zero-as-null-pointer-constant -Wno-deprecated-anon-enum-enum-conversion -Wno-deprecated-enum-enum-conversion -Wno-string-compare -Wno-enum-enum-conversion -Wno-enum-float-conversion -Wno-pessimizing-move -MD -MF out/soong/.intermediates/external/boringssl/libcrypto/windows_x86_64_static/obj/external/boringssl/src/crypto/afalg/afalg.o.d -o out/soong/.intermediates/external/boringssl/libcrypto/windows_x86_64_static/obj/external/boringssl/src/crypto/afalg/afalg.o external/boringssl/src/crypto/afalg/afalg.c
external/boringssl/src/crypto/engine/e_afalg.c:11:10: fatal error: 'sys/socket.h' file not found
#include <sys/socket.h>
         ^~~~~~~~~~~~~~
1 error generated.
17:57:54 ninja failed with: exit status 1
```

/home/e0004941/Desktop/shaoxie/external/boringssl/src/include/openssl/cipher.h

![image-20211028175205279](/home/e0004941/.config/Typora/typora-user-images/image-20211028175205279.png)

```sh
FAILED: out/soong/.intermediates/external/boringssl/libcrypto

android_arm_armv7-a-neon_cortex-a15_shared
android_recovery_arm_armv7-a-neon_cortex-a15_shared
android_vendor.30_arm_armv7-a-neon_cortex-a15_shared
windows_x86_64_static
linux_glibc_x86_static
android_arm_armv7-a-neon_cortex-a15_shared_com.android.conscrypt
android_arm_armv7-a-neon_cortex-a15_sdk_shared
linux_glibc_x86_static_com.android.art.host
linux_glibc_x86_64_static
linux_glibc_x86_64_static_com.android.art.host

obj/external/boringssl/src/crypto/bio/afalg.o
```

### use hongkong

```c
// src/crypto/bio/internal.h
#include <openssl/base.h>
// #if defined(_WIN32)
// #define OPENSSL_WINDOWS
// #endif
#if !defined(OPENSSL_WINDOWS)
#if defined(OPENSSL_PNACL)

#if !defined(OPENSSL_WINDOWS) && !defined(OPENSSL_PNACL)

#endif  // !WINDOWS && !PNACL
```



## cleanup

```sh
external/boringssl/src/crypto/afalg/afalg.c:1028:21: error: incompatible function pointer types assigning to 'void (*)(EVP_CIPHER_CTX *)' (aka 'void (*)(struct evp_cipher_ctx_st *)') from 'int (*)(EVP_CIPHER_CTX *)' (aka 'int (*)(struct evp_cipher_ctx_st *)') [-Werror,-Wincompatible-function-pointer-types]
    cipher->cleanup = cleanup;
                    ^ ~~~~~~~
1 error generated.
09:14:15 ninja failed with: exit status 1
```

handle: change from int to void

## libcrypto

```shell
error: VNDK library: libcrypto's ABI has INCOMPATIBLE CHANGES Please check compatibility report at: out/soong/.intermediates/external/boringssl/libcrypto/android_vendor.30_arm_armv7-a-neon_cortex-a15_shared/libcrypto.so.abidiff

error: Please update ABI references with: $ANDROID_BUILD_TOP/development/vndk/tools/header-checker/utils/create_reference_dumps.py  -l libcrypto
09:48:34 ninja failed with: exit status 1
```

handle

```sh
export ANDROID_BUILD_TOP=/home/e0004941/Desktop/shaoxie
echo $ANDROID_BUILD_TOP
$ANDROID_BUILD_TOP/development/vndk/tools/header-checker/utils/create_reference_dumps.py  -l libcrypto
```

error

```sh
[ 92% 252/273] including vendor/socionext/sc1401aj1/aqutils/avio_aq/Android.mk ...
FAILED: 
vendor/socionext/sc1401aj1/aqutils/avio_aq/Android.mk: error: libavio_aq: C_INCLUDES must be under the source or output directories: /sysroot32/usr/include /linux/include 
In file included from vendor/socionext/sc1401aj1/app/tif/Android.mk:8:
In file included from vendor/socionext/sc1401aj1/aqutils/avio_aq/Android.mk:63:
In file included from build/make/core/shared_library.mk:32:
In file included from build/make/core/shared_library_internal.mk:34:
In file included from build/make/core/dynamic_binary.mk:39:
build/make/core/binary.mk:1318: error: done.
10:03:27 ckati failed with: exit status 1
Traceback (most recent call last):
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/create_reference_dumps.py", line 218, in <module>
    main()
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/create_reference_dumps.py", line 209, in main
    num_processed = create_source_abi_reference_dumps_for_all_products(args)
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/create_reference_dumps.py", line 156, in create_source_abi_reference_dumps_for_all_products
    platform_vndk_version, targets)
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/create_reference_dumps.py", line 37, in make_libs_for_product
    make_libraries(product, variant, vndk_version, targets, libs)
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/utils.py", line 176, in make_libraries
    build=True)
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/utils.py", line 264, in read_lsdump_paths
    make_targets(product, variant, [lsdump_paths_file_path])
  File "/home/e0004941/Desktop/shaoxie/development/vndk/tools/header-checker/utils/utils.py", line 165, in make_targets
    subprocess.check_call(make_cmd, cwd=AOSP_DIR)
  File "/usr/lib/python3.6/subprocess.py", line 311, in check_call
    raise CalledProcessError(retcode, cmd)
subprocess.CalledProcessError: Command '['build/soong/soong_ui.bash', '--make-mode', '-j', 'TARGET_PRODUCT=aosp_arm_ab', 'TARGET_BUILD_VARIANT=userdebug', 'out/target/product/generic_arm_ab/lsdump_paths.txt']' returned non-zero exit status 1.
```

handle: redefinition



## aio_abi.h


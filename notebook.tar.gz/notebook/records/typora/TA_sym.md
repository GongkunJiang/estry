# sym

```c
xtest 1022
ADBG_CASE_DEFINE(regression, 1022, xtest_tee_test_1022, "Test dlopen()/dlsym()/dlclose() API");
//ca
Do_ADBG_Log("[%s]%s(%d)s JGK",__func__, __FILE__,__LINE__);
Do_ADBG_Log("[%s]%s(%d)e JGK",__func__, __FILE__,__LINE__);
//ta
#include "trace.h"
EMSG("[%s]%s(%d) JGK",__func__, __FILE__,__LINE__);
EMSG("[%s]%s(%d)s JGK",__func__, __FILE__,__LINE__);
EMSG("[%s]%s(%d)e JGK",__func__, __FILE__,__LINE__);

EMSG("[%s]%s(%d)Finding TA %pUl JGK",__func__, __FILE__,__LINE__,(void *)&arg->dlsym.uuid);
EMSG("[%s]%s(%d)val=0x%08lx JGK",__func__, __FILE__,__LINE__,(unsigned long)*val);

dlsym(res = invoke_system_pta(PTA_SYSTEM_DLSYM, param_types, params))
invoke_command(PTA_SYSTEM_DLSYM)
system_dlsym
call_ldelf_dlsym(LDELF_DL_ENTRY_DLSYM)
dl_entry(LDELF_DL_ENTRY_DLSYM)
dlsym_entry

//os_test    
local_module := 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b.ta
    
SHLIBNAME = libos_test
SHLIBUUID = ffd2bded-ab7d-4988-95ee-e4962fff7154
    
SHLIBNAME = libos_test_dl
SHLIBUUID = b3091a65-9751-4784-abf7-0298a7cc35ba    

/* This UUID is generated with the ITU-T UUID generator at
   http://www.itu.int/ITU-T/asn1/uuid.html */
#define TA_OS_TEST_UUID { 0x5b9e0e40, 0x2636, 0x11e1, \
	{ 0xad, 0x9e, 0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b } }    
```

## xtest_tee_test_1022

```c
static void xtest_tee_test_1022(ADBG_Case_t *c)
{
	TEEC_Session session = { 0 };
	uint32_t ret_orig = 0;

	if (!ADBG_EXPECT_TEEC_SUCCESS(c,
			xtest_teec_open_session(&session, &os_test_ta_uuid,
				NULL, &ret_orig)))
		return;

	(void)ADBG_EXPECT_TEEC_SUCCESS(c,
		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL, NULL,
				   &ret_orig));

	(void)ADBG_EXPECT_TEEC_RESULT(c,
		TEEC_ERROR_TARGET_DEAD,
		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL_PANIC,
				   NULL, &ret_orig));

	(void)ADBG_EXPECT_TEEC_ERROR_ORIGIN(c, TEEC_ORIGIN_TEE, ret_orig);

	TEEC_CloseSession(&session);
	Do_ADBG_Log("[%s]%s(%d)e JGK",__func__, __FILE__,__LINE__);
}
```



# CA

```c++
# xtest 1022
Test ID: 1022
Run test suite with level=0

TEE test application started over default TEE instance
######################################################
#
# regression
#
######################################################
 
* regression_1022 Test dlopen()/dlsym()/dlclose() API
  regression_1022 OK
+-----------------------------------------------------
Result of testsuite regression filtered by "1022":
regression_1022 OK
+-----------------------------------------------------
4 subtests of which 0 failed
1 test case of which 0 failed
90 test cases were skipped
TEE test application done!
# 


# xtest 1022
[main]xtest_main.c(118)
    tee_res = xtest_teec_ctx_init();
		return TEEC_InitializeContext(xtest_tee_name, &xtest_teec_ctx);
	[Do_ADBG_RunSuite]adbg/src/adbg_run.c(55)
		[ADBG_RunSuite]adbg/src/adbg_run.c(114)
        	xtest_tee_test_1022// case_def->Run_fp(Case_p);
        		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL, NULL, &ret_orig)
        		TEEC_InvokeCommand(&session, TA_OS_TEST_CMD_CALL_LIB_DL_PANIC, NULL, &ret_orig)
    xtest_teec_ctx_deinit();
		TEEC_FinalizeContext(&xtest_teec_ctx);
```

## xtest_tee_test_1022

### TEEC_Session

```c
/**
 * struct TEEC_Session - Represents a connection between a client application
 * and a trusted application.
 */
typedef struct {
	/* Implementation defined */
	TEEC_Context *ctx;
	uint32_t session_id;
} TEEC_Session;

/**
 * struct TEEC_Context - Represents a connection between a client application
 * and a TEE.
 */
typedef struct {
	/* Implementation defined */
	int fd;
	bool reg_mem;
	bool memref_null;
} TEEC_Context;

	Do_ADBG_Log("TEEC_Session session");
	Do_ADBG_Log("\tTEEC_Context *ctx");
	Do_ADBG_Log("\t\tfd=%d",session.ctx->fd);
	Do_ADBG_Log("\t\treg_mem=%s",session.ctx->reg_mem?"true":"false");
	Do_ADBG_Log("\t\tmemref_null=%s",session.ctx->memref_null?"true":"false");
	Do_ADBG_Log("\tsession_id=%d",session.session_id);
	Do_ADBG_Log("ret_orig=%d",ret_orig);

TEEC_Session session
        TEEC_Context *ctx
                fd=3
                reg_mem=true
                memref_null=true
        session_id=1
ret_orig=4
TEEC_Session session
        TEEC_Context *ctx
                fd=3
                reg_mem=true
                memref_null=true
        session_id=1
ret_orig=4
TEEC_Session session
        TEEC_Context *ctx
                fd=3
                reg_mem=true
                memref_null=true
        session_id=1
ret_orig=3
    
//用于存放从TA端返回的结果的变量。如果不需要返回值，则可以将该变量指向NULL。
#define TEEC_ORIGIN_TEE          0x00000003//The error originated within the common TEE code.
#define TEEC_ORIGIN_TRUSTED_APP  0x00000004//The error originated within the Trusted Application code.    
```



# TA

```c++
D/TC:? 0 tee_ta_init_pseudo_ta_session:283 Lookup pseudo TA 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b
D/TC:? 0 load_ldelf:712 ldelf load address 0x40006000
D/LD:  ldelf:134 Loading TA 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b
D/TC:? 0 tee_ta_init_pseudo_ta_session:283 Lookup pseudo TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 tee_ta_init_pseudo_ta_session:296 Open system.pta
D/TC:? 0 tee_ta_init_pseudo_ta_session:313 system.pta : 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b (Secure Storage TA)
D/TC:? 0 system_open_ta_binary:260 res=0xffff0008
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b (REE)
D/TC:? 0 system_open_ta_binary:260 res=0x0
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF ffd2bded-ab7d-4988-95ee-e4962fff7154 (Secure Storage TA)
D/TC:? 0 system_open_ta_binary:260 res=0xffff0008
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF ffd2bded-ab7d-4988-95ee-e4962fff7154 (REE)
D/TC:? 0 system_open_ta_binary:260 res=0x0
D/LD:  ldelf:168 ELF (5b9e0e40-2636-11e1-ad9e-0002a5d5c51b) at 0x40045000
D/LD:  ldelf:168 ELF (ffd2bded-ab7d-4988-95ee-e4962fff7154) at 0x40029000
D/TC:? 0 tee_ta_close_session:490 csess 0xe18d060 id 1
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 tee_ta_init_session_with_context:584 Re-open TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 tee_ta_init_session_with_context:584 Re-open TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 tee_ta_init_session_with_context:584 Re-open TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF b3091a65-9751-4784-abf7-0298a7cc35ba (Secure Storage TA)
D/TC:? 0 system_open_ta_binary:260 res=0xffff0008
D/TC:? 0 system_open_ta_binary:256 Lookup user TA ELF b3091a65-9751-4784-abf7-0298a7cc35ba (REE)
D/TC:? 0 system_open_ta_binary:260 res=0x0
D/LD:  ta_elf_add_library:1457 ELF (b3091a65-9751-4784-abf7-0298a7cc35ba) at 0x401bc000
D/TC:? 0 tee_ta_close_session:490 csess 0xe18b2c0 id 3
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 tee_ta_close_session:490 csess 0xe18b6f0 id 1
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 tee_ta_init_session_with_context:584 Re-open TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
E/TC:? 0 
E/TC:? 0 TA panicked with code 0x0
E/LD:  Status of TA 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b
E/LD:   arch: aarch64
E/LD:  region  0: va 0x40004000 pa 0x0e300000 size 0x002000 flags rw-s (ldelf)
E/LD:  region  1: va 0x40006000 pa 0x0e302000 size 0x008000 flags r-xs (ldelf)
E/LD:  region  2: va 0x4000e000 pa 0x0e30a000 size 0x001000 flags rw-s (ldelf)
E/LD:  region  3: va 0x4000f000 pa 0x0e30b000 size 0x004000 flags rw-s (ldelf)
E/LD:  region  4: va 0x40013000 pa 0x0e30f000 size 0x001000 flags r--s
E/LD:  region  5: va 0x40014000 pa 0x0e41e000 size 0x003000 flags rw-s (stack)
E/LD:  region  6: va 0x40029000 pa 0x00000000 size 0x007000 flags r-xs [1]
E/LD:  region  7: va 0x40030000 pa 0x00006000 size 0x002000 flags rw-s [1]
E/LD:  region  8: va 0x40045000 pa 0x00001000 size 0x027000 flags r-xs [0]
E/LD:  region  9: va 0x4006c000 pa 0x00028000 size 0x0e7000 flags rw-s [0]
E/LD:  region 10: va 0x401bc000 pa 0x00000000 size 0x007000 flags r-xs [2]
E/LD:  region 11: va 0x401c3000 pa 0x00006000 size 0x002000 flags rw-s [2]
E/LD:   [0] 5b9e0e40-2636-11e1-ad9e-0002a5d5c51b @ 0x40045000
E/LD:   [1] ffd2bded-ab7d-4988-95ee-e4962fff7154 @ 0x40029000
E/LD:   [2] b3091a65-9751-4784-abf7-0298a7cc35ba @ 0x401bc000
E/LD:  Call stack:
E/LD:   0x0000000040057674
E/LD:   0x00000000400595b0
E/LD:   0x0000000040057c9c
D/TC:? 0 user_ta_enter:195 tee_user_ta_enter: TA panicked with code 0x0
D/TC:? 0 destroy_ta_ctx_from_session:305 Remove references to context (0xe18d800)
D/TC:? 0 destroy_context:290 Destroy TA ctx (0xe18d800)
D/TC:? 0 tee_ta_close_session:490 csess 0xe18b550 id 2
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 tee_ta_close_session:490 csess 0xe18a630 id 3
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 tee_ta_close_session:490 csess 0xe18d860 id 1
D/TC:? 0 tee_ta_close_session:510 Destroy session    
```

## TA_InvokeCommandEntryPoint

```c
E/TA:  TA_InvokeCommandEntryPoint:55 [TA_InvokeCommandEntryPoint]ta_entry.c(55)id=16 
    return ta_entry_call_lib_dl(nParamTypes, pParams);//TA_OS_TEST_CMD_CALL_LIB_DL	
E/TA:  TA_InvokeCommandEntryPoint:55 [TA_InvokeCommandEntryPoint]ta_entry.c(55)id=17     
    return ta_entry_call_lib_dl_panic(nParamTypes, pParams);//TA_OS_TEST_CMD_CALL_LIB_DL_PANIC
```

### TEE_Param

```c
/*
 * This union describes one parameter passed by the Trusted Core Framework
 * to the entry points TA_OpenSessionEntryPoint or
 * TA_InvokeCommandEntryPoint or by the TA to the functions
 * TEE_OpenTASession or TEE_InvokeTACommand.
 *
 * Which of the field value or memref to select is determined by the
 * parameter type specified in the argument paramTypes passed to the entry
 * point.
*/
typedef union {
	struct {
		void *buffer;
		uint32_t size;
	} memref;
	struct {
		uint32_t a;
		uint32_t b;
	} value;
} TEE_Param;

	EMSG("[%s]%s(%d)nCommandID=%d JGK",__func__, __FILE__,__LINE__,nCommandID);
	EMSG("nParamTypes=%d",nParamTypes);
	EMSG("TEE_Param pParams[4]");
	for(int i=0;i<4;i++){
		EMSG("TEE_Param pParams[%d]",i);
		EMSG("\tstruct memref");
		EMSG("\t\tbuffer=0x%08lx",(unsigned long)pParams[i].memref.buffer);
		EMSG("\t\tsize=%d",pParams[i].memref.size);
		EMSG("\tstruct value");
		EMSG("\t\ta=%d",pParams[i].value.a);
		EMSG("\t\tb=%d",pParams[i].value.b);
	}

TA_OS_TEST_CMD_CALL_LIB_DL//16
0
TA_OS_TEST_CMD_CALL_LIB_DL_PANIC//17
0
    
	EMSG("[%s]%s(%d)cmd_id=%d JGK",__func__, __FILE__,__LINE__,cmd_id);
	EMSG("param_types=%d",param_types);
	EMSG("TEE_Param params[4]");
	for(int i=0;i<4;i++){
		EMSG("TEE_Param params[%d]",i);
		EMSG("\tstruct memref");
		EMSG("\t\tbuffer=0x%08lx",(unsigned long)params[i].memref.buffer);
		EMSG("\t\tsize=%d",params[i].memref.size);
		EMSG("\tstruct value");
		EMSG("\t\ta=%d",params[i].value.a);
		EMSG("\t\tb=%d",params[i].value.b);
	}

E/TC:? 0 system_dlsym:833 [system_dlsym]core/pta/system.c(833)va=0x4019e9c8 JGK
E/TC:? 0 system_dlsym:836 TEE_Param params[4]
E/TC:? 0 system_dlsym:838 TEE_Param params[0]
E/TC:? 0 system_dlsym:839 	struct memref
E/TC:? 0 system_dlsym:840 		buffer=0x40017000
E/TC:? 0 system_dlsym:841 		size=16
E/TC:? 0 system_dlsym:842 	struct value
E/TC:? 0 system_dlsym:843 		a=1073836032
E/TC:? 0 system_dlsym:844 		b=0
E/TC:? 0 system_dlsym:838 TEE_Param params[1]
E/TC:? 0 system_dlsym:839 	struct memref
E/TC:? 0 system_dlsym:840 		buffer=0x40017010
E/TC:? 0 system_dlsym:841 		size=23
E/TC:? 0 system_dlsym:842 	struct value
E/TC:? 0 system_dlsym:843 		a=1073836048
E/TC:? 0 system_dlsym:844 		b=0
E/TC:? 0 system_dlsym:838 TEE_Param params[2]
E/TC:? 0 system_dlsym:839 	struct memref
E/TC:? 0 system_dlsym:840 		buffer=0x4019e9c800000000
E/TC:? 0 system_dlsym:841 		size=11
E/TC:? 0 system_dlsym:842 	struct value
E/TC:? 0 system_dlsym:843 		a=0
E/TC:? 0 system_dlsym:844 		b=1075440072
E/TC:? 0 system_dlsym:838 TEE_Param params[3]
E/TC:? 0 system_dlsym:839 	struct memref
E/TC:? 0 system_dlsym:840 		buffer=0x00000000
E/TC:? 0 system_dlsym:841 		size=0
E/TC:? 0 system_dlsym:842 	struct value
E/TC:? 0 system_dlsym:843 		a=0
E/TC:? 0 system_dlsym:844 		b=0
E/TC:? 0 system_dlsym:846 [system_dlsym]core/pta/system.c(846)e JGK
```



## ta_entry_call_lib_dl

```c
TEE_Result ta_entry_call_lib_dl(uint32_t param_types __maybe_unused,
				TEE_Param params[4] __unused)
{
	int (*add_func)(int a, int b) = NULL;
	TEE_Result res = TEE_ERROR_GENERIC;
	void *handle = NULL;
	void *hnull = NULL;

	if (param_types != TEE_PARAM_TYPES(TEE_PARAM_TYPE_NONE,
					   TEE_PARAM_TYPE_NONE,
					   TEE_PARAM_TYPE_NONE,
					   TEE_PARAM_TYPE_NONE))
		return TEE_ERROR_BAD_PARAMETERS;

	handle = dlopen("b3091a65-9751-4784-abf7-0298a7cc35ba",
			RTLD_NOW | RTLD_GLOBAL | RTLD_NODELETE);
	if (!handle)
		return TEE_ERROR_GENERIC;

	add_func = dlsym(handle, "os_test_shlib_dl_add");
	if (!add_func)
		goto err;
	if (add_func(3, 4) != 7)
		goto err;

	hnull = dlopen(NULL, RTLD_NOW | RTLD_GLOBAL | RTLD_NODELETE);
	if (!hnull)
		goto err;

	add_func = dlsym(hnull, "os_test_shlib_dl_add");
	if (!add_func)
		goto err;
	if (add_func(5, 6) != 11)
		goto err;

	res = TEE_SUCCESS;
	dlclose(hnull);
err:
	dlclose(handle);
	return res;
}
```

## dlsym

```c++
void *dlsym(void *handle, const char *symbol)
{
	TEE_Result res = TEE_ERROR_GENERIC;
	TEE_Param params[TEE_NUM_PARAMS] = { };
	struct dl_handle *h = handle;
	uint32_t param_types = 0;
	void *ptr = NULL;

	if (!handle || !symbol)
		return NULL;

	param_types = TEE_PARAM_TYPES(TEE_PARAM_TYPE_MEMREF_INPUT,
				      TEE_PARAM_TYPE_MEMREF_INPUT,
				      TEE_PARAM_TYPE_VALUE_OUTPUT,
				      TEE_PARAM_TYPE_NONE);

	params[0].memref.buffer = &h->uuid;
	params[0].memref.size = sizeof(h->uuid);
	params[1].memref.buffer = (void *)symbol;
	params[1].memref.size = strlen(symbol) + 1;

	res = invoke_system_pta(PTA_SYSTEM_DLSYM, param_types, params);
    // reg_pair_from_64(va, &params[2].value.a, &params[2].value.b);//system_dlsym
	if (!res)
		ptr = (void *)(vaddr_t)reg_pair_to_64(params[2].value.a,
						      params[2].value.b);
	return ptr;
}   
```

### detail

```c
add_func = dlsym(handle, "os_test_shlib_dl_add");
	res = invoke_system_pta(PTA_SYSTEM_DLSYM, param_types, params);
		return TEE_InvokeTACommand(sess, TEE_TIMEOUT_INFINITE, cmd_id, param_types, params, NULL);
				res = _utee_invoke_ta_command((uintptr_t)session, cancellationRequestTimeout, commandID, &up, &ret_origin);

syscall_invoke_ta_command
	called_sess = tee_ta_get_session((uint32_t)ta_sess, true, &utc->open_sessions);
	res = tee_ta_invoke_command(&ret_o, called_sess, &clnt_id, cancel_req_to, cmd_id, &param);
		res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);//pseudo_ta_enter_invoke_cmd
			res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
				return system_dlsym(s, param_types, params);

res = call_ldelf_dlsym(utc, uuid, sym, maxlen, &va);
	res = thread_enter_user_mode((vaddr_t)arg, 0, 0, 0, usr_stack, utc->dl_entry_func, is_arm32, &panicked, &panic_code);

dl_entry//ldelf/main.c
    arg->ret = dlsym_entry(arg);
```

### dl_entry_arg

```c
/*
 * struct dl_entry_arg - argument for ldelf_arg::dl_entry()
 */
struct dl_entry_arg {
	uint32_t cmd;
	TEE_Result ret;
	union {
		struct {
			TEE_UUID uuid;	/* in */
			uint32_t flags;	/* in */
		} dlopen;
		struct {
			TEE_UUID uuid;	/* in */
			vaddr_t val;	/* out */
			char symbol[];	/* in */
		} dlsym;
	};
};

	EMSG("struct dl_entry_arg *arg");
	EMSG("\tcmd=%d",arg->cmd);
	EMSG("\tret=0x%08x",arg->ret);
	EMSG("\tdlopen.uuid=%pUl",(void *)&arg->dlopen.uuid);
	EMSG("\tdlopen.flags=%d",arg->dlopen.flags);
	EMSG("\tdlsym.uuid=%pUl",(void *)&arg->dlsym.uuid);
	EMSG("\tdlsym.val=0x%08lx",(unsigned long)arg->dlsym.val);
	EMSG("\tdlsym.symbol=%s",arg->dlsym.symbol);

E/TC:? 0 call_ldelf_dlsym:736 struct dl_entry_arg *arg
E/TC:? 0 call_ldelf_dlsym:737 	cmd=1
E/TC:? 0 call_ldelf_dlsym:738 	ret=0x00000000
E/TC:? 0 call_ldelf_dlsym:739 	dlopen.uuid=b3091a65-9751-4784-abf7-0298a7cc35ba
E/TC:? 0 call_ldelf_dlsym:740 	dlopen.flags=0
E/TC:? 0 call_ldelf_dlsym:741 	dlsym.uuid=b3091a65-9751-4784-abf7-0298a7cc35ba
E/TC:? 0 call_ldelf_dlsym:742 	dlsym.val=0x00000000
E/TC:? 0 call_ldelf_dlsym:743 	dlsym.symbol=os_test_shlib_dl_add
    
E/TC:? 0 call_ldelf_dlsym:747 struct dl_entry_arg *arg
E/TC:? 0 call_ldelf_dlsym:748 	cmd=1
E/TC:? 0 call_ldelf_dlsym:749 	ret=0x00000000
E/TC:? 0 call_ldelf_dlsym:750 	dlopen.uuid=b3091a65-9751-4784-abf7-0298a7cc35ba
E/TC:? 0 call_ldelf_dlsym:751 	dlopen.flags=1073908160
E/TC:? 0 call_ldelf_dlsym:752 	dlsym.uuid=b3091a65-9751-4784-abf7-0298a7cc35ba
E/TC:? 0 call_ldelf_dlsym:753 	dlsym.val=0x400289c0
E/TC:? 0 call_ldelf_dlsym:754 	dlsym.symbol=os_test_shlib_dl_add    

E/TC:? 0 call_ldelf_dlsym:753 	dlsym.val=0x400289c0    // hnull
    
E/TC:? 0 call_ldelf_dlsym:753 	dlsym.val=0x400289c8    //panic
E/TC:? 0 call_ldelf_dlsym:754 	dlsym.symbol=os_test_shlib_dl_panic
    
E/TC:? 0 system_dlsym:836 [system_dlsym]core/pta/system.c(836)e a=0,b=1073908160 JGK    
    
E/TC:? 0 system_dlsym:836 [system_dlsym]core/pta/system.c(836)e a=0,b=1073908168 JGK    
```



## dlsym_entry

```c
TEE_Result dlsym_entry(struct dl_entry_arg *arg)
{
	struct ta_elf *elf = NULL;
	TEE_UUID zero = { };

	if (memcmp(&arg->dlsym.uuid, &zero, sizeof(zero))) {
		elf = ta_elf_find_elf(&arg->dlsym.uuid);//Finding TA b3091a65-9751-4784-abf7-0298a7cc35ba(libos_test_dl)
		if (!elf)
			return TEE_ERROR_ITEM_NOT_FOUND;
	}
	return ta_elf_resolve_sym(arg->dlsym.symbol, &arg->dlsym.val, NULL,
				  elf);
}
```

### ta_elf

```c
struct ta_elf {
	bool is_main;
	bool is_32bit;	/* Initialized from Elf32_Ehdr/Elf64_Ehdr */
	bool is_legacy;

	vaddr_t load_addr;
	vaddr_t max_addr;
	vaddr_t max_offs;
 
	vaddr_t ehdr_addr;

	/* Initialized from Elf32_Ehdr/Elf64_Ehdr */
	vaddr_t e_entry;
	vaddr_t e_phoff;
	vaddr_t e_shoff;
	unsigned int e_phnum;
	unsigned int e_shnum;
	unsigned int e_phentsize;
	unsigned int e_shentsize;

	void *phdr;
	void *shdr;
	/*
	 * dynsymtab and dynstr are used for external symbols, they may hold
	 * other symbols too.
	 */
	void *dynsymtab;
	size_t num_dynsyms;
	const char *dynstr;
	size_t dynstr_size;

	/* DT_HASH hash table for faster resolution of external symbols */
	void *hashtab;

	/* DT_SONAME */
	char *soname;

	struct segment_head segs;

	vaddr_t exidx_start;
	size_t exidx_size;

	/* Thread Local Storage */

	size_t tls_mod_id;
	/* PT_TLS segment */
	vaddr_t tls_start;
	size_t tls_filesz; /* Covers the .tdata section */
	size_t tls_memsz; /* Covers the .tdata and .tbss sections */
#ifdef ARM64
	/* Offset of the copy of the TLS block in the TLS area of the TCB */
	size_t tls_tcb_offs;
#endif

	uint32_t handle;

	struct ta_head *head;

	TEE_UUID uuid;
	TAILQ_ENTRY(ta_elf) link;
};
```



## resolve_sym_helper

```c
// resolve_sym_helper(hash, name, val, elf, false /* !weak_ok */)
static TEE_Result resolve_sym_helper(uint32_t hash, const char *name,// name=os_test_shlib_dl_add
				     vaddr_t *val, struct ta_elf *elf,
				     bool weak_ok)
{
	/*
	 * Using uint32_t here for convenience because both Elf64_Word
	 * and Elf32_Word are 32-bit types
	 */
	uint32_t *hashtab = elf->hashtab;
	uint32_t nbuckets = hashtab[0];
	uint32_t nchains = hashtab[1];
	uint32_t *bucket = &hashtab[2];
	uint32_t *chain = &bucket[nbuckets];
	size_t n = 0;

	if (elf->is_32bit) {//elf->is_32bit=0
		Elf32_Sym *sym = elf->dynsymtab;

		for (n = bucket[hash % nbuckets]; n; n = chain[n]) {
			if (n >= nchains || n >= elf->num_dynsyms)
				err(TEE_ERROR_BAD_FORMAT,
				    "Index out of range");
			/*
			 * We're loading values from sym[] which later
			 * will be used to load something.
			 * => Spectre V1 pattern, need to cap the index
			 * against speculation.
			 */
			n = confine_array_index(n, elf->num_dynsyms);
			if (__resolve_sym(elf,
					  ELF32_ST_BIND(sym[n].st_info),
					  ELF32_ST_TYPE(sym[n].st_info),
					  sym[n].st_shndx,
					  sym[n].st_name,
					  sym[n].st_value, name, val, weak_ok))
				return TEE_SUCCESS;
		}
	} else {
		Elf64_Sym *sym = elf->dynsymtab;

		for (n = bucket[hash % nbuckets]; n; n = chain[n]) {
			if (n >= nchains || n >= elf->num_dynsyms)
				err(TEE_ERROR_BAD_FORMAT,
				    "Index out of range");
			/*
			 * We're loading values from sym[] which later
			 * will be used to load something.
			 * => Spectre V1 pattern, need to cap the index
			 * against speculation.
			 */
			n = confine_array_index(n, elf->num_dynsyms);
			if (__resolve_sym(elf,
					  ELF64_ST_BIND(sym[n].st_info),//#define ELF64_ST_BIND(info)    ((info) >> 4)
					  ELF64_ST_TYPE(sym[n].st_info),//#define ELF64_ST_TYPE(info)    ((info) & 0xf)
					  sym[n].st_shndx,
					  sym[n].st_name,
					  sym[n].st_value, name, val, weak_ok))
				return TEE_SUCCESS;
		}
	}
	return TEE_ERROR_ITEM_NOT_FOUND;
}
```

### Elf64_Sym

```c
typedef struct {
  Elf64_Word  st_name;  /* String table index of name. */
  unsigned char  st_info;  /* Type and binding information. */
  unsigned char  st_other;  /* Reserved (not used). */
  Elf64_Half  st_shndx;  /* Section index of symbol. */
  Elf64_Addr  st_value;  /* Symbol value. */
  Elf64_Xword  st_size;  /* Size of associated object. */
} Elf64_Sym;
```



## __resolve_sym

```c
static bool __resolve_sym(struct ta_elf *elf, unsigned int st_bind,
			  unsigned int st_type, size_t st_shndx,
			  size_t st_name, size_t st_value, const char *name,
			  vaddr_t *val, bool weak_ok)
{
	bool bind_ok = false;

	if (!st_name)
		return false;
	if (st_name > elf->dynstr_size)
		err(TEE_ERROR_BAD_FORMAT, "Symbol name out of range");
	if (strcmp(name, elf->dynstr + st_name))
		return false;
	if (st_bind == STB_GLOBAL || (weak_ok && st_bind == STB_WEAK))
		bind_ok = true;
	if (!bind_ok)
		return false;
	if (st_bind == STB_WEAK && st_shndx == SHN_UNDEF) {
		if (val)
			*val = 0;
		return true;
	}
	if (st_shndx == SHN_UNDEF || st_shndx == SHN_XINDEX)
		return false;

	switch (st_type) {//st_type=2
	case STT_NOTYPE:
	case STT_OBJECT:
	case STT_FUNC:
		if (st_value > (elf->max_addr - elf->load_addr))
			err(TEE_ERROR_BAD_FORMAT,
			    "Symbol location out of range");
		if (val)
			*val = st_value + elf->load_addr;
		break;
	case STT_TLS:
		if (val)
			*val = st_value;
		break;
	default:
		err(TEE_ERROR_NOT_SUPPORTED, "Symbol type not supported");
	}

	return true;
}
```

# time

```c
TEE_Time sys_t = { };
TEE_GetSystemTime(&sys_t);
EMSG("system time %u.%03u\n", (unsigned int)sys_t.seconds,
       (unsigned int)sys_t.millis);

TEE_GetREETime(&sys_t);
EMSG("system time seconds=%d,millis=%d\n", sys_t.seconds, sys_t.millis);
```


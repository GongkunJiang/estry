# 加载TA镜像

请求加载TA镜像的功能ID为**OPTEE_MSG_RPC_CMD_LOAD_TA**。执行该功能时，tee_supplicant会到文件系统中将TA镜像的内容读取到共享内存中。该操作是通过调用**load_ta**函数来实现的，该函数定义在*optee_client/tee-supplicant/src/tee_supplicant.c*文件中。

```c
int main(int argc, char *argv[])
{
    ...
    /* 调用process_one_request函数接收来自TEE的请求,并加以处理 */
	while (!arg.abort) {
		if (!process_one_request(&arg))
			arg.abort = true;
	}
    ...
}

static bool process_one_request(struct thread_arg *arg)
{
    ...
    switch (func) {
	case OPTEE_MSG_RPC_CMD_LOAD_TA:
		ret = load_ta(num_params, params);//加载在文件系统的TA镜像
		break;
	...
	}
    request.send.ret = ret;
    /* 回复处理后的数据给TA */
	return write_response(arg->fd, &request);
}

static uint32_t load_ta(size_t num_params, struct tee_ioctl_param *params)
{
	...
     /* 解析出需要加载的TA镜像的UUID以及配置将读取到的TA镜像的内容存放位置 */
	if (num_params != 2 || get_value(num_params, params, 0, &val_cmd) ||
	    get_param(num_params, params, 1, &shm_ta))
		return TEEC_ERROR_BAD_PARAMETERS;
	/* 将UUID的值转换成TEEC_UUID格式 */
	uuid_from_octets(&uuid, (void *)val_cmd);
	size = shm_ta.size;
    /* 从ta_dir变量指定的目录中查找与UUID相符的TA镜像,并将其内容读取到共享内存中 */
	ta_found = TEECI_LoadSecureModule(ta_dir, &uuid, shm_ta.buffer, &size);
	if (ta_found != TA_BINARY_FOUND) {
		ERROR("  TA not found");
		return TEEC_ERROR_ITEM_NOT_FOUND;
	}
	/* 将读取到的TA镜像的大小填充到返回参数的size成员中 */
	MEMREF_SIZE(params + 1) = size;
	...
}
```

当**load_ta**执行完成并正确读取了TA镜像文件的信息之后，最终会将读取到的数据通过调用**write_response**函数，将数据发送给OP-TEE驱动，由驱动来完成将数据发送给OP-TEE的操作。

```c
static bool write_response(int fd, union tee_rpc_invoke *request)
{
	struct tee_ioctl_buf_data data;
	/* 将需要返回给TA的数据存放在buffer中 */
	memset(&data, 0, sizeof(data));

	data.buf_ptr = (uintptr_t)&request->send;
	data.buf_len = sizeof(struct tee_iocl_supp_send_arg) +
		       sizeof(struct tee_ioctl_param) *
				(__u64)request->send.num_params;
	/* 调用驱动中ioctl函数的TEE_IOC_SUPPL_SEND功能,将数据发送给TA */
	if (ioctl(fd, TEE_IOC_SUPPL_SEND, &data)) {
		ERROR("TEE_IOC_SUPPL_SEND: %s", strerror(errno));
		return false;
	}
	return true;
}
```

 when call function**ioctl**, driver function **tee_ioctl** was called.

```c
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct tee_context *ctx = filp->private_data;
	void __user *uarg = (void __user *)arg;
	switch (cmd) {
	case TEE_IOC_VERSION:
		return tee_ioctl_version(ctx, uarg);
	case TEE_IOC_SHM_ALLOC:
		return tee_ioctl_shm_alloc(ctx, uarg);
	case TEE_IOC_SHM_REGISTER:
		return tee_ioctl_shm_register(ctx, uarg);
	case TEE_IOC_SHM_REGISTER_FD:
		return tee_ioctl_shm_register_fd(ctx, uarg);
	case TEE_IOC_OPEN_SESSION:
		return tee_ioctl_open_session(ctx, uarg);
	case TEE_IOC_INVOKE:
		return tee_ioctl_invoke(ctx, uarg);
	case TEE_IOC_CANCEL:
		return tee_ioctl_cancel(ctx, uarg);
	case TEE_IOC_CLOSE_SESSION:
		return tee_ioctl_close_session(ctx, uarg);
	case TEE_IOC_SUPPL_RECV:
		return tee_ioctl_supp_recv(ctx, uarg);
	case TEE_IOC_SUPPL_SEND:// write_response() fall through
		return tee_ioctl_supp_send(ctx, uarg);
	default:
		return -EINVAL;
	}
}
```

OP-TEE会对接收到的TA镜像的合法性进行校验，主要是验证TA镜像文件的电子签名是否合法。

```markdown
# rpc_load
[_ldelf_start](asm)ENTRY(_ldelf_start) optee_os/ldelf/ldelf.ld.S
  [ldelf]ldelf/main.c(133)JGK
    Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
    [sys_map_zi]ldelf/sys.c(69)JGK
      [invoke_sys_ta]ldelf/sys.c(55)_utee_open_ta_session	JGK
        return _utee_invoke_ta_command(sess, 0, cmdid, params, &ret_orig);
          [thread_svc_handler]core/arch/arm/kernel/thread.c(1561)JGK
            sess->ctx->ops->handle_svc(regs)
              [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
                [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
                  [syscall_invoke_ta_command]core/tee/tee_svc.c(859)JGK
                    [tee_ta_get_session]core/kernel/tee_ta_manager.c(216)JGK
                    [tee_ta_invoke_command]core/kernel/tee_ta_manager.c(752)JGK
                      [tee_ta_set_busy]core/kernel/tee_ta_manager.c(139)JGK
                      res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);
                        [pseudo_ta_enter_invoke_cmd]core/arch/arm/kernel/pseudo_ta.c(186)JGK
                          [tee_ta_push_current_session]core/kernel/tee_ta_manager.c(857)JGK
                            res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);
                              [invoke_command]core/pta/system.c(879)cmd_id=4	JGK
                                [system_open_ta_binary]core/pta/system.c(233)
                                  Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
                                  res = binh->op->open(uuid, &binh->h);
                                    [ree_fs_ta_open]core/arch/arm/kernel/ree_fs_ta.c(131)JGK
                                      [rpc_load]core/arch/arm/kernel/ree_fs_ta.c(84)JGK
                                        [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                          [thread_rpc](asm)
                                            [thread_get_ctx_regs]core/arch/arm/kernel/thread.c(1213)JGK
                                            [thread_get_tmp_sp]core/arch/arm/kernel/thread.c(707)JGK
                                            [thread_state_suspend]core/arch/arm/kernel/thread.c(870)JGK
                                        [thread_rpc_alloc_payload]core/arch/arm/kernel/thread_optee_smc.c(591)JGK
                                        [mobj_get_va]core/arch/arm/include/mm/mobj.h(45)offset=0, JGK
                                        [thread_rpc_cmd]core/arch/arm/kernel/thread_optee_smc.c(480)JGK
                                      [shdr_alloc_and_copy]core/crypto/signed_hdr.c(18)JGK
                                      [shdr_verify_signature]core/crypto/signed_hdr.c(50)JGK
                                  res=0x0
```



# code

![image-20220104092249810](/home/e0004941/.config/Typora/typora-user-images/image-20220104092249810.png)

![image-20220104092330550](/home/e0004941/.config/Typora/typora-user-images/image-20220104092330550.png)

![image-20220104092348142](/home/e0004941/.config/Typora/typora-user-images/image-20220104092348142.png)

![image-20220104092404726](/home/e0004941/.config/Typora/typora-user-images/image-20220104092404726.png)

使用OP-TEE实现特定功能需求则需要开发一个特定的TA，TA调用GP规范定义的接口实现该功能需求。



TA镜像文件会被保存在REE侧的文件系统中并以动态TA的方式运行于OP-TEE中，

当用户需要调用该TA的功能时，通过在CA中调用libteec库中的接口，完成创建会话的操作，将REE侧文件系统中的TA镜像文件加载到OP-TEE的用户空间运行。



为防止该TA镜像文件被篡改或被破坏，在加载TA镜像文件的过程中会对该TA镜像文件的合法性进行检查，

只有校验通过的TA镜像文件才允许运行于OP-TEE的用户空间。



编译TA镜像文件过程中会对TA镜像文件做电子签名操作。



TA镜像文件在OP-TEE工程编译过程中生成，也可通过单独调用TA目录下的脚本来进行编译，但前提是OP-TEE工程被完整编译过。编译过程会先生成原始的TA镜像文件，然后使用签名脚本对该文件进行电子签名，并最终生成.ta文件，即最终会被加载到OP-TEE中的TA镜像文件。



# 编译

对某个TA源代码目录中的Makefile文件执行make指令可触发编译生成TA镜像文件的操作，该Makefile文件将会包含**optee_os/ta/mk/ta_dev_kit.mk**文件，

```shell
# optee_examples/hello_world/ta/Makefile
CFG_TEE_TA_LOG_LEVEL ?= 4

# The UUID for the Trusted Application
BINARY=8aaaf200-2450-11e4-abe2-0002a5d5c51b

# - 表示，无论 include 过程中出现什么错误，都不要报错继续执行。
-include $(TA_DEV_KIT_DIR)/mk/ta_dev_kit.mk

ifeq ($(wildcard $(TA_DEV_KIT_DIR)/mk/ta_dev_kit.mk), )
clean:
	@echo 'Note: $$(TA_DEV_KIT_DIR)/mk/ta_dev_kit.mk not found, cannot clean TA'
	@echo 'Note: TA_DEV_KIT_DIR=$(TA_DEV_KIT_DIR)'
endif
```

该文件中会定义各种目标依赖关系和Object，编译完目标和object后，编译器将会按照**optee_os/ta/arch/arm/link.mk**文件中的依赖关系将目标和object链接成xxx.ta文件，

```shell
# optee_os/ta/mk/ta_dev_kit.mk

ifneq ($(user-ta-uuid),)
include  $(ta-dev-kit-dir$(sm))/mk/link.mk
endif
```

其中xxx是该TA UUID的值。link.mk中的链接依赖关系如下：

```shell
# optee_os/ta/arch/arm/link.mk
define gen-link-t
$(link-script-pp$(sm)): $(link-script$(sm)) $(conf-file) $(link-script-pp-makefiles$(sm))
	@$(cmd-echo-silent) '  CPP     $$@'
	$(q)mkdir -p $$(dir $$@)
	$(q)$(CPP$(sm)) -P -MT $$@ -MD -MF $(link-script-dep$(sm)) \
		$(link-script-cppflags-$(sm)) $$< -o $$@

$(link-out-dir$(sm))/$(user-ta-uuid).elf: $(objs) $(libdeps) \
					  $(link-script-pp$(sm)) \
					  $(dynlistdep) \
					  $(additional-link-deps)
	@$(cmd-echo-silent) '  LD      $$@'
	$(q)$(LD$(sm)) $(ldargs-$(user-ta-uuid).elf) -o $$@

$(link-out-dir$(sm))/$(user-ta-uuid).dmp: \
			$(link-out-dir$(sm))/$(user-ta-uuid).elf
	@$(cmd-echo-silent) '  OBJDUMP $$@'
	$(q)$(OBJDUMP$(sm)) -l -x -d $$< > $$@

$(link-out-dir$(sm))/$(user-ta-uuid).stripped.elf: \
			$(link-out-dir$(sm))/$(user-ta-uuid).elf
	@$(cmd-echo-silent) '  OBJCOPY $$@'
	$(q)$(OBJCOPY$(sm)) --strip-unneeded $$< $$@

cmd-echo$(user-ta-uuid) := SIGN   #
ifeq ($(CFG_ENCRYPT_TA),y)
crypt-args$(user-ta-uuid) := --enc-key $(TA_ENC_KEY)
cmd-echo$(user-ta-uuid) := SIGNENC
endif
$(link-out-dir$(sm))/$(user-ta-uuid).ta: \
			$(link-out-dir$(sm))/$(user-ta-uuid).stripped.elf \
			$(TA_SIGN_KEY)
	@$(cmd-echo-silent) '  $$(cmd-echo$(user-ta-uuid)) $$@'
	$(q)$(SIGN_ENC) --key $(TA_SIGN_KEY) $$(crypt-args$(user-ta-uuid)) \
		--uuid $(user-ta-uuid) --ta-version $(user-ta-version) \
		--in $$< --out $$@
endef
```

$(link-out-dir)/$(binary).stripped.elf目标会删除TA镜像文件中的调试信息。

在原始TA镜像文件的头部有一个ta_head段，该段中存放该TA的基本信息以及被调用到的入口地址，该段的内容将会在加载TA镜像到OP-TEE时和调用TA执行特定命令时被使用到。存放在该段中的内容定义在**optee_os/ta/arch/arm/user_ta_header.c**文件中，其内容如下：

# 签名





# 验签

# 加密

# 解密
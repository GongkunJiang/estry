# LD60基础环境搭建

http://confluence.eswin.com/pages/viewpage.action?pageId=33922225

## 根目录

![image-20211026141817788](/home/e0004941/.config/Typora/typora-user-images/image-20211026141817788.png)

### eswin_bsp

![image-20211026141826569](/home/e0004941/.config/Typora/typora-user-images/image-20211026141826569.png)

#### eswin_bsp/build/socionext

![image-20211026141831428](/home/e0004941/.config/Typora/typora-user-images/image-20211026141831428.png)

## step

```sh
repo init -u ssh://jianggongkun@review-bj.eswin.cn:29418/platform/manifest -b android-11-dev-ld60-pre -g base,security,-securitypre --repo-url=ssh://jianggongkun@review-bj.eswin.cn:29418/tools/git-repo
repo sync -cdj4 --no-tags
./eswinbuild ld60_evb userdebug fullbuild
# real	142m42.528s
# user	951m46.527s
# sys	38m56.829s
du -sh # 174G	.
# no realease_img
# cd /home/e0004941/Desktop/shaoxie/eswin_bsp
# make ld20-hikeen-dtmb
# cd /home/e0004941/Desktop/shaoxie
# source build/envsetup.sh
# lunch ld60_evb-userdebug
# make -j100
# ./eswin_make_romimage.sh
```

## images

![image-20211026185748668](/home/e0004941/.config/Typora/typora-user-images/image-20211026185748668.png)

## problems

###  API-LINT(when make -j100)

![image-20211026183105729](/home/e0004941/.config/Typora/typora-user-images/image-20211026183105729.png)

#### handle nouse

```sh
cp \
out/soong/.intermediates/frameworks/base/system-api-stubs-docs/android_common/api/system-baseline.txt \
frameworks/base/api/system-baseline.txt
```

![image-20211026183213649](/home/e0004941/.config/Typora/typora-user-images/image-20211026183213649.png)

#### final handle

```sh
cd /home/e0004941/Desktop/shaoxie
source build/envsetup.sh
lunch
57 # ld60_evb-userdebug
# cd /home/e0004941/Desktop/shaoxie/external/boringssl
mmma # 编译指定路径下所有模块，且包含依赖
# source build/envsetup.sh
# lunch ld60_evb-userdebug
make -j100
./eswin_make_romimage.sh
```

# 验证linux 内核对crypto的支持

配置linux 内核的crypto 层算法支持，使boringssl能调用到相关算法
http://jira.eswin.com/browse/LDP-5441

## 1. generate default defconfig

```shell
cd /home/e0004941/Desktop/shaoxie/eswin_bsp/output/linux
make ARCH=arm64 savedefconfig
```

## 2. compare to ld20-dtmb_defconfig

```shell
diff defconfig ../../kernel/common/arch/arm64/configs/ld20-dtmb_defconfig
```

only one  commit line differ, so we can use to compare modification  later.

```sh
542a543
> # CONFIG_STATIC_USERMODEHELPER is not set
```

## 3. modify defconfig

```sh
make ARCH=arm64 menuconfig
#scroll to the end, Enter "Cryptographic API"
#includes follow items: 
#   Userspace cryptographic algorithm configuration
#   CCM support
#   CFB support
#   SHA3 digest algorithm   
#   SM3 digest algorithm
#   SM4 cipher algorithm
#   User-space interface for symmetric key cipher algorithms                                                         
#   User-space interface for random number generator algorithms 
#   User-space interface for AEAD cipher algorithms
#Save and Exit
make ARCH=arm64 savedefconfig
diff defconfig ../../kernel/common/arch/arm64/configs/ld20-dtmb_defconfig
```

modification shown below

```sh
542a543
> # CONFIG_STATIC_USERMODEHELPER is not set
544,545d544
< CONFIG_CRYPTO_USER=y
< CONFIG_CRYPTO_CCM=y
547,554d545
< CONFIG_CRYPTO_CFB=y
< CONFIG_CRYPTO_SHA3=y
< CONFIG_CRYPTO_SM3=y
< CONFIG_CRYPTO_SM4=y
< CONFIG_CRYPTO_USER_API_HASH=y
< CONFIG_CRYPTO_USER_API_SKCIPHER=y
< CONFIG_CRYPTO_USER_API_RNG=y
< CONFIG_CRYPTO_USER_API_AEAD=y
```

overwrite ld20-dtmb_defconfig

```sh
cp defconfig ../../kernel/common/arch/arm64/configs/ld20-dtmb_defconfig
```

## 4. compile bsp

```sh
cd /home/e0004941/Desktop/shaoxie/eswin_bsp
make ld20-hikeen-dtmb
cd /home/e0004941/Desktop/shaoxie
./eswin_make_romimage.sh
```

## 5. got new fip.bin

```sh
cd /home/e0004941/Desktop/shaoxie/release_img
ls -alh fip.bin # -rw-rw-r-- 1 e0004941 e0004941 1.5M Oct 26 19:06 fip.bin
ls -alh cache.img # -rw-rw-r-- 1 e0004941 e0004941 57K Oct 26 17:05 cache.img
du -sh # 724M	.
```

## 6. copy fip.bin to usb

```sh
ftp 10.100.130.32 2122
mbu002
MBU888888
cd jianggongkun
put fip.bin
```

## 7. 烧写说明

1. 第一次烧写升级时需要烧写全部文件
2. **后期修改时，可以只烧写部分镜像**。比如，我只**修改了kernel**，编译重新生成镜像文件时，usb目录下**只**需要放**boot.img**（usb_update、unph_bl.bin、fip.bin、stm_main_ref16.bin这几个文件每次烧写时也是需要的，因为usb_update脚本会做mmc erase动作），这样烧录时没有其他文件会自动跳过

```shell
Enter
run update_from_usb
reset
```

# 分析boringssl的测试方式                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             

分析test_fips与crypto_test两个boringssl测试工具的编译与测试逻辑，确认我们使用哪中方式进行算法的全面测试
http://jira.eswin.com/browse/LDP-5442

## 编译boringssl

```sh
cd /home/e0004941/Desktop/shaoxie
source build/envsetup.sh
lunch ld60_evb-userdebug # 57
cd /home/e0004941/Desktop/shaoxie/external/boringssl
mma # 编译当前路径下所有模块，且包含依赖
cd /home/e0004941/Desktop/shaoxie
source build/envsetup.sh
lunch ld60_evb-userdebug
make -j100
./eswin_make_romimage.sh
du release_img/ -sh # 725M	release_img/
```

## bssl

![image-20211029104851850](/home/e0004941/.config/Typora/typora-user-images/image-20211029104851850.png)

## test_fips

```sh
vim /home/e0004941/Desktop/shaoxie/external/boringssl/src/util/fipstools/cavp/test_fips.c
mma
```

![image-20211026195315544](/home/e0004941/.config/Typora/typora-user-images/image-20211026195315544.png)

![image-20211029104911911](/home/e0004941/.config/Typora/typora-user-images/image-20211029104911911.png)

### output

```sh
cd /home/e0004941/Desktop/jgk
cp /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/vendor/bin/bssl /home/e0004941/Desktop/jgk/
cp /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/vendor/apex/com.android.vndk.current.on_vendor/lib/* /home/e0004941/Desktop/jgk/
cp /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/system/bin/test_fips /home/e0004941/Desktop/jgk/

ftp 10.100.130.32 2122
mbu002
MBU888888
cd jianggongkun
put bssl 
put libcrypto.so  
put libssl.so
put test_fips 

```



## callback type

```sh
pwd # /home/e0004941/Desktop/shaoxie/external/boringssl/src
vim src/engines/e_afalg.h
mma
```

![image-20211027094200014](/home/e0004941/.config/Typora/typora-user-images/image-20211027094200014.png)

```c
typedef int (*ENGINE_CIPHERS_PTR) (ENGINE *, const EVP_CIPHER **, 
                                   const int **, int);
struct engine_st {
  RSA_METHOD *rsa_method;
  ECDSA_METHOD *ecdsa_method;
  ENGINE_CIPHERS_PTR ciphers;
};
```

​										

## afalg

```sh
cp -rf /home/e0004941/Desktop/myWorkPlace/boringssl/engines . # e_afalg.c  e_afalg_err.c  e_afalg_err.h  e_afalg.h
vim ../sources.bp # add *.c 
vim crypto/fipsmodule/cipher/cipher.c # add *.h 
```

![image-20211027094736186](/home/e0004941/.config/Typora/typora-user-images/image-20211027094736186.png)

![image-20211027084254878](/home/e0004941/.config/Typora/typora-user-images/image-20211027084254878.png)

## 宏控打印

![image-20211027091330724](/home/e0004941/.config/Typora/typora-user-images/image-20211027091330724.png)

## problems

### linux_glibc_common module source path  does not exist

![image-20211026143949432](/home/e0004941/.config/Typora/typora-user-images/image-20211026143949432.png)

prebuilts/tools/common/m2/repository/org/jetbrains/kotlin/kotlin-compiler/1.3.20/kotlin-compiler-1.3.20-dev-564.jar

prebuilts/tools/common/m2/repository/org/jetbrains/kotlin/kotlin-ide-common/1.3.20/kotlin-ide-common.jar

```sh
# start all over again
cd /home/e0004941/Desktop/shaoxie
rm * -rf
```

### do not include c file (no hongkong)

```sh
vim 
ts name
```

### variable has incomplete type 

![image-20211026150721211](/home/e0004941/.config/Typora/typora-user-images/image-20211026150721211.png)

**sources.bp** or

Copy definition from C file to H file.

![image-20211026175803298](/home/e0004941/.config/Typora/typora-user-images/image-20211026175803298.png)

![image-20211026175853317](/home/e0004941/.config/Typora/typora-user-images/image-20211026175853317.png)































# 单独编译bsp中的某个模块

当前，支持单独编译bsp中的如下模块：

![image-20211026150304185](/home/e0004941/.config/Typora/typora-user-images/image-20211026150304185.png)

常用的包括uboot vmlinux(也就是kernel) kernel_modules(索喜的kmod) 等

使用方法：

cd eswin_bsp/build/mk/

make target=ld20-hikeen-dtmb uboot   // 编译uboot

make target=ld20-hikeen-dtmb vmlinux  // 编译kernel

注：如果编译其它开发板或者tvstack，target=<soc>-<platform>-<tvstack>,

如 make target=ld20-socionext-isdb uboot


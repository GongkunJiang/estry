I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(73)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
D/TC:1 0 __thread_std_smc_entry:214 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(214)JGK
D/TC:1 0 std_smc_entry:191 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(191)JGK
D/TC:1 0 tee_entry_std:528 [tee_entry_std]core/arch/arm/tee/entry_std.c(528)JGK
D/TC:1 0 __tee_entry_std:539 [__tee_entry_std]core/arch/arm/tee/entry_std.c(539)JGK
D/TC:? 0 entry_open_session:371 [entry_open_session]core/arch/arm/tee/entry_std.c(371)JGK
D/TC:? 0 tee_ta_open_session:689 [tee_ta_open_session]core/kernel/tee_ta_manager.c(689)JGK
D/TC:? 0 tee_ta_init_session:624 [tee_ta_init_session]core/kernel/tee_ta_manager.c(624)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:282 [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(282)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:283 Lookup pseudo TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
D/TC:? 0 tee_ta_init_user_ta_session:738 [tee_ta_init_user_ta_session]core/arch/arm/kernel/user_ta.c(738)utc->uctx.ctx.uuid = *uuid. JGK
D/TC:? 0 load_ldelf:680 [load_ldelf]core/arch/arm/kernel/user_ta.c(680)JGK
D/TC:? 0 load_ldelf:692 [load_ldelf]core/arch/arm/kernel/user_ta.c(692)utc->entry_func = code_addr + ldelf_entry. JGK
D/TC:? 0 load_ldelf:710 ldelf load address 0x40006000
D/TC:? 0 init_with_ldelf:247 [init_with_ldelf]core/arch/arm/kernel/user_ta.c(247)call thread_enter_user_mode. JGK
D/TC:1 0 thread_enter_user_mode:1475 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1475)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:133 [ldelf]ldelf/main.c(133)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:134 Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:69 [sys_map_zi]ldelf/sys.c(69)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:55 [invoke_sys_ta]ldelf/sys.c(55)_utee_open_ta_session	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=5. JGK
D/TC:? 0 tee_ta_open_session:689 [tee_ta_open_session]core/kernel/tee_ta_manager.c(689)JGK
D/TC:? 0 tee_ta_init_session:624 [tee_ta_init_session]core/kernel/tee_ta_manager.c(624)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:282 [tee_ta_init_pseudo_ta_session]core/arch/arm/kernel/pseudo_ta.c(282)JGK
D/TC:? 0 tee_ta_init_pseudo_ta_session:283 Lookup pseudo TA 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 tee_ta_init_pseudo_ta_session:296 Open system.pta
D/TC:? 0 tee_ta_init_pseudo_ta_session:313 system.pta : 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=2	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_load_main:1126 [ta_elf_load_main]ldelf/ta_elf.c(1126)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  load_main:1073 [load_main]ldelf/ta_elf.c(1073)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  init_elf:432 [init_elf]ldelf/ta_elf.c(432)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=4	JGK
D/TC:? 0 system_open_ta_binary:233 [system_open_ta_binary]core/pta/system.c(233)JGK
D/TC:? 0 system_open_ta_binary:257 Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (Secure Storage TA)
D/TC:? 0 system_open_ta_binary:261 res=0xffff0008
D/TC:? 0 system_open_ta_binary:257 Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
D/TC:? 0 system_open_ta_binary:261 res=0x0
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_ta_bin:148 [sys_map_ta_bin]ldelf/sys.c(148)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=6	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  map_segments:864 [map_segments]ldelf/ta_elf.c(864)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  populate_segments:731 [populate_segments]ldelf/ta_elf.c(731)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=33. JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_ta_bin:148 [sys_map_ta_bin]ldelf/sys.c(148)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=6	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:69 [sys_map_zi]ldelf/sys.c(69)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=2	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_copy_from_ta_bin:189 [sys_copy_from_ta_bin]ldelf/sys.c(189)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=7	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  add_dependencies:948 [add_dependencies]ldelf/ta_elf.c(948)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  copy_section_headers:968 [copy_section_headers]ldelf/ta_elf.c(968)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_copy_from_ta_bin:189 [sys_copy_from_ta_bin]ldelf/sys.c(189)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=7	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  save_symtab:402 [save_symtab]ldelf/ta_elf.c(402)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  close_handle:1003 [close_handle]ldelf/ta_elf.c(1003)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_close_ta_bin:140 [sys_close_ta_bin]ldelf/sys.c(140)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=5	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  set_tls_offset:1057 [set_tls_offset]ldelf/ta_elf.c(1057)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_map_zi:69 [sys_map_zi]ldelf/sys.c(69)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  invoke_sys_ta:62 [invoke_sys_ta]ldelf/sys.c(62)call _utee_invoke_ta_command JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=7. JGK
D/TC:? 0 invoke_command:879 [invoke_command]core/pta/system.c(879)cmd_id=2	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_load_dependency:1174 [ta_elf_load_dependency]ldelf/ta_elf.c(1174)elf->is_main=1. JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_relocate:613 [ta_elf_relocate]ldelf/ta_elf_rel.c(613)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_finalize_load_main:1157 [ta_elf_finalize_load_main]ldelf/ta_elf.c(1157)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_set_init_fini_info_compat:1696 [ta_elf_set_init_fini_info_compat]ldelf/ta_elf.c(1696)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_resolve_sym:157 [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_set_elf_phdr_info:1822 [ta_elf_set_elf_phdr_info]ldelf/ta_elf.c(1822)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ta_elf_resolve_sym:157 [ta_elf_resolve_sym]ldelf/ta_elf_rel.c(157)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  realloc_elf_phdr_info:1744 [realloc_elf_phdr_info]ldelf/ta_elf.c(1744)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:160 [ldelf]ldelf/main.c(160)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:166 [ldelf]ldelf/main.c(166)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:168 ELF (8aaaf200-2450-11e4-abe2-0002a5d5c51b) at 0x40038000
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:170 [ldelf]ldelf/main.c(170)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  ldelf:177 [ldelf]ldelf/main.c(177)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/LD:  sys_return_cleanup:35 [sys_return_cleanup]ldelf/sys.c(35)JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=6. JGK
D/TC:? 0 syscall_close_ta_session:853 [syscall_close_ta_session]core/tee/tee_svc.c(853)JGK
D/TC:? 0 tee_ta_close_session:490 csess 0xe18e060 id 1
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
D/TC:1 0 thread_enter_user_mode:1475 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1475)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_CreateEntryPoint:39 has been called
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_OpenSessionEntryPoint:68 has been called
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: JGK, Hello World!
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(73)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
D/TC:1 0 __thread_std_smc_entry:214 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(214)JGK
D/TC:1 0 std_smc_entry:191 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(191)JGK
D/TC:1 0 tee_entry_std:528 [tee_entry_std]core/arch/arm/tee/entry_std.c(528)JGK
D/TC:1 0 __tee_entry_std:539 [__tee_entry_std]core/arch/arm/tee/entry_std.c(539)JGK
D/TC:1 0 thread_enter_user_mode:1475 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1475)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  inc_value:105 has been called
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Got value: 42 from NW
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Increase value to: 43
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
I/TC: [thread_handle_std_smc]core/arch/arm/kernel/thread_optee_smc.c(73)ASM	vector_std_smc_entry		JGK
I/TC: [thread_alloc_and_run]core/arch/arm/kernel/thread.c(553)JGK
I/TC: [init_regs]core/arch/arm/kernel/thread.c(477)JGK
D/TC:1 0 __thread_std_smc_entry:214 [__thread_std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(214)JGK
D/TC:1 0 std_smc_entry:191 [std_smc_entry]core/arch/arm/kernel/thread_optee_smc.c(191)JGK
D/TC:1 0 tee_entry_std:528 [tee_entry_std]core/arch/arm/tee/entry_std.c(528)JGK
D/TC:1 0 __tee_entry_std:539 [__tee_entry_std]core/arch/arm/tee/entry_std.c(539)JGK
D/TC:? 0 tee_ta_close_session:490 csess 0xe18e860 id 1
D/TC:? 0 tee_ta_close_session:510 Destroy session
D/TC:1 0 thread_enter_user_mode:1475 [thread_enter_user_mode]core/arch/arm/kernel/thread.c(1475)call	ASM	__thread_enter_user_mode	JGK
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
I/TA: Goodbye!
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=1. JGK
D/TA:  TA_DestroyEntryPoint:50 has been called
D/TC:? 0 thread_svc_handler:1551 [thread_svc_handler]core/arch/arm/kernel/thread.c(1551)JGK
D/TC:? 0 user_ta_handle_svc:251 [user_ta_handle_svc]core/arch/arm/tee/arch_svc.c(251)JGK
D/TC:? 0 get_syscall_func:223 [get_syscall_func]core/arch/arm/tee/arch_svc.c(223)num=0. JGK
D/TC:? 0 destroy_context:290 Destroy TA ctx (0xe18e800)


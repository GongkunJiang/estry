# bp

xxx

## base.h

```c
#if defined(__APPLE__)
#define OPENSSL_APPLE
// Note |TARGET_OS_MAC| is set for all Apple OS variants. |TARGET_OS_OSX|
// targets macOS specifically.
#if defined(TARGET_OS_OSX) && TARGET_OS_OSX
#define OPENSSL_MACOS
#endif
#if defined(TARGET_OS_IPHONE) && TARGET_OS_IPHONE
#define OPENSSL_IOS
#endif
#endif

#if defined(_WIN32)
#define OPENSSL_WINDOWS
#endif

#if defined(__linux__)
#define OPENSSL_LINUX
#endif

#if defined(__Fuchsia__)
#define OPENSSL_FUCHSIA
#endif

#if defined(TRUSTY)
#define OPENSSL_TRUSTY
#define OPENSSL_NO_THREADS_CORRUPT_MEMORY_AND_LEAK_SECRETS_IF_THREADED
#endif

#if defined(__ANDROID_API__)
#define OPENSSL_ANDROID
#endif
```



## Android.bp

```sh
# Android.bp
# cflags: ["-DJGKTEST"],
e0004941@user-virtual-machine:~/Desktop/shaoxie/external/boringssl$ git diff Android.bp
diff --git a/Android.bp b/Android.bp
index 6ff1bf8c..c80872f6 100644
--- a/Android.bp
+++ b/Android.bp
@@ -22,6 +22,7 @@ cc_defaults {
         "-D_XOPEN_SOURCE=700",
         "-Werror",
         "-Wno-unused-parameter",
+               "-DJGKTEST",
     ],
 
     cppflags: [
```



# patch

```sh
cd /home/e0004941/Desktop/shaoxie/external/boringssl
git status
git add src/crypto/afalg/
git status
git diff --staged > 20211105.patch
mv 20211105.patch ~/Desktop/myWorkPlace/backups/
# cd ..
# tar -zvcf 20201105.tar.gz boringssl
# mv 20201105.tar.gz ~/Desktop/myWorkPlace/backups/
git clean -nfd
git clean -fd

# libcrypto.so
cd /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/vendor/apex/com.android.vndk.current.on_vendor/lib/
# test_fips
cd /home/e0004941/Desktop/shaoxie/out/target/product/ld60_evb/system/bin/


tar -zvxf ~/Desktop/myWorkPlace/backups/20201105.tar.gz -C .

```


# 0. tee_supplicant

tee_supplicant作为Linux中的一个守护进程，起到处理RPC请求的服务器端的作用，通过类似于C/S的方式，为OP-TEE提供对REE侧资源进行操作的实现。

tee_supplicant启动的动作存放在S30optee文件中, 内容如下：

```shell
# buildroot/package/optee-client/S30optee
DAEMON="tee-supplicant"
PIDFILE="/var/run/$DAEMON.pid"

DAEMON_ARGS="-d /dev/teepriv0"

start() {
	printf 'Starting %s: ' "$DAEMON"
	start-stop-daemon -S -q -p "$PIDFILE" -x "/usr/sbin/$DAEMON" \
		-- $DAEMON_ARGS
	status=$?
	if [ "$status" -eq 0 ]; then
		echo "OK"
	else
		echo "FAIL"
	fi
	return "$status"
}
```

**start-stop-daemon** - start and stop system daemon programs

| COMMANDS               | DESCRIPTION                                                  |
| ---------------------- | ------------------------------------------------------------ |
| -S, --start            | Check  for the existence of a specified process.             |
| -q, --quiet            | Do not print informational messages; only display error messages. |
| -p, --pidfile pid-file | Check  whether  a  process  has  created  the  file  pid-file. |
| -x, --exec executable  | Check for processes that are instances of this executable. The executable argument should be an absolute pathname. |
| -d, --chdir path       | Chdir to path before starting the process.                   |

S30optee会在编译optee-client目标时被编译生成一个可执行文件:

```shell
# buildroot/package//optee-client/optee-client.mk
define OPTEE_CLIENT_INSTALL_INIT_SYSV
	$(INSTALL) -m 0755 -D $(OPTEE_CLIENT_PKGDIR)/S30optee \
		$(TARGET_DIR)/etc/init.d/S30optee
endef
```

tee_supplicant可执行文件在Linux启动时会被作为后台程序启动。

optee_client/tee-supplicant/src/tee_supplicant.c

## 0.0 加载TA镜像

请求加载TA镜像的功能ID为**OPTEE_MSG_RPC_CMD_LOAD_TA**。执行该功能时，tee_supplicant会到文件系统中将TA镜像的内容读取到共享内存中。该操作是通过调用**load_ta**函数来实现的，该函数定义在*optee_client/tee-supplicant/src/tee_supplicant.c*文件中。

```c
int main(int argc, char *argv[])
{
    ...
    /* 调用process_one_request函数接收来自TEE的请求,并加以处理 */
	while (!arg.abort) {
		if (!process_one_request(&arg))
			arg.abort = true;
	}
    ...
}

static bool process_one_request(struct thread_arg *arg)
{
    ...
    switch (func) {
	case OPTEE_MSG_RPC_CMD_LOAD_TA:
		ret = load_ta(num_params, params);//加载在文件系统的TA镜像
		break;
	...
	}
    request.send.ret = ret;
    /* 回复处理后的数据给TA */
	return write_response(arg->fd, &request);
}

static uint32_t load_ta(size_t num_params, struct tee_ioctl_param *params)
{
	...
     /* 解析出需要加载的TA镜像的UUID以及配置将读取到的TA镜像的内容存放位置 */
	if (num_params != 2 || get_value(num_params, params, 0, &val_cmd) ||
	    get_param(num_params, params, 1, &shm_ta))
		return TEEC_ERROR_BAD_PARAMETERS;
	/* 将UUID的值转换成TEEC_UUID格式 */
	uuid_from_octets(&uuid, (void *)val_cmd);
	size = shm_ta.size;
    /* 从ta_dir变量指定的目录中查找与UUID相符的TA镜像,并将其内容读取到共享内存中 */
	ta_found = TEECI_LoadSecureModule(ta_dir, &uuid, shm_ta.buffer, &size);
	if (ta_found != TA_BINARY_FOUND) {
		ERROR("  TA not found");
		return TEEC_ERROR_ITEM_NOT_FOUND;
	}
	/* 将读取到的TA镜像的大小填充到返回参数的size成员中 */
	MEMREF_SIZE(params + 1) = size;
	...
}
```

当**load_ta**执行完成并正确读取了TA镜像文件的信息之后，最终会将读取到的数据通过调用**write_response**函数，将数据发送给OP-TEE驱动，由驱动来完成将数据发送给OP-TEE的操作。

```c
static bool write_response(int fd, union tee_rpc_invoke *request)
{
	struct tee_ioctl_buf_data data;
	/* 将需要返回给TA的数据存放在buffer中 */
	memset(&data, 0, sizeof(data));

	data.buf_ptr = (uintptr_t)&request->send;
	data.buf_len = sizeof(struct tee_iocl_supp_send_arg) +
		       sizeof(struct tee_ioctl_param) *
				(__u64)request->send.num_params;
	/* 调用驱动中ioctl函数的TEE_IOC_SUPPL_SEND功能,将数据发送给TA */
	if (ioctl(fd, TEE_IOC_SUPPL_SEND, &data)) {
		ERROR("TEE_IOC_SUPPL_SEND: %s", strerror(errno));
		return false;
	}
	return true;
}
```

 when call function**ioctl**, driver function **tee_ioctl** was called.

```c
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct tee_context *ctx = filp->private_data;
	void __user *uarg = (void __user *)arg;
	switch (cmd) {
	case TEE_IOC_VERSION:
		return tee_ioctl_version(ctx, uarg);
	case TEE_IOC_SHM_ALLOC:
		return tee_ioctl_shm_alloc(ctx, uarg);
	case TEE_IOC_SHM_REGISTER:
		return tee_ioctl_shm_register(ctx, uarg);
	case TEE_IOC_SHM_REGISTER_FD:
		return tee_ioctl_shm_register_fd(ctx, uarg);
	case TEE_IOC_OPEN_SESSION:
		return tee_ioctl_open_session(ctx, uarg);
	case TEE_IOC_INVOKE:
		return tee_ioctl_invoke(ctx, uarg);
	case TEE_IOC_CANCEL:
		return tee_ioctl_cancel(ctx, uarg);
	case TEE_IOC_CLOSE_SESSION:
		return tee_ioctl_close_session(ctx, uarg);
	case TEE_IOC_SUPPL_RECV:
		return tee_ioctl_supp_recv(ctx, uarg);
	case TEE_IOC_SUPPL_SEND:// write_response() fall through
		return tee_ioctl_supp_send(ctx, uarg);
	default:
		return -EINVAL;
	}
}
```

OP-TEE会对接收到的TA镜像的合法性进行校验，主要是验证TA镜像文件的电子签名是否合法。

## 0.1 pthread_mutex_init[144]

```c
// int pthread_mutex_init(pthread_mutex_t *__mutex, const pthread_mutexattr_t *__mutexattr)
e = pthread_mutex_init(&arg.mutex, NULL); /* 初始化互斥体 */
	/*
	 * We keep trying to init our preload module because there might be
	 * code in init sections that tries to touch locks before we are
	 * initialized, in that case we'll need to manually call preload
	 * to get us going.
	 *
	 * Funny enough, kernel's lockdep had the same issue, and used
	 * (almost) the same solution. See look_up_lock_class() in
	 * kernel/locking/lockdep.c for details.
	 */

        /*
         * We do a dummy initialization here so that lockdep could
         * warn us if something fishy is going on - such as
         * initializing a held lock.
         */
```

我们一直在尝试初始化我们的预加载模块，因为在初始化之前，init部分中可能有代码试图触摸锁，在这种情况下，我们需要手动调用preload来启动.

有趣的是，内核的lockdep也有同样的问题，并且使用了(几乎)相同的解决方案。详情请参阅*kernel/locking/lockdep.c*中的*look_up_lock_class()*。

我们在这里做了一个虚拟的初始化，这样如果有什么可疑的事情发生，比如初始化一个持有的锁，lockdep就可以警告我们。

## 0.2 open_dev

```c
if (dev)
    arg.fd = open_dev(dev, &arg.gen_caps);//static int open_dev(const char *devname, uint32_t *gen_caps)
```

### 0.2.1 open

```c
// int open(const char *__file, int __oflag, ...)
fd = open(devname, O_RDWR);

// somehow goto linux/drivers/tee/tee_core.c
static int tee_open(struct inode *inode, struct file *filp){
	// static struct tee_context *teedev_open(struct tee_device *teedev)
    ctx = teedev_open(container_of(inode->i_cdev, struct tee_device, cdev));
}

// static const struct tee_driver_ops optee_ops: .open = optee_open
rc = teedev->desc->ops->open(ctx);

INIT_WORK(&optee->scan_bus_work, optee_bus_scan);
    WARN_ON(optee_enumerate_devices(PTA_CMD_GET_DEVICES_SUPP));
		return  __optee_enumerate_devices(func);
    		ctx = tee_client_open_context(NULL, optee_ctx_match, NULL, NULL);/* Open context with OP-TEE driver */
				ctx = teedev_open(container_of(dev, struct tee_device, dev));
					rc = teedev->desc->ops->open(ctx);
			rc = tee_client_open_session(ctx, &sess_arg, NULL);
				return ctx->teedev->desc->ops->open_session(ctx, arg, param);//.open_session = optee_open_session
					optee_do_call_with_arg
                        optee_smccc_smc
                        	opteed_smc_handler
```

### 0.2.2 ioctl

**TEE_IOC_VERSION** - query version of TEE

 Takes a tee_ioctl_version_data struct and returns with the TEE version data filled in.

```c
// int ioctl(int __fd, unsigned long __request, ...)
ioctl(fd, TEE_IOC_VERSION, &vers)
    
// somehow goto linux/drivers/tee/tee_core.c
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_VERSION:
            // static int tee_ioctl_version(struct tee_context *ctx, struct tee_ioctl_version_data *uvers)
            return tee_ioctl_version(ctx, uarg); // void __user *uarg = (void __user *)arg;
    }
}
```

## 0.3 daemon

```c
/* Put the program in the background, and dissociate from the controlling
   terminal.  If NOCHDIR is zero, do `chdir ("/")'.  If NOCLOSE is zero,
   redirects stdin, stdout, and stderr to /dev/null.  */
// extern int daemon (int __nochdir, int __noclose) __THROW __wur;
daemon(0, 0) // 修改参数为（1，1），才能显示打印信息
```

## 0.4 process_one_request[146]

```c
/* 调用process_one_request函数接收来自TEE的请求,并加以处理 */
	while (!arg.abort) {
		if (!process_one_request(&arg))
			arg.abort = true;
	}
```

### 0.4.1 num_waiters_inc

增加当前正在等待处理的tee_supplicant的数量

```c
// static size_t num_waiters_inc(struct thread_arg *arg)
num_waiters_inc(arg);
```

### 0.4.2 read_request

通过ioctl函数,将等待请求发送到tee驱动,在tee驱动中将会阻塞,直到有来自TA的请求才会返回

```c
// static bool read_request(int fd, union tee_rpc_invoke *request)
read_request(arg->fd, &request)
    
// int ioctl(int __fd, unsigned long __request, ...)
ioctl(fd, TEE_IOC_SUPPL_RECV, &data)
    
// somehow goto linux/drivers/tee/tee_core.c
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_SUPPL_RECV:
            // static int tee_ioctl_supp_recv(struct tee_context *ctx, struct tee_ioctl_buf_data *ubuf)
            return tee_ioctl_supp_recv(ctx, uarg); // void __user *uarg = (void __user *)arg;
    }
}    
```

TEE_IOC_SUPPL_RECV - Receive a request for a supplicant function

Takes a struct tee_ioctl_buf_data which contains a struct tee_iocl_supp_recv_arg followed by any array of struct tee_param

### 0.4.3 find_params

解析从TA发送的请求,分离出TA需要tee_supplicant执行的操作对应的ID和执行操作需要的参数

```c
// static bool find_params(union tee_rpc_invoke *request, uint32_t *func,size_t *num_params, struct tee_ioctl_param **params,size_t *num_meta)
find_params(&request, &func, &num_params, &params, &num_meta)// back from 1.2.1.1
    *func = request->recv.func;//记录TA请求的操作编号
	*num_params = request->recv.num_params - n;//确定TA真正的参数个数(跳过属性为TEE_IOCTL_PARAM_ATTR_META的参数)
	*params = p + n;//将params指向TA发送过来的参数
	*num_meta = n;//定位meta的起始位置
```

### 0.4.4 num_waiters_dec

*将等待请求的数量减一*

```c
// static size_t num_waiters_dec(struct thread_arg *arg)
num_waiters_dec(arg)
```

### 0.4.5 spawn_thread

*创建新的线程**[177]**来接收来自TA的请求*

```c
// static bool spawn_thread(struct thread_arg *arg)
spawn_thread(arg)
    /*
	 * Increase number of waiters now to avoid starting another thread
	 * before this thread has been scheduled.
	 */
	num_waiters_inc(arg);

	e = pthread_create(&tid, NULL, thread_main, arg);

// [177]
thread_main
    num_waiters_dec
    process_one_request
    	num_waiters_inc
    	read_request
    	
    	find_params// cuntinue from 0.4.8
    	num_waiters_dec //spawn_thread MISSING
    	ret = tee_supp_fs_process(num_params, params);//OPTEE_MSG_RPC_CMD_FS处理操作文件系统的请求
		
		/*tee_supplicant会根据TA请求调用tee_supp_fs_process函数来完成对文件系统的具体操作，
        包括常规的文件和目录的打开、关闭、读取、写入、重命名、删除等。*/(178)
        OPTEE_MSG_RPC_CMD_FS ... 	/* File system access, defined in tee-supplicant */
	
		[146]OPTEE_MSG_RPC_CMD_SHM_ALLOC/* step1. 分配共享内存 */701
            
		[146]OPTEE_MSG_RPC_CMD_LOAD_TA/* 触发第一次RPC请求将返回TA镜像文件的大小 */994
        [177]OPTEE_MSG_RPC_CMD_SHM_ALLOC/* 分配大小与TA镜像文件大小相当的共享内存 */1015
        [177]OPTEE_MSG_RPC_CMD_LOAD_TA/* 触发第二次RPC请求,TA镜像文件的内容将会被读取到刚刚分配的共享内存中 */1031
        [146]OPTEE_MSG_RPC_CMD_SHM_FREE	/* 释放TA与tee_supplicant之间的共享内存 */1871
        [177]OPTEE_MSG_RPC_CMD_SHM_FREE	/* 释放TA与tee_supplicant之间的共享内存 */1798

// 1.2.1.1 follow-up
optee_do_call_with_arg(struct tee_context *ctx, phys_addr_t parg)
	optee_handle_rpc(ctx, &param, &call_ctx);            
		handle_rpc_func_cmd(ctx, optee, shm, call_ctx);        
            handle_rpc_func_cmd_shm_free(ctx, arg);
                cmd_free_suppl(ctx, shm);
                	optee_supp_thrd_req(ctx, OPTEE_MSG_RPC_CMD_SHM_FREE, 1, &param);
```

### 0.4.6 process_alloc

*根据TA请求的ID来执行具体的handle* 

```c
switch (func) {
    case OPTEE_MSG_RPC_CMD_SHM_ALLOC:
        //static uint32_t process_alloc(struct thread_arg *arg, size_t num_params, struct tee_ioctl_param *params)
        ret = process_alloc(arg, num_params, params);//处理分配共享内存的请求
        break;
}

	//static int get_value(size_t num_params, struct tee_ioctl_param *params, const uint32_t idx, struct param_value **value)
	get_value(num_params, params, 0, &val)
    // static struct tee_shm *register_local_shm(int fd, size_t size)
    shm = register_local_shm(arg->fd, val->b);
		shm->fd = ioctl(fd, TEE_IOC_SHM_REGISTER, &data);

static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_SHM_REGISTER:
            // static int tee_ioctl_shm_register(struct tee_context *ctx, struct tee_ioctl_shm_register_data *udata)
            return tee_ioctl_shm_register(ctx, uarg); // void __user *uarg = (void __user *)arg;
    }
}
```

### 0.4.7 write_response

*回复处理后的数据给TA*

```c
// static bool write_response(int fd, union tee_rpc_invoke *request)
return write_response(arg->fd, &request);
	/* 调用驱动中ioctl函数的TEE_IOC_SUPPL_SEND功能,将数据发送给TA */
	ioctl(fd, TEE_IOC_SUPPL_SEND, &data)
        
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_SUPPL_SEND:
            // static int tee_ioctl_supp_send(struct tee_context *ctx, struct tee_ioctl_buf_data *ubuf)
            return tee_ioctl_supp_send(ctx, uarg); // void __user *uarg = (void __user *)arg;
    }
}
```

### 0.4.8 looping

block at **read_request**

```c
0.4.1 num_waiters_inc
0.4.2 read_request

    [146] -> [177] 0.4.5
```



# 1. CA(hello world)

## 1.1 TEEC_InitializeContext

Initialize a context connecting us to the TEE

```c
// TEEC_Result TEEC_InitializeContext(const char *name, TEEC_Context *ctx)
res = TEEC_InitializeContext(NULL, &ctx);
```

### 1.1.1 teec_open_dev

```c
 // How many device sequence numbers will be tried before giving up
#define TEEC_MAX_DEV_SEQ    10

for (n = 0; n < TEEC_MAX_DEV_SEQ; n++) {
    // static int teec_open_dev(const char *devname, const char *capabilities,
    //			 uint32_t *gen_caps)
    fd = teec_open_dev(devname, name, &gen_caps);
}
```

#### 1.1.1.1 open

```c
// int open(const char *__file, int __oflag, ...)
fd = open(devname, O_RDWR);

// somehow goto linux/drivers/tee/tee_core.c
static int tee_open(struct inode *inode, struct file *filp){
	// static struct tee_context *teedev_open(struct tee_device *teedev)
    ctx = teedev_open(container_of(inode->i_cdev, struct tee_device, cdev));
}

// static const struct tee_driver_ops optee_ops: .open = optee_open
rc = teedev->desc->ops->open(ctx);
```

#### 1.1.1.2 ioctl

**TEE_IOC_VERSION** - query version of TEE

 Takes a tee_ioctl_version_data struct and returns with the TEE version data filled in.

```c
// int ioctl(int __fd, unsigned long __request, ...)
ioctl(fd, TEE_IOC_VERSION, &vers)
    
// somehow goto linux/drivers/tee/tee_core.c
static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_VERSION:
            // static int tee_ioctl_version(struct tee_context *ctx, struct tee_ioctl_version_data *uvers)
            return tee_ioctl_version(ctx, uarg); // void __user *uarg = (void __user *)arg;
    }
}
```

## 1.2 TEEC_OpenSession

```c
rc = ioctl(ctx->fd, TEE_IOC_OPEN_SESSION, &buf_data);

static long tee_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){
    switch (cmd) {
        case TEE_IOC_OPEN_SESSION:
            // static int tee_ioctl_open_session(struct tee_context *ctx, struct tee_ioctl_buf_data __user *ubuf)
            return tee_ioctl_open_session(ctx, uarg); 
    }
}

// static const struct tee_driver_ops optee_ops: .open_session = optee_open_session
rc = ctx->teedev->desc->ops->open_session(ctx, &arg, params);
```

### 1.2.1 optee_open_session

#### 1.2.1.1 optee_do_call_with_arg

```c
/**
 * optee_do_call_with_arg() - Do an SMC to OP-TEE in secure world
 * @ctx:	calling context
 * @parg:	physical address of message to pass to secure world
 *
 * Does and SMC to OP-TEE in secure world and handles eventual resulting
 * Remote Procedure Calls (RPC) from OP-TEE.
 *
 * Returns return code from secure world, 0 is OK
 */
u32 optee_do_call_with_arg(struct tee_context *ctx, phys_addr_t parg){
    // optee->invoke_fn = invoke_fn;
    // invoke_fn = get_invoke_func(&pdev->dev);
	optee->invoke_fn(param.a0, param.a1, param.a2, param.a3, param.a4, param.a5, param.a6, param.a7, &res);
    /**
     * get_invoke_func() - invoke SMC or HVC call
     * @dev: pointer to device
     *
     * Return: function pointer to svc_smccc_smc or svc_smccc_hvc.
     */
}

/**
 * svc_smccc_smc() - secure monitor call between normal and secure world
 * @a0: argument passed in registers 0
 * @a1: argument passed in registers 1
 * @a2: argument passed in registers 2
 * @a3: argument passed in registers 3
 * @a4: argument passed in registers 4
 * @a5: argument passed in registers 5
 * @a6: argument passed in registers 6
 * @a7: argument passed in registers 7
 * @res: result values from register 0 to 3
 */
static void svc_smccc_smc(unsigned long a0, unsigned long a1,
			  unsigned long a2, unsigned long a3,
			  unsigned long a4, unsigned long a5,
			  unsigned long a6, unsigned long a7,
			  struct arm_smccc_res *res)
{
	arm_smccc_smc(a0, a1, a2, a3, a4, a5, a6, a7, res);
}

#define arm_smccc_smc(...) __arm_smccc_smc(__VA_ARGS__, NULL)

/**
 * __arm_smccc_smc() - make SMC calls
 * @a0-a7: arguments passed in registers 0 to 7
 * @res: result values from registers 0 to 3
 * @quirk: points to an arm_smccc_quirk, or NULL when no quirks are required.
 *
 * This function is used to make SMC calls following SMC Calling Convention.
 * The content of the supplied param are copied to registers 0 to 7 prior
 * to the SMC instruction. The return values are updated with the content
 * from register 0 to 3 on return from the SMC instruction.  An optional
 * quirk structure provides vendor specific behavior.
 */
asmlinkage void __arm_smccc_smc(unsigned long a0, unsigned long a1,
			unsigned long a2, unsigned long a3, unsigned long a4,
			unsigned long a5, unsigned long a6, unsigned long a7,
			struct arm_smccc_res *res, struct arm_smccc_quirk *quirk);

/*
 * void arm_smccc_smc(unsigned long a0, unsigned long a1, unsigned long a2,
 *		  unsigned long a3, unsigned long a4, unsigned long a5,
 *		  unsigned long a6, unsigned long a7, struct arm_smccc_res *res,
 *		  struct arm_smccc_quirk *quirk)
 */
SYM_FUNC_START(__arm_smccc_smc)
	SMCCC	smc
SYM_FUNC_END(__arm_smccc_smc)
EXPORT_SYMBOL(__arm_smccc_smc)
    
/*******************************************************************************
 * This function is responsible for handling all SMCs in the Trusted OS/App
 * range from the non-secure state as defined in the SMC Calling Convention
 * Document. It is also responsible for communicating with the Secure
 * payload to delegate work and return results back to the non-secure
 * state. Lastly it will also return any information that OPTEE needs to do
 * the work assigned to it.
 ******************************************************************************/
static uintptr_t opteed_smc_handler(uint32_t smc_fid,
			 u_register_t x1,
			 u_register_t x2,
			 u_register_t x3,
			 u_register_t x4,
			 void *cookie,
			 void *handle,
			 u_register_t flags)

// log 
[optee_smccc_smc]drivers/tee/optee/core.c(556)
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=1
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=0
[optee_smccc_smc]drivers/tee/optee/core.c(556)
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=1
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=0
[optee_smccc_smc]drivers/tee/optee/core.c(556)
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=1
[opteed_smc_handler]services/spd/opteed/opteed_main.c(200)is_caller_non_secure(flags)=0    

goto 0.4.3 process_one_request.find_params
```

## TEEC_InvokeCommand

## TEEC_CloseSession

## TEEC_FinalizeContext

# 2. TA(hello world)

## 2.1 thread_std_smc_entry refer

```c
/* optee_os/core/arch/arm/kernel/kern.ld.S */
ENTRY(_start)

/* optee_os/core/arch/arm/kernel/entry_a64.S */
FUNC _start , :
	adr	x1, thread_vector_table

/* optee_os/core/arch/arm/kernel/thread_optee_smc_a64.S */
FUNC thread_vector_table , : , .identity_map
	b	vector_std_smc_entry	//处理标准smc异常

/* optee_os/core/arch/arm/kernel/thread_optee_smc_a64.S */
LOCAL_FUNC vector_std_smc_entry , : , .identity_map
	bl	thread_handle_std_smc
	
/* core/arch/arm/kernel/thread_optee_smc.c */
uint32_t thread_handle_std_smc(uint32_t a0, uint32_t a1, uint32_t a2,
			       uint32_t a3, uint32_t a4, uint32_t a5,
			       uint32_t a6 __unused, uint32_t a7 __maybe_unused){
    /* only return on error */
    if (a0 == OPTEE_SMC_CALL_RETURN_FROM_RPC) {
        thread_resume_from_rpc(a3, a1, a2, a4, a5);
		rv = OPTEE_SMC_RETURN_ERESUME;
    } else {
        thread_alloc_and_run(a0, a1, a2, a3);
        rv = OPTEE_SMC_RETURN_ETHREAD_LIMIT;
    }
    
}

/* /home/e0004941/Desktop/1223/optee_os/core/arch/arm/kernel/thread.c */
void thread_alloc_and_run(uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3){
    init_regs(threads + n, a0, a1, a2, a3);
    	thread->regs.pc = (uint64_t)thread_std_smc_entry; // ARM64
    thread_resume(&threads[n].regs);
}

struct thread_ctx_regs {
	uint64_t sp;
	uint64_t pc;
	uint64_t cpsr;
	uint64_t x[31];
	uint64_t tpidr_el0;
};

/* struct thread_ctx_regs */
DEFINE(THREAD_CTX_REGS_SP, offsetof(struct thread_ctx_regs, sp));
DEFINE(THREAD_CTX_REGS_X0, offsetof(struct thread_ctx_regs, x[0]));
DEFINE(THREAD_CTX_REGS_X1, offsetof(struct thread_ctx_regs, x[1]));
DEFINE(THREAD_CTX_REGS_X2, offsetof(struct thread_ctx_regs, x[2]));
DEFINE(THREAD_CTX_REGS_X4, offsetof(struct thread_ctx_regs, x[4]));
DEFINE(THREAD_CTX_REGS_X19, offsetof(struct thread_ctx_regs, x[19]));
DEFINE(THREAD_CTX_REGS_TPIDR_EL0, offsetof(struct thread_ctx_regs, tpidr_el0));

/* optee_os/core/arch/arm/kernel/thread_a64.S */
FUNC thread_resume , :
	load_xregs x0, THREAD_CTX_REGS_SP, 1, 3
	load_xregs x0, THREAD_CTX_REGS_X4, 4, 30
	mov	sp, x1
	msr	elr_el1, x2
	msr	spsr_el1, x3
	ldr	x1, [x0, THREAD_CTX_REGS_TPIDR_EL0]
	msr	tpidr_el0, x1

	b_if_spsr_is_el0 w3, 1f

	load_xregs x0, THREAD_CTX_REGS_X1, 1, 3
	ldr	x0, [x0, THREAD_CTX_REGS_X0]
	return_from_exception

1:	load_xregs x0, THREAD_CTX_REGS_X1, 1, 3
	ldr	x0, [x0, THREAD_CTX_REGS_X0]

	msr	spsel, #1
	store_xregs sp, THREAD_CORE_LOCAL_X0, 0, 1
	b	eret_to_el0
END_FUNC thread_resume
```

## 2.2 thread_std_smc_entry call

```c
/* optee_os/core/arch/arm/kernel/thread_optee_smc_a64.S */
FUNC thread_std_smc_entry , :
	bl	__thread_std_smc_entry
    bl	thread_get_tmp_sp
    bl	thread_state_free    
```

### 2.2.1 __thread_std_smc_entry

```c
/* optee_os/core/arch/arm/kernel/thread_optee_smc.c */
uint32_t __weak __thread_std_smc_entry(uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3)
    // static uint32_t std_smc_entry(uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3 __unused)
    rv = std_smc_entry(a0, a1, a2, a3);
		// uint32_t __weak tee_entry_std(struct optee_msg_arg *arg, uint32_t num_params)
		rv = tee_entry_std(arg, num_params);
			entry_open_session(arg, num_params);// case OPTEE_MSG_CMD_OPEN_SESSION://0

res = tee_ta_open_session(&err_orig, &s, &tee_open_sessions, &uuid, &clnt_id, TEE_TIMEOUT_INFINITE, &param);
	res = tee_ta_init_session(err, open_sessions, uuid, &s);
		res = tee_ta_init_user_ta_session(uuid, s);
			res = load_ldelf(utc);
			res = init_with_ldelf(s, utc);

res = thread_enter_user_mode((vaddr_t)arg, 0, 0, 0, usr_stack, utc->entry_func, is_arm32, &panicked, &panic_code);
	rc = __thread_enter_user_mode(regs, exit_status0, exit_status1);

/* optee_os/core/arch/arm/kernel/thread_a64.S */
FUNC __thread_enter_user_mode , :
	/* Jump into user mode */
	b eret_to_el0
        
goto 2.3

goto 3.2 TA_OpenSessionEntryPoint
```

### 2.2.2 thread_get_tmp_sp

```c
/* optee_os/core/arch/arm/kernel/thread.c */
void __nostackcheck *thread_get_tmp_sp(void)
```

### 2.2.3 thread_state_free

```c
/* optee_os/core/arch/arm/kernel/thread.c */
void thread_state_free(void)
```

## 2.3 ldelf

待共享内存中的TA镜像文件校验通过后，OP-TEE就会将共享内存中的TA的内容复制到OP-TEE用户空间的TA内存区域，并初始化该TA运行于用户空间时的上下文。这些操作通过调用**ldelf**函数来实现。

TA镜像文件的TA原始文件是ELF格式，在加载前需要先解析该ELF格式文件，获取该ELF文件中哪些段在运行时是必需的、需要保存在什么位置，从而决定用户空间中该TA运行时需要的内存大小和堆栈空间大小。解析完后再将ELF格式的必要段的内容复制到为该TA分配的OP-TEE用户空间内存中。

```c
ENTRY(_ldelf_start) optee_os/ldelf/ldelf.ld.S

FUNC _ldelf_start , :
2:	bl	ldelf
```

D/LD:  ldelf:134 Loading TA 8aaaf200-2450-11e4-abe2-0002a5d5c51b

### 2.3.1 sys_map_zi

**PTA_SYSTEM_MAP_ZI**: *Map zero initialized memory*

1. open session **system.pta** 
   1.  ask ptr to the session s
   2.  allocates space for s->user_ctx (Opaque session handle assigned by PTA)
2. call **system_map_zi**

```c
// TEE_Result sys_map_zi(size_t num_bytes, uint32_t flags, vaddr_t *va, size_t pad_begin, size_t pad_end)
res = sys_map_zi(mpool_size, 0, &mpool_base, 0, 0);
	// static TEE_Result invoke_sys_ta(uint32_t cmdid, struct utee_params *params)
	res = invoke_sys_ta(PTA_SYSTEM_MAP_ZI, &params);// params.vals[3] = va
		// TEE_Result _utee_open_ta_session(const TEE_UUID *dest, unsigned long cancel_req_to,
		//		 struct utee_params *params, uint32_t *sess, uint32_t *ret_orig);
		res = _utee_open_ta_session(&(const TEE_UUID)PTA_SYSTEM_UUID, 0, NULL, &s, &ret_orig);//syscall_open_ta_session
            res = tee_ta_open_session(&ret_o, &s, &utc->open_sessions, uuid, clnt_id, cancel_req_to, param);
                res = tee_ta_init_session(err, open_sessions, uuid, &s);
                    res = tee_ta_init_pseudo_ta_session(uuid, s); // system.pta : 3a2f8978-5dc0-11e8-9c2d-fa7ae01bbebc
				res = ctx->ops->enter_open_session(s, param, err); // .enter_open_session = pseudo_ta_enter_open_session
					res = stc->pseudo_ta->open_session_entry_point(param->types, tee_param, &s->user_ctx);// .* = open_session
		return _utee_invoke_ta_command(sess, 0, cmdid, params, &ret_orig);//syscall_invoke_ta_command
			called_sess = tee_ta_get_session((uint32_t)ta_sess, true, &utc->open_sessions);
			res = tee_ta_invoke_command(&ret_o, called_sess, &clnt_id, cancel_req_to, cmd_id, &param);
				res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);//pseudo_ta_enter_invoke_cmd
					res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
						return system_map_zi(s, param_types, params);
```

### 2.3.2 malloc_add_pool

Adds a pool of memory to allocate from.

```c
// void malloc_add_pool(void *buf, size_t len);
malloc_add_pool((void *)mpool_base, mpool_size);
	// static void gen_malloc_add_pool(struct malloc_ctx *ctx, void *buf, size_t len)
	gen_malloc_add_pool(&malloc_ctx, buf, len);

#define DEFINE_CTX(name) struct malloc_ctx name =		\
	{ .poolset = { .freelist = { {0, 0},			\
			{&name.poolset.freelist,		\
			 &name.poolset.freelist}}}}
static DEFINE_CTX(malloc_ctx);
```

### 2.3.3 ta_elf_load_main

Load the main binary and get a list of dependencies, if any.

```c
//void ta_elf_load_main(const TEE_UUID *uuid, uint32_t *is_32bit, uint64_t *sp, uint32_t *ta_flags)
ta_elf_load_main(&arg->uuid, &arg->is_32bit, &arg->stack_ptr, &arg->flags);
```

#### 2.3.3.1 queue_elf

```c
// static struct ta_elf *queue_elf(const TEE_UUID *uuid)
struct ta_elf *elf = queue_elf(uuid);
	// struct ta_elf *ta_elf_find_elf(const TEE_UUID *uuid)
	struct ta_elf *elf = ta_elf_find_elf(uuid);
	// static struct ta_elf *queue_elf_helper(const TEE_UUID *uuid)
	elf = queue_elf_helper(uuid);
		elf->uuid = *uuid;
```

#### 2.3.3.2 load_main

```c
goto 4. static void load_main(struct ta_elf *elf)
```

#### 2.3.3.3 sys_map_zi

```c
// TEE_Result sys_map_zi(size_t num_bytes, uint32_t flags, vaddr_t *va, size_t pad_begin, size_t pad_end)
res = sys_map_zi(elf->head->stack_size, 0, &va, 0, 0);
```

### 2.3.4 ta_elf_load_dependency

### 2.3.5 ta_elf_relocate

### 2.3.6 ta_elf_finalize_mappings

### 2.3.7 ta_elf_finalize_load_main

### 2.3.8 sys_return_cleanup

# 3. load_main

Called by 2.3.3 **ta_elf_load_main** after **queue_elf**. (2.3.3.2)

```c
static void load_main(struct ta_elf *elf){
    init_elf(elf);//static void init_elf(struct ta_elf *elf)
	map_segments(elf);//static void map_segments(struct ta_elf *elf)
	populate_segments(elf);//static void populate_segments(struct ta_elf *elf)
	add_dependencies(elf);//static void add_dependencies(struct ta_elf *elf)
	copy_section_headers(elf);//static void copy_section_headers(struct ta_elf *elf)
	save_symtab(elf);//static void save_symtab(struct ta_elf *elf)
	close_handle(elf);//static void close_handle(struct ta_elf *elf)
	set_tls_offset(elf);//static void set_tls_offset(struct ta_elf *elf)
}
```

## 3.1 init_elf

```c
//TEE_Result sys_open_ta_bin(const TEE_UUID *uuid, uint32_t *handle)
res = sys_open_ta_bin(&elf->uuid, &elf->handle);
// TEE_Result sys_map_ta_bin(vaddr_t *va, size_t num_bytes, uint32_t flags, 
//			uint32_t handle, size_t offs, size_t pad_begin, size_t pad_end)
res = sys_map_ta_bin(&va, SMALL_PAGE_SIZE, flags, elf->handle, 0, 0, 0);
// static TEE_Result e64_parse_ehdr(struct ta_elf *elf, Elf64_Ehdr *ehdr)
res = e64_parse_ehdr(elf, (void *)va);// parse ELF
     elf->* = va->*
```

### 3.1.1 sys_open_ta_bin

```c
res = invoke_sys_ta(PTA_SYSTEM_OPEN_TA_BINARY, &params);
	return _utee_invoke_ta_command(sess, 0, cmdid, params, &ret_orig);//syscall_invoke_ta_command
		called_sess = tee_ta_get_session((uint32_t)ta_sess, true, &utc->open_sessions);
		res = tee_ta_invoke_command(&ret_o, called_sess, &clnt_id, cancel_req_to, cmd_id, &param);
			res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);//pseudo_ta_enter_invoke_cmd
				res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
					return system_open_ta_binary(sess_ctx, param_types, params);

goto 4. system_open_ta_binary
// Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (Secure Storage TA)	//binh->op->description
// res=0xffff0008
#define TEE_ERROR_ITEM_NOT_FOUND          0xFFFF0008
// Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
// res=0x0
*handle = params.vals[2];
```

### 3.1.2 sys_map_ta_bin

```c
res = invoke_sys_ta(PTA_SYSTEM_MAP_TA_BINARY, &params);// params.*  = input_params
	return _utee_invoke_ta_command(sess, 0, cmdid, params, &ret_orig);//syscall_invoke_ta_command
		called_sess = tee_ta_get_session((uint32_t)ta_sess, true, &utc->open_sessions);
		res = tee_ta_invoke_command(&ret_o, called_sess, &clnt_id, cancel_req_to, cmd_id, &param);
			res = sess->ctx->ops->enter_invoke_cmd(sess, cmd, param, err);//pseudo_ta_enter_invoke_cmd
				res = stc->pseudo_ta->invoke_command_entry_point(s->user_ctx, cmd, param->types, tee_param);//invoke_command
					return system_map_ta_binary(sess_ctx, s, param_types, params);
```

## 3.2 map_segments

## 3.3 populate_segments

## 3.4 add_dependencies

## 3.5 copy_section_headers

## 3.6 save_symtab

## 3.7 close_handle

## 3.8 set_tls_offset

# 4. system_open_ta_binary

called from 3.1.1 **sys_open_ta_bin**

```c
/* Lookup user TA ELF 8aaaf200-2450-11e4-abe2-0002a5d5c51b (REE)
TEE_TA_REGISTER_TA_STORE(9) = {
	.description = "REE",
	.open = ree_fs_ta_open,
	.get_size = ree_fs_ta_get_size,
	.get_tag = ree_fs_ta_get_tag,
	.read = ree_fs_ta_read,
	.close = ree_fs_ta_close,
};*/

// static TEE_Result ree_fs_ta_open(const TEE_UUID *uuid, struct user_ta_store_handle **h)
res = binh->op->open(uuid, &binh->h);
```

## 4.1 ree_fs_ta_open

```c
/* Request TA from tee-supplicant */
res = rpc_load(uuid, &ta, &ta_size, &mobj);
/* Make secure copy of signed header */
shdr = shdr_alloc_and_copy(ta, ta_size);
/* Validate header signature */
res = shdr_verify_signature(shdr);
/*
* Initialize a hash context and run the algorithm over the signed
* header (less the final file hash and its signature of course)
*/
res = crypto_hash_alloc_ctx(&hash_ctx,
				    TEE_DIGEST_HASH_TO_ALGO(shdr->algo));
res = crypto_hash_init(hash_ctx);
res = crypto_hash_update(hash_ctx, (uint8_t *)shdr, sizeof(*shdr));
/*分配的共享内存的地址将会被保存到ta_handle变量的nw_ta成员中，读取到的TA镜像文件的内容将会被加载到OP-TEE用户空间TA运行的内存中*/
handle->nw_ta = ta;
```

### 4.1.1 rpc_load

Load a TA via RPC with UUID defined by input param @uuid. The virtual address of the raw TA binary is received in out parameter @ta.

```c
static TEE_Result rpc_load(const TEE_UUID *uuid, struct shdr **ta, size_t *ta_size, struct mobj **mobj)
    // uint32_t thread_rpc_cmd(uint32_t cmd, size_t num_params, struct thread_param *params)
    res = thread_rpc_cmd(OPTEE_RPC_CMD_LOAD_TA, 2, params);//返回TA镜像文件的大小
	*mobj = thread_rpc_alloc_payload(params[1].u.memref.size);//分配大小与TA镜像文件大小相当的共享内存
	*ta = mobj_get_va(*mobj, 0);//获取分配的共享内存的虚拟地址被保存在*ta中
	res = thread_rpc_cmd(OPTEE_RPC_CMD_LOAD_TA, 2, params);//TA镜像文件的内容将会被读取到刚刚分配的共享内存中
```

### 4.1.2 thread_rpc_cmd

加载TA过程中，ta_open函数会调用rpc_load函数，该函数会调用thread_rpc_cmd来发送OPTEE_RPC_CMD_LOAD_TA的RPC请求，rpc_load函数会组合该类请求的相关数据结构变量，然后通过调用thread_rpc函数向REE发送RPC请求。

```c
uint32_t thread_rpc_cmd(uint32_t cmd, size_t num_params, struct thread_param *params)
    ret = get_rpc_arg(cmd, num_params, params, &arg, &carg);/* 获取需要通过RPC机制发送到REE侧的参数内容 */
	reg_pair_from_64(carg, rpc_args + 1, rpc_args + 2);/* 转换成64位,以便兼容64位系统 */
	thread_rpc(rpc_args);
	return get_rpc_arg_res(arg, num_params, params);
```

### 4.1.3 thread_rpc

RPC请求的发送是通过触发安全监控模式调用（smc）来实现的，在触发安全监控模式调用（smc）之前会将当前的线程挂起，并保存该线程的运行上下文。

当REE处理完RPC请求后，会发送标准安全监控模式调用（std smc）重新进入到OP-TEE中，OP-TEE根据返回的安全监控模式调用（smc）的类型判定当前的安全监控模式调用（smc）是RPC的返回还是普通的安全监控模式调用（smc）。如果该安全监控模式调用（smc）是返回RPC请求的处理结果，则会进入到thread_resume_from_rpc分支恢复之前被挂起的线程。在thread_rpc函数中已经指定了恢复该线程之后程序执行的入口函数——thread_rpc_return，到此一次完整的RPC请求也就被处理完毕。

```c
/* void thread_rpc(uint32_t rv[THREAD_RPC_NUM_ARGS]) */
FUNC thread_rpc , :
	/* Read daif and create an SPSR(Saved Program Status Register) 
	The exception masking bits
        D 		Debug exception mask bit. When EL0 is enabled to modify the mask bits, this bit is
        		visible and can be modified. However, this bit is architecturally ignored at EL0.
        A 		SError interrupt mask bit.
        I 		IRQ interrupt mask bit.
        F 		FIQ interrupt mask bit.
        For each bit, the values are:
        0 		Exception not masked.
        1 		Exception masked.		
    MRS		Move the contents of a specified special register into the general-purpose register
    At EL0 using AArch64 state, PSTATE fields can be accessed using Special-purpose registers that can be directly
	read using the MRS instruction and directly written using the MSR (register) instructions. 
	The A64 instructions for accessing Special-purpose registers are:
    MSR <Special-purpose register>, Xt ; Write to Special-purpose register
    MRS Xt, <Special-purpose register> ; Read from Special-purpose register 	*/
	mrs	x1, daif
        
    /* Bitwise OR (shifted register) performs a bitwise (inclusive) OR of a register value and 
    	an optionally-shifted register value, and writes the result to the destination register. 
    ORR <Xd>, <Xn>, <Xm>{, <shift> #<amount>}
    	<Xd> Is the 64-bit name of the general-purpose destination register, encoded in the "Rd" field.
    	<Xn> Is the 64-bit name of the first general-purpose source register, encoded in the "Rn" field.
    	<Xm> Is the 64-bit name of the second general-purpose source register, encoded in the "Rm" field.
    #define SPSR_64_MODE_EL1	0x1
    #define SPSR_64_MODE_EL_SHIFT	2 	*/
	orr	x1, x1, #(SPSR_64_MODE_EL1 << SPSR_64_MODE_EL_SHIFT)

	/* Mask all maskable exceptions before switching to temporary stack 
		Operand		PSTATE fields 		Notes
		DAIFSet 	 D, A, I, F 		Directly sets any of the PSTATE.{D,A, I, F} bits to 1
		MSR DAIFSet, #Imm4 ; Used to set any or all of DAIF to 1
	#define DAIFBIT_ALL			(DAIFBIT_FIQ | DAIFBIT_IRQ | DAIFBIT_ABT | DAIFBIT_DBG)*/
	msr	daifset, #DAIFBIT_ALL
        
    /* POP is a load operation, and PUSH is a store operation. 
    	Name	Size	Encoding	Description
     	XZR		64bits 	  31 		Zero register
     	The X30 general-purpose register is used as the procedure call link register. 	*/
	push	x0, xzr
	push	x1, x30
    
    /* Returns a pointer to the saved registers in current thread context. */
	bl	thread_get_ctx_regs
    
    /* Load Register (immediate) loads a word or doubleword from memory and writes it to a register. 
    	LDR <Xt>, [<Xn|SP>{, #<pimm>}]
            <Xt> Is the 64-bit name of the general-purpose register to be transferred, encoded in the "Rt" field.
            <Xn|SP> Is the 64-bit name of the general-purpose base register or stack pointer, encoded in the "Rn" field.
            <pimm> For the 64-bit variant: is the optional positive immediate byte offset, a multiple of 8 in the range 0
                    to 32760, defaulting to 0 and encoded in the "imm12" field as <pimm>/8.*/
	ldr	x30, [sp, #8]
        
    /*Stores registers x[19]..x[30] at [x0, #THREAD_CTX_REGS_X19] 
    DEFINE(THREAD_CTX_REGS_X19, offsetof(struct thread_ctx_regs, x[19]));	*/ 
	store_xregs x0, THREAD_CTX_REGS_X19, 19, 30
    
    /* Move (register) copies the value in a source register to the destination register.(an alias of the ORR)
    	MOV <Xd>, <Xm> 			(is equivalent to ORR <Xd>, XZR, <Xm>)
            <Xd> Is the 64-bit name of the general-purpose destination register, encoded in the "Rd" field.
            <Xm> Is the 64-bit name of the general-purpose source register, encoded in the "Rm" field. */
	mov	x19, x0

	bl	thread_get_tmp_sp	/* 获取tmp栈空间 */
	pop	x1, xzr		/* Match "push x1, x30" above */
	mov	x2, sp
        
    /* Store Register (immediate) stores a word or a doubleword from a register to memory.
    	STR <Xt>, [<Xn|SP>{, #<pimm>}]
    DEFINE(THREAD_CTX_REGS_SP, offsetof(struct thread_ctx_regs, sp));*/    
	str	x2, [x19, #THREAD_CTX_REGS_SP]
        
	ldr	x20, [sp]	/* Get pointer to rv[] */
	mov	sp, x0		/* Switch to tmp stack */
        
	/*
	 * We need to read rv[] early, because thread_state_suspend
	 * can invoke virt_unset_guest() which will unmap pages,
	 * where rv[] resides
	 */
	load_wregs x20, 0, 21, 23	/* Load rv[] into w20-w22 */
	/* Loads registers w[21]..w[23] at [x20, #0] */
    
    /* Form PC-relative address adds an immediate value to the PC value to form a PC-relative address, and writes the
		result to the destination register. 
		ADR <Xd>, <label>
			<Xd> Is the 64-bit name of the general-purpose destination register, encoded in the "Rd" field.
			<label> Is the program label whose address is to be calculated. 
			Its offset from the address of this instruction,in the range +/-1MB, is encoded in "immhi:immlo".*/
	adr	x2, .thread_rpc_return
    
    /* #define THREAD_FLAGS_COPY_ARGS_ON_RETURN	(1 << 0) */
	mov	w0, #THREAD_FLAGS_COPY_ARGS_ON_RETURN
        
	bl	thread_state_suspend	/* 挂起当前线程 */
	mov	x4, x0		/* Supply thread index */
    
    /*
     * Issued when returning from "std_smc" or "fast_smc" vector
     *
     * Register usage:
     * r0/x0	SMC Function ID, TEESMC_OPTEED_RETURN_CALL_DONE
     * r1-4/x1-4	Return value 0-3 which will passed to normal world in
     *		r0-3/x0-3
	#define TEESMC_OPTEED_FUNCID_RETURN_CALL_DONE		5
	#define TEESMC_OPTEED_RETURN_CALL_DONE \
	TEESMC_OPTEED_RV(TEESMC_OPTEED_FUNCID_RETURN_CALL_DONE)
     */
	ldr	w0, =TEESMC_OPTEED_RETURN_CALL_DONE
	mov	x1, x21
	mov	x2, x22
	mov	x3, x23
	smc	#0		/* 触发smc操作,切回到REE侧 */
	b	.		/* SMC should not return */

.thread_rpc_return:
	/*
	 * At this point has the stack pointer been restored to the value
	 * stored in THREAD_CTX above.
	 *
	 * Jumps here from thread_resume above when RPC has returned. The
	 * IRQ and FIQ bits are restored to what they where when this
	 * function was originally entered.
	 */
	pop	x16, xzr	/* Get pointer to rv[] */
	store_wregs x16, 0, 0, 3	/* Store w0-w3 into rv[] */
	ret
END_FUNC thread_rpc
```

### 4.1.4 shdr_verify_signature

当TA镜像文件被加载到共享内存后，OP-TEE会对获取到的数据进行合法性检查。检查TA镜像文件中的**magic**、**algo**、**hash_size**值否一致，并对镜像文件中的电子签名部分做验证。

对TA镜像文件内容合法性的检查是通过调用**shdr_verify_signature**函数来实现的，该函数除了会对TA镜像文件中的签名信息进行验签操作外，还会校验TA镜像文件的shdr部分，校验TA镜像签名时使用的RSA公钥是由ta_public_key.c文件中的ta_pub_key_exponent和ta_pub_key_modulus变量的值组成。

```c
TEE_Result shdr_verify_signature(const struct shdr *shdr){
    uint32_t e = TEE_U32_TO_BIG_ENDIAN(ta_pub_key_exponent);//将全局变量ta_pub_key_exponent转成RSA公钥的E值
    if (shdr->magic != SHDR_MAGIC)/* 校验shdr中的magic值 */
		return TEE_ERROR_SECURITY;
    if (TEE_ALG_GET_MAIN_ALG(shdr->algo) != TEE_MAIN_ALGO_RSA)/* 检查shdr中的algo成员指定的算法类型是否合法 */
		return TEE_ERROR_SECURITY;
    /* 获取验签操作时需要使用的摘要的大小 */
    res = tee_alg_get_digest_size(TEE_DIGEST_HASH_TO_ALGO(shdr->algo), &hash_size);
    if (hash_size != shdr->hash_size)/* 检查shdr中的hash_size是否正确 */
		return TEE_ERROR_SECURITY;
    /* 分配RSA公钥在算法接口中的存储空间 */
    res = crypto_acipher_alloc_rsa_public_key(&key, shdr->sig_size);
    /* 将RSA公钥中的E值转换成大整数*/
    res = crypto_bignum_bin2bn((uint8_t *)&e, sizeof(e), key.e);
    /* 将ta_pub_key_modulus变量的值作为RSA公钥中的N值,并转换成大整数*/
    res = crypto_bignum_bin2bn(ta_pub_key_modulus, ta_pub_key_modulus_size, key.n);
    /* 使用TA镜像文件中的摘要部分和签名信息部分做RSA的验签操作 */
    res = crypto_acipher_rsassa_verify(shdr->algo, &key, shdr->hash_size,
					   SHDR_GET_HASH(shdr), shdr->hash_size,
					   SHDR_GET_SIG(shdr), shdr->sig_size);
}
```

# 5. Interaction

TA镜像的内容从共享内存复制到OP-TEE用户空间内存区域后会返回到**tee_ta_init_user_ta_session**函数继续执行，执行初始化该TA运行上下文的操作，并将该上下文添加到OP-TEE的TA运行上下文队列中。

待**tee_ta_init_user_ta_session**执行完后，加载TA镜像到OP-TEE的操作也就全部完成。在CA中执行的创建会话操作会得到该TA的会话ID，用于REE侧的CA对该TA执行调用命令的操作。

## TA_CreateEntryPoint

## TA_OpenSessionEntryPoint

## TA_InvokeCommandEntryPoint

### inc_value

## TA_DestroyEntryPoint
